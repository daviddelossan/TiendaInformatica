/**
 * 
 */
package Integraci�n.Producto;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import Negocio.Producto.TransferProducto;
import java.util.ArrayList;

/*NOTA:
 * File NO te crea el archivo si no existe
 * FileReader NO te crea el archivo si no existe
 * FileWriter SI te crea el archivo si no existe

 */

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class DAOProductoImp implements DAOProducto {


	/** 
	 * (sin Javadoc)
	 * @see DAOProducto#creaProducto()
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	
	
	public int readNumArchivos(){
		String cadena;
		FileReader f;
		try {
			f = new FileReader("Productos\\" + CENTINELA_NUM_ARCHIVOS + ".txt"); //Si no existe, salta excepcion y pasa al catch
			BufferedReader br = new BufferedReader(f);
			cadena = br.readLine();
			f.close();
			return Integer.parseInt(cadena);
		} catch (IOException e) {
			File escribe = new File("Productos"); //Si no existe la carpeta Productos
			if(!escribe.exists()) //Si el directorio no existe, lo crea
				escribe.mkdir();
			//Escritura inicial del int numArchivos
			try{
				FileWriter w = new FileWriter("Productos\\" + CENTINELA_NUM_ARCHIVOS + ".txt");
				BufferedWriter bw = new BufferedWriter(w);
				PrintWriter wr = new PrintWriter(bw);	
				wr.write("1");
				wr.close();
				bw.close();
			}catch(IOException g){};
			return 1;
		}

	}

	public  void aumentarNumArchivos(){
		Integer centinela = this.readNumArchivos();
		File f;
		f = new File("Productos\\" + CENTINELA_NUM_ARCHIVOS + ".txt");
		//Escritura
		try{
			FileWriter w = new FileWriter(f);
			BufferedWriter bw = new BufferedWriter(w);
			PrintWriter wr = new PrintWriter(bw);	
			wr.write(Integer.toString(centinela + 1));
			wr.close();
			bw.close();
		}catch(IOException e){};
	}
	
	public int creaProducto(TransferProducto tProducto) {
		int id = this.readNumArchivos();

		float precio = tProducto.getPrecio();
		//boolean activo = tProducto.getActivo(); //Se supone que no le vas a meter si lo quieres activo o no, lo querr�s activo
		String nombre = tProducto.getNombre();
		int stock = tProducto.getStock();
		int idProveedor = tProducto.getIDProveedor();
		int idMarca = tProducto.getIDMarca();

		String ruta = "Productos\\" + id + ".txt";
		File archivo = new File(ruta);
		//Escritura
		try{
		FileWriter w = new FileWriter(archivo);
		BufferedWriter bw = new BufferedWriter(w);
		PrintWriter wr = new PrintWriter(bw);	
		wr.write("Activo");
		wr.write("\n");
		wr.write(Integer.toString(id));
		wr.write("\n");
		wr.write(Integer.toString(idMarca));
		wr.write("\n");
		wr.write(Integer.toString(idProveedor));
		wr.write("\n");
		wr.write(nombre);
		wr.write("\n");
		wr.write(Float.toString(precio));
		wr.write("\n");
		wr.write(Integer.toString(stock));
		
		this.aumentarNumArchivos();
		wr.close();
		bw.close();	
		}catch(IOException e){
			id = -1;
		};
		
		return id;
	}

	/** 
	 * (sin Javadoc)
	 * @see DAOProducto#readById(int IDProducto)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public TransferProducto readById(int IDProducto) {
		TransferProducto tProducto = null; //Se quedar� a null si es error
		FileReader leerArchivoID = null;
		
		try{
			leerArchivoID = new FileReader("Productos\\" + IDProducto + ".txt");
			BufferedReader br = new BufferedReader(leerArchivoID);
				tProducto = new TransferProducto(); //Est� vacio por ahora
				if(br.readLine().equals("Activo"))
					tProducto.setActivo(true);
				else
					tProducto.setActivo(false);
				tProducto.setIdProducto(Integer.parseInt(br.readLine()));
				tProducto.setIDMarca(Integer.parseInt(br.readLine()));
				tProducto.setIDProveedor(Integer.parseInt(br.readLine()));
				tProducto.setNombre(br.readLine());
				tProducto.setPrecio(Float.parseFloat(br.readLine()));
				tProducto.setStock(Integer.parseInt(br.readLine()));

		}catch(Exception e){
			////e.printStackTrace();
		} 	finally{
			if(leerArchivoID != null)
				try {
					leerArchivoID.close();
				} catch (Exception e) {
					////e.printStackTrace();
				}
		}

		return tProducto;
	}

	/** 
	 * (sin Javadoc)
	 * @see DAOProducto#readByName()
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public TransferProducto readByName(String nombre) {
		int numArchivos = this.readNumArchivos();
		TransferProducto tProducto = null; //Si hay error se quedar� como null
		boolean encontrado = false;
		int i = 1;
		
		do{
			tProducto = readById(i);
			if(tProducto != null && tProducto.getNombre().equals(nombre))
				encontrado = true;
			else
				i++;
		} while(!encontrado && i < numArchivos);	
		if(!encontrado)
			tProducto = null;
		
		return tProducto;
	}

	/** 
	 * (sin Javadoc)
	 * @see DAOProducto#eliminaProducto(int ID)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean eliminaProducto(int ID) {
		boolean exito = false;

		TransferProducto tProducto = readById(ID);
		if(tProducto != null && tProducto.getActivo()) {
			tProducto.setActivo(false);
			this.modificaProducto(tProducto);
			exito = true;
		}

		return exito;
	}

	/** 
	 * (sin Javadoc)
	 * @see DAOProducto#muestraProducto(int ID)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */


	/** 
	 * (sin Javadoc)
	 * @see DAOProducto#muestraProductos()
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ArrayList<TransferProducto> muestraProductos() {
		int numArchivos = this.readNumArchivos();
		if(numArchivos <= 1)
			return null;
		ArrayList<TransferProducto> array = new ArrayList<TransferProducto>();
		
		for(int i = 1; i < numArchivos; i++){ //empezando la id desde 1 hasta numArchivos
			array.add(readById(i)); //desde id 1
		}	
		return array;
	}

	/** 
	 * (sin Javadoc)
	 * @see DAOProducto#readNumArchivos()
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */

	
	/** 
	 * (sin Javadoc)
	 * @see DAOProducto#modificaProducto(TransferProducto TProducto)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean modificaProducto(TransferProducto tProducto) {
		boolean exito = false;
		
		String activoProducto = "";
		if(tProducto.getActivo())
			activoProducto = "Activo";
		else
			activoProducto = "Inactivo";

		int idProducto = tProducto.getID();
		int idMarca = tProducto.getIDMarca();
		int idProveedor = tProducto.getIDProveedor();
		String nombreProducto = tProducto.getNombre();
		float precioProducto = tProducto.getPrecio();
		int stockProducto = tProducto.getStock();

		String ruta = "Productos\\" + idProducto + ".txt";
		File archivo = new File(ruta);
		try{
			FileWriter w = new FileWriter(archivo);
			if(archivo.exists()) {
					BufferedWriter bw = new BufferedWriter(w);
					PrintWriter wr = new PrintWriter(bw);		
					wr.write(activoProducto);
					wr.write("\n");
					wr.write(Integer.toString(idProducto));
					wr.write("\n");
					wr.write(Integer.toString(idMarca));
					wr.write("\n");
					wr.write(Integer.toString(idProveedor));
					wr.write("\n");
					wr.write(nombreProducto);
					wr.write("\n");
					wr.write(Float.toString(precioProducto));
					wr.write("\n");
					wr.write(Integer.toString(stockProducto));
					wr.close();
					bw.close();	
					exito = true;
			}
		}catch(IOException e){
			//e.printStackTrace();
		}

		return exito;
	}


}