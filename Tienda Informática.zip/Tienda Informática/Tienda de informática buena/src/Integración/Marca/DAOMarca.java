/**
 * 
 */
package Integraci�n.Marca;

import Negocio.Marca.TransferMarca;
import java.util.ArrayList;


public interface DAOMarca {

	public int creaMarca(TransferMarca TMarca);
	public TransferMarca readById(Integer ID);
	public TransferMarca readByName(String nombre);
	public TransferMarca muestraMarca(Integer ID);
	public ArrayList<TransferMarca> muestraMarcas();
	public boolean eliminaMarca(Integer ID);
	public boolean modificaMarca(TransferMarca tMarca);
	public void aumentaNumProductos(Integer ID);
	public void restaNumProductos(Integer ID);
	
}