/**
 * 
 */
package Integraci�n.Marca;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import Negocio.Marca.TransferMarca;
import java.util.ArrayList;


public class DAOMarcaImpl  implements DAOMarca {

	private Integer leeNumArchivos(){
		String cadena;
		  FileReader f;
			try {
			  f = new FileReader("Marca\\NumArchivos.txt");	
		      BufferedReader br = new BufferedReader(f);
			  cadena = br.readLine();
			  return Integer.parseInt(cadena);
			} catch (IOException e) {
				//Si no existia crear 
				File escribe;
				escribe = new File("Marca");
				//Si el directorio no existe
				if(!escribe.exists())
					escribe.mkdir();
				escribe = new File("Marca\\NumArchivos.txt");
				//Escritura
				try{
				FileWriter w = new FileWriter(escribe);
				BufferedWriter bw = new BufferedWriter(w);
				PrintWriter wr = new PrintWriter(bw);	
				wr.write("1");
				wr.close();
				bw.close();
				}catch(IOException g){};
				return 1;
			}
		
		}

	public  void aumentarNumArchivos(){
		Integer centinela = leeNumArchivos();
		File f;
		f = new File("Marca\\NumArchivos.txt");
		//Escritura
		try{
		FileWriter w = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(w);
		PrintWriter wr = new PrintWriter(bw);	
		wr.write(Integer.toString(centinela + 1));
		wr.close();
		bw.close();
		}catch(IOException e){};
		}
		
	@Override
	public int creaMarca(TransferMarca TMarca) {
		Integer centinela = leeNumArchivos();
		File f;
		f = new File("Marca\\" + Integer.toString(centinela) + ".txt");
		//Escritura
		try{
		FileWriter w = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(w);
		PrintWriter wr = new PrintWriter(bw);	
		wr.write(Integer.toString(centinela));
		wr.write('\n');
		wr.write(TMarca.getNombre());
		wr.write('\n');
		wr.write(Integer.toString(TMarca.getNumProductos()));
		wr.write('\n');
		if(TMarca.getActivo() == true)
			wr.write("activo");
		else
			wr.write("inactivo");
		wr.close();
		bw.close();
		
		
		aumentarNumArchivos(); //Esto tiene que estar dentro del try, si ha habido error no se tiene que aumentar
		}catch(IOException e){
			
		};
		return centinela;
	}

	@Override
	public TransferMarca readById(Integer ID) {
		TransferMarca marca = new TransferMarca();
		FileReader f;
		try {
		  f = new FileReader("Marca\\" + Integer.toString(ID) + ".txt");	
	      BufferedReader br = new BufferedReader(f);
	      	marca.setID(Integer.parseInt(br.readLine()));
	      	marca.setNombre( br.readLine());
	      	marca.setNumProductos(Integer.parseInt(br.readLine()));
	      	if(br.readLine().equalsIgnoreCase("activo"))
	      		marca.setActivo(true);
	      	else
	      		marca.setActivo(false);
			return marca;
		} catch (IOException e) {
			return null;
		}
	}

	@Override
	public TransferMarca readByName(String nombre) {
		int i = 1;
		while (i < leeNumArchivos()){
			if(readById(i).getNombre().equalsIgnoreCase(nombre)){
				return readById(i);
			}
			i++;
		}
		return null;
	}

	@Override
	public TransferMarca muestraMarca(Integer ID) {
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return null;
	}

	@Override
	public ArrayList<TransferMarca> muestraMarcas() {
		int i = 1;
		int centinela = leeNumArchivos();
		ArrayList<TransferMarca> arrayMarcas = new ArrayList<TransferMarca>();
		while(i < centinela){
			arrayMarcas.add(readById(i));
			i++;
		}
		return arrayMarcas;
	}

	@Override
	public boolean eliminaMarca(Integer ID) {
			TransferMarca marca = readById(ID);
			if(marca != null && marca.getActivo())
			{
			 if(marca.getNumProductos() == 0){
				marca.setActivo(false);
				modificaMarca(marca);
				return true;}
			 else
				 return false;
			}
			else return false;
			
	}

	@Override
	public boolean modificaMarca(TransferMarca tMarca) {
		Integer IDMarca = tMarca.getID();
		String nombre = tMarca.getNombre();
		Integer numProductos = tMarca.getNumProductos();
		boolean activo = tMarca.getActivo();
		File f;
		f = new File("Marca\\" + IDMarca + ".txt");
		//Escritura
		try{
		FileWriter w = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(w);
		PrintWriter wr = new PrintWriter(bw);
		wr.write(Integer.toString(IDMarca));
		wr.write('\n');
		wr.write(nombre);
		wr.write('\n');
		wr.write(Integer.toString(numProductos));
		wr.write('\n');
		if(activo == true)
			wr.write("activo");
		else
			wr.write("inactivo");
		wr.close();
		bw.close();
		return true;
		}catch(IOException e){
			return false;
		}
		
	}

	@Override
	public void aumentaNumProductos(Integer ID) {
		TransferMarca marca = readById(ID);
		marca.setNumProductos(marca.getNumProductos()+1);
		modificaMarca(marca);
	}

	@Override
	public void restaNumProductos(Integer ID) {
		TransferMarca marca = readById(ID);
		marca.setNumProductos(marca.getNumProductos()-1);
		modificaMarca(marca);
	}
}