/**
 * 
 */
package Integraci�n.Cliente;

import Negocio.Cliente.TCliente;
import java.util.ArrayList;

public interface DAOCliente {

	static final String nombreArchivoInicial = "-1.txt";
	public int creaCliente(TCliente tCliente);
	public TCliente readById(int IDCliente);
	public TCliente readByName(String Nombre);
	public TCliente muestraCliente(int ID);
	public ArrayList<TCliente> muestraClientes();
	public boolean eliminaCliente(int ID);
	public boolean modificaCliente(TCliente tCliente);
	public Integer leeNumArchivos();
	public void aumentarNumArchivos();
}