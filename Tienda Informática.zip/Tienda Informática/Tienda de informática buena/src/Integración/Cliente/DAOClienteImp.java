package Integraci�n.Cliente;

import java.io.*;

import Negocio.Cliente.TCliente;
import Negocio.Cliente.TransferClienteNormal;
import Negocio.Cliente.TransferClienteVip;
import java.util.ArrayList;

public class DAOClienteImp implements DAOCliente {

	public Integer leeNumArchivos() {
		String cadena;
		FileReader f;

		try{
			f = new FileReader("Cliente\\NumArchivos.txt");
			BufferedReader br = new BufferedReader(f);
			cadena = br.readLine();
			return Integer.parseInt(cadena);
		}
		catch (IOException e) {
			//Si no existia crear 
			File escribe;
			escribe = new File("Cliente");
			//Si el directorio no existe
			if(!escribe.exists())
				escribe.mkdir();
			escribe = new File("Cliente\\NumArchivos.txt");
			//Escritura
			try{
				FileWriter w = new FileWriter(escribe);
				BufferedWriter bw = new BufferedWriter(w);
				PrintWriter wr = new PrintWriter(bw);	
				wr.write("1");
				wr.close();
				bw.close();
			}catch(IOException g){};
			return 1;
		}
	}


	public  void aumentarNumArchivos(){
		Integer centinela = leeNumArchivos();
		File f;
		f = new File("Cliente\\NumArchivos.txt");
		//Escritura
		try{
			FileWriter w = new FileWriter(f);
			BufferedWriter bw = new BufferedWriter(w);
			PrintWriter wr = new PrintWriter(bw);	
			wr.write(Integer.toString(centinela + 1));
			wr.close();
			bw.close();
		}catch(IOException e){};
	}


	public int creaCliente(TCliente tCliente){
		Integer centinela = leeNumArchivos();
		File f;
		f = new File("Cliente\\" + Integer.toString(centinela) + ".txt");		

		try{
			FileWriter w = new FileWriter(f);
			BufferedWriter bw = new BufferedWriter(w);
			PrintWriter wr = new PrintWriter(bw);
			wr.write(Integer.toString(centinela));
			wr.write('\n');

			if(tCliente.getClass() == TransferClienteVip.class){ //Si el cliente es VIP
				TransferClienteVip transferClienteVip = (TransferClienteVip)tCliente;
				wr.write(((Integer)transferClienteVip.getLimiteTarjeta()).toString());
				wr.write('\n');
				wr.write(transferClienteVip.getCorreo());
				wr.write('\n');
				wr.write(transferClienteVip.getNombre());
				wr.write('\n');
				wr.write(transferClienteVip.getDireccion());
				wr.write('\n');
				wr.write(((Integer)transferClienteVip.getTelefono()).toString());
				wr.write('\n');
				if(transferClienteVip.getActivo())
					wr.write("activo");
				else wr.write("inactivo");
			}
			else{ //Si no es VIP
				TransferClienteNormal transferClienteNormal = (TransferClienteNormal)tCliente;
				if(transferClienteNormal.getIntencionVIP())
					wr.write("si");
				else wr.write("no");
				wr.write('\n');
				wr.write(transferClienteNormal.getCorreo());
				wr.write('\n');
				wr.write(transferClienteNormal.getNombre());
				wr.write('\n');
				wr.write(transferClienteNormal.getDireccion());
				wr.write('\n');
				wr.write(((Integer)transferClienteNormal.getTelefono()).toString());
				wr.write('\n');

				if(transferClienteNormal.getActivo())
					wr.write("activo");
				else wr.write("inactivo");
			}

			wr.close();
			bw.close();

			aumentarNumArchivos(); //Esto tiene que estar dentro del try, si ha habido error no se tiene que aumentar
		}catch(IOException e){
		};

		return centinela;
	}



	public TCliente readById(int ID) {

		TCliente clienteLeido = null;
		FileReader f;
		Integer IDTemporal;
		String intencionVipOLimiteTarjeta;

		try{ //Abrimos el fichero al que le corresponde el ID
			f = new FileReader("Cliente\\" + Integer.toString(ID) + ".txt");
			BufferedReader br = new BufferedReader(f);

			IDTemporal = Integer.parseInt(br.readLine());

			intencionVipOLimiteTarjeta = br.readLine();


			if(intencionVipOLimiteTarjeta.equalsIgnoreCase("NO")){ //Si la primera l�nea es NO, creamos un cliente normal sin intenci�n de ser VIP
				TransferClienteNormal clienteNormal = new TransferClienteNormal();
				clienteNormal.setIntencionVIP(false);
				clienteLeido = clienteNormal;
			}

			else if (intencionVipOLimiteTarjeta.equalsIgnoreCase("SI")){//Si la primera l�nea es SI, creamos un cliente normal con intenci�n de ser VIP
				TransferClienteNormal clienteNormal = new TransferClienteNormal();
				clienteNormal.setIntencionVIP(true);
				clienteLeido = clienteNormal;
			}

			else { //Si no es ni SI ni NO, es una cantidad, as� que creamos un cliente VIP con el l�mite de la tarjeta
				TransferClienteVip clienteVIP = new TransferClienteVip();
				clienteVIP.setLimiteTarjeta(Integer.parseInt(intencionVipOLimiteTarjeta));
				clienteLeido = clienteVIP;
			}

			//Leemos el resto de datos
			clienteLeido.setID(IDTemporal);
			clienteLeido.setCorreo(br.readLine());
			clienteLeido.setNombre(br.readLine());
			clienteLeido.setDireccion(br.readLine());
			clienteLeido.setTelefono(Integer.parseInt(br.readLine()));
			String stringActivo = br.readLine();

			if(stringActivo.equalsIgnoreCase("ACTIVO"))
				clienteLeido.setActivo(true);
			else clienteLeido.setActivo(false);

			return clienteLeido;
		}
		catch (IOException e) {
			return null;
		}
	}




	public TCliente readByName(String correo) {
		int i = 1;

		while (i < leeNumArchivos()){
			if(readById(i).getCorreo().equalsIgnoreCase(correo)){
				return readById(i);
			}
			i++;
		}
		return null;
	}

	public TCliente muestraCliente(int ID) {

		return readById(ID);
	}

	public ArrayList<TCliente> muestraClientes() {
		int i = 1;
		int centinela = leeNumArchivos();
		ArrayList<TCliente> arrayClientes = new ArrayList<TCliente>();

		while(i < centinela){
			arrayClientes.add(readById(i));
			i++;
		}

		return arrayClientes;
	}

	public boolean eliminaCliente(int ID){
		System.out.println("Elimino");
		TCliente cliente = readById(ID);
		if(cliente != null && cliente.getActivo()){			
			cliente.setActivo(false);
			modificaCliente(cliente);
			return true;
		}
		else return false;
	}

	public boolean modificaCliente(TCliente tCliente) {
		File f;
		f = new File("Cliente\\" + tCliente.getID() + ".txt");
		//Escritura

		
			try{
				FileWriter w = new FileWriter(f);
				BufferedWriter bw = new BufferedWriter(w);
				PrintWriter wr = new PrintWriter(bw);
				wr.append(Integer.toString(tCliente.getID()));
				wr.append("\n");

				if(tCliente.getClass() == TransferClienteVip.class){ //Si es VIP
					TransferClienteVip transferCliente = (TransferClienteVip)tCliente;
					wr.append(Integer.toString(transferCliente.getLimiteTarjeta()));
					wr.append("\n");
					wr.append(transferCliente.getCorreo());
					wr.append("\n");
					wr.append(transferCliente.getNombre());
					wr.append("\n");
					wr.append(transferCliente.getDireccion());
					wr.append("\n");
					wr.append(Integer.toString(transferCliente.getTelefono()));
					wr.append("\n");
					if(transferCliente.getActivo() == true)
						wr.append("activo");
					else
						wr.append("inactivo");
				}
				else{ //Si es normal
					TransferClienteNormal transferCliente = (TransferClienteNormal)tCliente;
					if(transferCliente.getIntencionVIP() == true) wr.write("SI");
					else wr.write("NO");
					wr.append("\n");
					wr.append(transferCliente.getCorreo());
					wr.append("\n");
					wr.append(transferCliente.getNombre());
					wr.append("\n");
					wr.append(transferCliente.getDireccion());
					wr.append("\n");
					wr.append(Integer.toString(transferCliente.getTelefono()));
					wr.append("\n");
					if(transferCliente.getActivo() == true)
						wr.append("activo");
					else
						wr.append("inactivo");
				}
				wr.close();
				bw.close();

				return true;
			}
			catch(IOException e){
				return false;
			}
	}
}