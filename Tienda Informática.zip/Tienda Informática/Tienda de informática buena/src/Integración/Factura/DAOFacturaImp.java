/**
 * 
 */
package Integraci�n.Factura;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import Negocio.Marca.TransferMarca;
import Negocio.Factura.LineaFactura;
import Negocio.Factura.TransferFactura;
import java.util.ArrayList;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class DAOFacturaImp implements DAOFactura {
	


	public int readNumArchivos(){
		String cadena;
		FileReader f;
		try {
			f = new FileReader("Facturas\\" + CENTINELA_NUM_ARCHIVOS + ".txt"); //Si no existe, salta excepcion y pasa al catch
			BufferedReader br = new BufferedReader(f);
			cadena = br.readLine();
			f.close();
			return Integer.parseInt(cadena);
		} catch (IOException e) {
			File escribe = new File("Facturas"); //Si no existe la carpeta se crea
			if(!escribe.exists()) //Si el directorio no existe, lo crea
				escribe.mkdir();
			//Escritura inicial del int numArchivos
			try{
				FileWriter w = new FileWriter("Facturas\\" + CENTINELA_NUM_ARCHIVOS + ".txt");
				BufferedWriter bw = new BufferedWriter(w);
				PrintWriter wr = new PrintWriter(bw);	
				wr.write("1");
				wr.close();
				bw.close();
			}catch(IOException g){};
			return 1;
		}

	}

	public  void aumentarNumArchivos(){
		Integer centinela = readNumArchivos();
		File f;
		f = new File("Facturas/" +CENTINELA_NUM_ARCHIVOS + ".txt");
		//Escritura
		try{
			FileWriter w = new FileWriter(f);
			BufferedWriter bw = new BufferedWriter(w);
			PrintWriter wr = new PrintWriter(bw);	
			wr.write(Integer.toString(centinela + 1));
			wr.close();
			bw.close();
		}catch(IOException e){};
	}
	
	public int creaFactura(TransferFactura tFactura){
		int numArchivos = this.readNumArchivos();
		int id = numArchivos;
		
		int idCliente = tFactura.getIDCliente();
		@SuppressWarnings("unchecked")
		ArrayList<LineaFactura> array = tFactura.getProductos();
		String fecha = tFactura.getFecha();
		
		String ruta = "Facturas\\" + id + ".txt";
		File archivo = new File(ruta);
		//Escritura
		try{
		FileWriter w = new FileWriter(archivo);
		BufferedWriter bw = new BufferedWriter(w);
		PrintWriter wr = new PrintWriter(bw);	
		wr.write(fecha);
		wr.write("\n");
		wr.write(Integer.toString(idCliente));
		wr.write("\n");
		wr.write(Integer.toString(id));
			for(int i = 0; i < array.size(); i++){
				wr.write("\n");
				array.get(i);
				wr.write(Integer.toString(array.get(i).getID()));
				wr.write("\n");
				wr.write(Integer.toString(array.get(i).getCantidad()));
				wr.write("\n");
				wr.write(Float.toString(array.get(i).getPrecio())); //A�ADIR AQUI FUNCION PARA PONER PRECIO
			}
			
			wr.close();
			bw.close();
			
			this.aumentarNumArchivos();
			
			}catch (IOException e){
				id = -1;
				//e.printStackTrace();
			}
		 

		return id;
	}

	/** 
	 * (sin Javadoc)
	 * @throws IOException 
	 * @see DAOFactura#readById(Object Par�metro)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public TransferFactura readById(int idFactura){ //He quitado muestraFactura porque es exactamente lo mismo que este metodo
		TransferFactura factura = null;
		FileReader leerArchivoIDs = null;

		try{ //Abrimos el fichero al que le corresponde el ID
			leerArchivoIDs = new FileReader("Facturas\\" + idFactura + ".txt");
			BufferedReader br = new BufferedReader(leerArchivoIDs);
			String fecha = "";
			int idCliente = 0;
			factura = new TransferFactura(fecha, idCliente, idFactura);
			factura.setFecha(br.readLine()); //fecha
			factura.setIDCliente(Integer.parseInt(br.readLine()));
			factura.setIDFactura(Integer.parseInt(br.readLine()));
			ArrayList<LineaFactura> array = new ArrayList<LineaFactura>();
			int idLineaFactura = Integer.parseInt(br.readLine());	
			while (idLineaFactura != -1)   {
				LineaFactura linea = new LineaFactura();
				linea.setID(idLineaFactura);
				linea.setCantidad(Integer.parseInt(br.readLine()));
				linea.setPrecio(Float.parseFloat(br.readLine()));
				array.add(linea);
				factura.setProductos(array);
				idLineaFactura = Integer.parseInt(br.readLine());	
			}
		
		factura.setProductos(array);
		}
		catch(Exception e){
			//e.printStackTrace();
		}
		finally{
			if(leerArchivoIDs != null)
				try {
					leerArchivoIDs.close();
				} catch (Exception e) {
					//e.printStackTrace();
				}
		}

		return factura;
	}

	/** 
	 * (sin Javadoc)
	 * @see DAOFactura#readByName(String nombre)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	/*
	public TransferFactura readByName(String nombre) { //NO HACE FALTA UN READ_BY_NAME de facturas porque no tienen name
		int id = 0;
		int numArchivos = this.readNumArchivos(CENTINELA_NUM_ARCHIVOS);
		Boolean encontrado = false;
		
		do {
		//	readById(id)....
			id++;
		} while(!encontrado && id < numArchivos);
		
		return null;
		// end-user-code
	}
*/
	public ArrayList<TransferFactura> muestraFacturas() {
		int numArchivos = this.readNumArchivos();
		if(numArchivos <= 1)
			return null;
		ArrayList<TransferFactura> array = new ArrayList<TransferFactura>();
		
		
		for(int i = 1; i < numArchivos; i++){ //empezando la id desde 1 hasta numArchivos
			array.add(readById(i)); //desde id 1
		}	
		return array;
	}

	/** 
	 * (sin Javadoc)
	 * @see DAOFactura#eliminaFactura(int ID)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public boolean eliminaFactura(int ID) { //Tendr�a que ser baja l�gica
		return false; // tiene sentido eliminar una factura, o darla de baja logica??
	}

	/** 
	 * (sin Javadoc)
	 * @throws IOException 
	 * @see DAOFactura#modificaFactura(TransferMarca tMarca)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	@SuppressWarnings("unchecked")
	public boolean modificaFactura(TransferFactura tFactura){ //Deber�a capturar aqui la excepci�n, no debe petar todo el programa
		boolean ok = true;
		
		int idFacturaBuscada = tFactura.getIDFactura();
		TransferFactura tFacturaBuscada = readById(idFacturaBuscada);
		if(tFacturaBuscada == null)
			return false;
		
		int idFactura = tFactura.getIDFactura();
		int idCliente = tFactura.getIDCliente();
		ArrayList<LineaFactura> array = tFactura.getProductos();
		String fecha = tFactura.getFecha();
		String ruta = "Facturas\\" + idFactura + ".txt"; //ruta
		File archivo = new File(ruta);
		
		try{
			FileWriter w = new FileWriter(archivo);
			if(archivo.exists()) {
				BufferedWriter bw = new BufferedWriter(w);
				PrintWriter wr = new PrintWriter(bw);

				wr.write(fecha);
				wr.write("\n");
				wr.write(Integer.toString(idCliente));
				wr.write("\n");
				wr.write(Integer.toString(idFactura));
				for(int i = 0; i < array.size(); i++){
					wr.write("\n");
					array.get(i);
					wr.write(Integer.toString(array.get(i).getID()));
					wr.write("\n");
					wr.write(Integer.toString(array.get(i).getCantidad()));
					wr.write("\n");
					wr.write(Float.toString(array.get(i).getPrecio())); //A�ADIR AQUI FUNCION PARA PONER PRECIO
				}
				wr.close();
				bw.close();	
			} else {
				ok = false;
			}
		} catch (IOException e) {
			// TODO Bloque catch generado autom�ticamente
			//e.printStackTrace();
		}
		return ok;
	}




}