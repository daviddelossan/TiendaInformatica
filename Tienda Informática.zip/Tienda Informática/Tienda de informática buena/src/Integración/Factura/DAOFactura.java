/**
 * 
 */
package Integraci�n.Factura;

import Negocio.Factura.TransferFactura;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public interface DAOFactura {

	public static final int CENTINELA_NUM_ARCHIVOS = 0;

	
	public int creaFactura(TransferFactura tFactura);

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param Par�metro
	 * @return
	 * @throws FileNotFoundException 
	 * @throws IOException 
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public TransferFactura readById(int idFactura);

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param nombre
	 * @return
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	//public TransferFactura readByName(String nombre);
	//NO HACE FALTA UN READ_BY_NAME de facturas porque no tienen name
	
	
	public ArrayList<TransferFactura> muestraFacturas();

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ID
	 * @return
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public boolean eliminaFactura(int ID);

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param tMarca
	 * @return
	 * @throws IOException 
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public boolean modificaFactura(TransferFactura tFactura);

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param id
	 * @return
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int readNumArchivos();
}