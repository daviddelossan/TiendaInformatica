/**
 * 
 */
package Integraci�n.Proveedor;

import java.util.ArrayList;

import Negocio.Proveedor.TransferProveedor;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public interface DAOProveedor {

	boolean eliminaProveedor(Integer ID);
	public boolean modificaProveedor(TransferProveedor tProveedor);
	public TransferProveedor muestraProveedor(Integer ID);
	public ArrayList<TransferProveedor> muestraProveedor();
	public TransferProveedor readByName(String nombre);
	public TransferProveedor readById(Integer ID);
	int creaProveedor(TransferProveedor TProveedor);

}