/**
 * 
 */
package Integraci�n.Proveedor;

import java.io.File;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import Negocio.Proveedor.TransferProveedor;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class DAOProveedorImp implements DAOProveedor {


	private Integer leeNumArchivos(){
		String cadena;
		  FileReader f;
			try {
			  f = new FileReader("Proveedor\\NumArchivos.txt");	
		      BufferedReader br = new BufferedReader(f);
			  cadena = br.readLine();
			  return Integer.parseInt(cadena);
			} catch (IOException e) {
				//Si no existia crear 
				File escribe;
				escribe = new File("Proveedor");
				//Si el directorio no existe
				if(!escribe.exists())
					escribe.mkdir();
				escribe = new File("Proveedor\\NumArchivos.txt");
				//Escritura
				try{
				FileWriter w = new FileWriter(escribe);
				BufferedWriter bw = new BufferedWriter(w);
				PrintWriter wr = new PrintWriter(bw);	
				wr.write("1");
				wr.close();
				bw.close();
				}catch(IOException g){};
				return 1;
			}
		
		}

	public  void aumentarNumArchivos(){
		Integer centinela = leeNumArchivos();
		File f;
		f = new File("Proveedor\\NumArchivos.txt");
		//Escritura
		try{
		FileWriter w = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(w);
		PrintWriter wr = new PrintWriter(bw);	
		wr.write(Integer.toString(centinela + 1));
		wr.close();
		bw.close();
		}catch(IOException e){};
		}
		
	@Override
	public int creaProveedor(TransferProveedor TProveedor) {
		Integer centinela = leeNumArchivos();
		File f;
		f = new File("Proveedor\\" + Integer.toString(centinela) + ".txt");
		//Escritura
		try{
		FileWriter w = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(w);
		PrintWriter wr = new PrintWriter(bw);	
		wr.write(Integer.toString(centinela));
		wr.write('\n');
		wr.write(TProveedor.getNombre());
		wr.write('\n');
		if(TProveedor.getActivo() == true)
			wr.write("activo");
		else
			wr.write("inactivo");
		wr.close();
		bw.close();
		
		
		aumentarNumArchivos(); //Esto tiene que estar dentro del try, si ha habido error no se tiene que aumentar
		}catch(IOException e){
			
		};
		return centinela;
	}

	@Override
	public TransferProveedor readById(Integer ID) {
		TransferProveedor proveedor = new TransferProveedor();
		FileReader f;
		try {
		  f = new FileReader("Proveedor\\" + Integer.toString(ID) + ".txt");	
	      BufferedReader br = new BufferedReader(f);
	      	proveedor.setID(Integer.parseInt(br.readLine()));
	      	proveedor.setNombre( br.readLine());
	      	if(br.readLine().equalsIgnoreCase("activo"))
	      		proveedor.setActivo(true);
	      	else
	      		proveedor.setActivo(false);
			return proveedor;
		} catch (IOException e) {
			return null;
		}
	}

	@Override
	public TransferProveedor readByName(String nombre) {
		int i = 1;
		while (i < leeNumArchivos()){
			if(readById(i).getNombre().equalsIgnoreCase(nombre)){
				return readById(i);
			}
			i++;
		}
		return null;
	}

	@Override
	public TransferProveedor muestraProveedor(Integer ID) {
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return null;
	}

	@Override
	public ArrayList<TransferProveedor> muestraProveedor() {
		int i = 1;
		int centinela = leeNumArchivos();
		ArrayList<TransferProveedor> arrayMarcas = new ArrayList<TransferProveedor>();
		while(i < centinela){
			arrayMarcas.add(readById(i));
			i++;
		}
		return arrayMarcas;
	}

	@Override
	public boolean eliminaProveedor(Integer ID) {
			TransferProveedor proveedor = readById(ID);			
			if(proveedor != null && proveedor.getActivo())
			{
			 
				proveedor.setActivo(false);
				modificaProveedor(proveedor);
				return true;}
		
			
			else return false;
			
	}

	@Override
	public boolean modificaProveedor(TransferProveedor tProveedor) {
		Integer IDProveedor = tProveedor.getID();
		String nombre = tProveedor.getNombre();
		boolean activo = tProveedor.getActivo();
		File f;
		f = new File("Proveedor\\" + IDProveedor + ".txt");
		//Escritura
		try{
		FileWriter w = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(w);
		PrintWriter wr = new PrintWriter(bw);
		wr.write(Integer.toString(IDProveedor));
		wr.write('\n');
		wr.write(nombre);
		wr.write('\n');
		if(activo == true)
			wr.write("activo");
		else
			wr.write("inactivo");
		wr.close();
		bw.close();
		return true;
		}catch(IOException e){
			return false;
		}
		
	}

	

	
	
}