/**
 * 
 */
package Integraci�n.factoria;

import Integraci�n.Cliente.DAOCliente;
import Integraci�n.Cliente.DAOClienteImp;
import Integraci�n.Factura.DAOFactura;
import Integraci�n.Factura.DAOFacturaImp;
import Integraci�n.Marca.DAOMarca;
import Integraci�n.Marca.DAOMarcaImpl;
import Integraci�n.Producto.DAOProducto;
import Integraci�n.Producto.DAOProductoImp;
import Integraci�n.Proveedor.DAOProveedor;
import Integraci�n.Proveedor.DAOProveedorImp;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class FactDAOImpl extends FactDAO {

	@Override
	public DAOMarca generaDAOMarca() {
		return new DAOMarcaImpl();
	}

	@Override
	public DAOProveedor generaDAOProveedor() {
		return new DAOProveedorImp();
	}

	@Override
	public DAOCliente generaDAOCliente() {
		return new DAOClienteImp(); //Os lo he creado porque lo necesitaba para factura
	}

	@Override
	public DAOProducto generaDAOProducto() {
		return new DAOProductoImp(); //Os lo he creado porque lo necesitaba para factura
	}

	@Override
	public DAOFactura generaDAOFactura() {
		return new DAOFacturaImp();
	}
}