/**
 * 
 */
package Integraci�n.factoria;

import Integraci�n.Marca.DAOMarca;
import Integraci�n.Proveedor.DAOProveedor;
import Integraci�n.Cliente.DAOCliente;
import Integraci�n.Producto.DAOProducto;
import Integraci�n.Factura.DAOFactura;

public abstract class FactDAO {

	private static FactDAO instancia;
	
	public static FactDAO getInstancia() {
		if(instancia == null)
			instancia =	new FactDAOImpl();
		return instancia;
	}
	public abstract DAOMarca generaDAOMarca();
	public  abstract DAOProveedor generaDAOProveedor();
	public  abstract DAOCliente generaDAOCliente();
	public abstract DAOProducto generaDAOProducto();
	public abstract DAOFactura generaDAOFactura();
}