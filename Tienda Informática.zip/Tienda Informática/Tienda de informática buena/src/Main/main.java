package Main;

import Presentacion.FrameTienda.MainWindow;

public class main
{
	public static void main(String[] args)
	{
		java.awt.EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				new MainWindow();
			}
		});
	}
}