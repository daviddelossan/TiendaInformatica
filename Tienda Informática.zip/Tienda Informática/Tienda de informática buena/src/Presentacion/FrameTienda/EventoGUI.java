package Presentacion.FrameTienda;

public class EventoGUI {
	
	//Marca===============================
	public static final int ALTA_MARCA_OK = 101;
	public static final int ALTA_MARCA_ERROR = 102;
	public static final int BAJA_MARCA_OK = 103;
	public static final int BAJA_MARCA_ERROR = 104;
	public static final int MODIFICA_MARCA_OK = 105;
	public static final int MODIFICA_MARCA_ERROR = 106;
	public static final int MUESTRA_MARCA_OK = 107;
	public static final int MUESTRA_MARCA_ERROR = 108;
	public static final int MUESTRA_MARCA_TEXTFIELDS = 111;
	public static final int MUESTRA_TODOS_MARCA_OK = 109;
	public static final int MUESTRA_TODOS_MARCA_ERROR = 110;
	public static final int MUESTRA_MARCA_TEXTFIELDS_ERROR= 112;

	
	//Proveedor===============================
	public static final int ALTA_PROVEEDOR_OK = 301;
	public static final int ALTA_PROVEEDOR_ERROR = 302;
	public static final int BAJA_PROVEEDOR_OK = 303;
	public static final int BAJA_PROVEEDOR_ERROR = 30;
	public static final int MODIFICA_PROVEEDOR_OK = 305;
	public static final int MODIFICA_PROVEEDOR_ERROR = 306;
	public static final int MUESTRA_PROVEEDOR_OK = 307;
	public static final int MUESTRA_PROVEEDOR_ERROR = 308;
	public static final int MUESTRA_TODOS_PROVEEDOR_OK = 309;
	public static final int MUESTRA_TODOS_PROVEEDOR_ERROR = 310;
	public static final int MUESTRA_PROVEEDOR_TEXTFIELDS = 311;
	public static final int MUESTRA_PROVEEDOR_TEXTFIELDS_ERROR = 312;

	
	
	//PRODUCTO==================================================
	public static final int ALTA_PRODUCTO_OK = 201;
	public static final int ALTA_PRODUCTO_ERROR = 202;
	public static final int BAJA_PRODUCTO_OK = 203;
	public static final int BAJA_PRODUCTO_ERROR = 204;
	public static final int MODIFICA_PRODUCTO_OK = 205;
	public static final int MODIFICA_PRODUCTO_ERROR = 206;
	public static final int MUESTRA_PRODUCTO_OK = 207;
	public static final int MUESTRA_PRODUCTO_ERROR = 208;
	public static final int MUESTRA_TODOS_PRODUCTO_OK = 209;
	public static final int MUESTRA_TODOS_PRODUCTO_ERROR = 210;
	public static final int MUESTRA_PRODUCTO_TEXTFIELDS = 211;
	public static final int MUESTRA_PRODUCTO_TEXTFIELDS_ERROR = 212;
	
	
	//FACTURA======================================
	public static final int ALTA_CARRITO_OK = 501; //Empiezan por 5 porque factura es el modulo 5
	public static final int ALTA_CARRITO_ERROR = 502; //Empiezan por 5 porque factura es el modulo 5
	public static final int GENERA_FACTURA_OK = 503; //Empiezan por 5 porque factura es el modulo 5
	public static final int GENERA_FACTURA_ERROR = 504; //Empiezan por 5 porque factura es el modulo 5
	public static final int ANADIR_PRODUCTO_CARRITO_OK = 505;
	public static final int ANADIR_PRODUCTO_CARRITO_ERROR = 506;
	public static final int MUESTRA_FACTURAS_OK = 507;
	public static final int MUESTRA_FACTURAS_ERROR = 508;
	public static final int ELIMINAR_PRODUCTO_CARRITO_OK = 509;
	public static final int ELIMINAR_PRODUCTO_CARRITO_ERROR = 510;
	public static final int MUESTRA_FACTURA_OK = 511;
	public static final int MUESTRA_FACTURA_ERROR = 512;
	public static final int DEVOLUCION_OK = 513;
	public static final int DEVOLUCION_ERROR = 514;
	
	//CLIENTE======================================
	public static final int ALTA_CLIENTE_OK = 601;
	public static final int ALTA_CLIENTE_ERROR = 602;
	public static final int BAJA_CLIENTE_OK = 603;
	public static final int BAJA_CLIENTE_ERROR = 604;
	public static final int MODIFICA_CLIENTE_OK = 605;
	public static final int MODIFICA_CLIENTE_ERROR = 606;
	public static final int MUESTRA_CLIENTE_OK = 607;
	public static final int MUESTRA_CLIENTE_ERROR = 608;
	public static final int MUESTRA_TODOS_CLIENTE_OK = 609;
	public static final int MUESTRA_TODOS_CLIENTE_ERROR = 610;
	public static final int MUESTRA_CLIENTE_TEXTFIELDS = 611;
	public static final int MUESTRA_CLIENTE_TEXTFIELDS_ERROR = 612;
	
	

}
