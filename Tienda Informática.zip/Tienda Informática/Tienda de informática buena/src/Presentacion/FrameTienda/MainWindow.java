package Presentacion.FrameTienda;

import Presentacion.Cliente.JFrameCliente;
import Presentacion.Factura.JFrameFactura;
import Presentacion.Marca.JFrameMarca;
import Presentacion.Producto.JFrameProducto;
import Presentacion.Proveedor.JFrameProveedor;
import Presentacion.controlador.Controlador;

public class MainWindow {
	private JFrameFactura frameFactura;
	private JFrameProducto frameProducto;
	private JFrameProveedor frameProveedor;
	private JFrameMarca frameMarca;
	private JFrameCliente frameCliente;
	
	public MainWindow (){
		this.frameFactura = new JFrameFactura();
		this.frameProducto = new JFrameProducto();
		this.frameProveedor = new JFrameProveedor();
		this.frameMarca = new JFrameMarca();
		this.frameCliente = new JFrameCliente();
		
		this.frameFactura.setVisible(true);
		this.frameCliente.setVisible(true);
		this.frameMarca.setVisible(true);
		this.frameProducto.setVisible(true);
		this.frameProveedor.setVisible(true);
		Controlador.creaControlador(this);
	}
	
	
	public JFrameFactura getFrameFactura(){
		return this.frameFactura;
	}
	
	public JFrameProducto getFrameProducto(){
		return this.frameProducto;
	}
	
	public JFrameProveedor getFrameProveedor(){
		return this.frameProveedor;
	}
	
	public JFrameMarca getFrameMarca(){
		return this.frameMarca;
	}
	
	public JFrameCliente getFrameCliente(){
		return this.frameCliente;
	}

}
