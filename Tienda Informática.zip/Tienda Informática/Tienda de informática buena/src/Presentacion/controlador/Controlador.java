/**
 * 
 */
package Presentacion.controlador;

import Presentacion.FrameTienda.MainWindow;


/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public abstract class Controlador {
	private static Controlador instancia;

	public static Controlador getInstancia() {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		if(instancia == null)
			instancia =	new ControladorImp();
		return instancia;
		// end-user-code
	}
	public static Controlador creaControlador(MainWindow window){
		instancia = new ControladorImp(window);
		return instancia;
	}
	public abstract void accion(int evento, java.lang.Object datos);
	
}