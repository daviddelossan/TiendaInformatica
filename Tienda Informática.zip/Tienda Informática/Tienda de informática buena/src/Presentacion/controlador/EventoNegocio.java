package Presentacion.controlador;

public class EventoNegocio {

	//MARCA=======================================
	public static final int ALTA_MARCA = 1;
	public static final int BAJA_MARCA = 2;
	public static final int MODIFICA_MARCA = 3;
	public static final int MUESTRA_MARCA = 4;
	public static final int MUESTRA_TODAS_MARCAS = 5;
	public static final int MUESTRA_MARCA_GUI = 6;

	//PRODUCTO=======================================
	public static final int ALTA_PRODUCTO = 201;
	public static final int BAJA_PRODUCTO = 202;
	public static final int MODIFICA_PRODUCTO = 203;
	public static final int MUESTRA_PRODUCTO = 204;
	public static final int MUESTRA_TODOS_PRODUCTO = 205;
	public static final int MUESTRA_PRODUCTO_GUI = 206;

	//PROVEEDOR======================================
	public static final int ALTA_PROVEEDOR = 301;
	public static final int BAJA_PROVEEDOR = 302;
	public static final int MODIFICA_PROVEEDOR= 303;
	public static final int MUESTRA_PROVEEDOR = 304;
	public static final int MUESTRA_TODOS_PROVEEDOR = 305;
	public static final int MUESTRA_PROVEEDOR_GUI = 306;
	//FACTURA======================================
	public static final int MUESTRA_FACTURA = 504;
	public static final int MUESTRA_FACTURAS = 505;
	public static final int DEVOLUCION_FACTURA = 506;
	public static final int GENERA_FACTURA = 507;
	
	//CLIENTE======================================
	public static final int ALTA_CLIENTE = 601;
	public static final int BAJA_CLIENTE = 602;
	public static final int MODIFICA_CLIENTE= 603;
	public static final int MUESTRA_CLIENTE = 604;
	public static final int MUESTRA_TODOS_CLIENTE = 605;
	public static final int MUESTRA_CLIENTE_GUI = 606;
	
	
	

	
}
