/**
 * 
 */
package Presentacion.controlador;

import java.util.ArrayList;

import Negocio.Cliente.SACliente;
import Negocio.Cliente.TCliente;
import Negocio.Factoria.FactoriaSA;
import Negocio.Factura.SAFactura;
import Negocio.Factura.TransferFactura;
import Negocio.Marca.TransferMarca;
import Negocio.Producto.SAProducto;
import Negocio.Producto.TransferProducto;
import Negocio.Proveedor.SAProveedor;
import Negocio.Proveedor.TransferProveedor;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.FrameTienda.MainWindow;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class ControladorImp extends Controlador {

	//private JFrameMarca frameMarca;
	private MainWindow window;
	
	
		public ControladorImp(){
			
		}
		public ControladorImp(MainWindow window){
			this.window = window;
		}
	@Override
	public void accion(int evento, Object datos) {
		
		switch(evento){
		
		//MARCA=======================================
		case EventoNegocio.ALTA_MARCA: {
			FactoriaSA sa= FactoriaSA.getInstancia();
			if( sa.generaSAMarca().altaMarca((TransferMarca)datos)!= -1){
				window.getFrameMarca().update(EventoGUI.ALTA_MARCA_OK, null);
			}
			else{
				window.getFrameMarca().update(EventoGUI.ALTA_MARCA_ERROR, null);
			}
		};break;
		
		case EventoNegocio.BAJA_MARCA:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			if(sa.generaSAMarca().bajaMarca((Integer)datos)!= false)
				window.getFrameMarca().update(EventoGUI.BAJA_MARCA_OK, null);
			else{
				///Si no existe la marca
				if(sa.generaSAMarca().muestraMarca((Integer)datos)== null)
					window.getFrameMarca().update(EventoGUI.MUESTRA_MARCA_ERROR,null);
					//Si ya esta dada de baja
				else
					window.getFrameMarca().update(EventoGUI.BAJA_MARCA_ERROR, null);}
		};break;
		
		case EventoNegocio.MODIFICA_MARCA:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			if(sa.generaSAMarca().modificaMarca((TransferMarca)datos)!= false)
				window.getFrameMarca().update(EventoGUI.MODIFICA_MARCA_OK, null);
			else
				window.getFrameMarca().update(EventoGUI.MODIFICA_MARCA_ERROR, null);
		};break;
	
		case EventoNegocio.MUESTRA_MARCA:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			TransferMarca marca = sa.generaSAMarca().muestraMarca((Integer)datos);
			if(marca == null)
				window.getFrameMarca().update(EventoGUI.MUESTRA_MARCA_ERROR, null);
			else
			{
				window.getFrameMarca().update(EventoGUI.MUESTRA_MARCA_OK, marca);		
			}
		};break;
		
		case EventoNegocio.MUESTRA_TODAS_MARCAS:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			ArrayList<TransferMarca> marcas = sa.generaSAMarca().muestraMarcas();
			//Si al menos contiene una marca
			if(marcas.size() != 0)
				window.getFrameMarca().update(EventoGUI.MUESTRA_TODOS_MARCA_OK, marcas);
			else
			{		
				window.getFrameMarca().update(EventoGUI.MUESTRA_TODOS_MARCA_ERROR, null);
			}
		};break;
		
		case EventoNegocio.MUESTRA_MARCA_GUI:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			TransferMarca marca = sa.generaSAMarca().muestraMarca((Integer)datos);
			if(marca == null)
				window.getFrameMarca().update(EventoGUI.MUESTRA_MARCA_ERROR, null);
			else
			{
				if( !marca.getActivo())
				window.getFrameMarca().update(EventoGUI.MUESTRA_MARCA_TEXTFIELDS_ERROR, null);
			else
			window.getFrameMarca().update(EventoGUI.MUESTRA_MARCA_TEXTFIELDS, marca);	
			}
		};break;
		
		
		
		
		//FACTURA======================================
		case EventoNegocio.MUESTRA_FACTURA:{
			SAFactura saFactura = FactoriaSA.getInstancia().generaSAFactura();
			int idFactura = (Integer)datos;
			TransferFactura tFactura = saFactura.muestraFactura(idFactura);
			if(tFactura != null)
				window.getFrameFactura().update(EventoGUI.MUESTRA_FACTURA_OK, tFactura);
			else
				window.getFrameFactura().update(EventoGUI.MUESTRA_FACTURA_ERROR, idFactura);
			break;
		}
		
		case EventoNegocio.MUESTRA_FACTURAS:{
			SAFactura saFactura = FactoriaSA.getInstancia().generaSAFactura();	
			ArrayList<TransferFactura> todasFacturas = saFactura.muestraFacturas();
			if(todasFacturas != null)
				window.getFrameFactura().update(EventoGUI.MUESTRA_FACTURAS_OK, todasFacturas);
			else
				window.getFrameFactura().update(EventoGUI.MUESTRA_FACTURAS_ERROR, null);
			break;
		}
		case EventoNegocio.GENERA_FACTURA:{
			SAFactura saFactura = FactoriaSA.getInstancia().generaSAFactura();
			TransferFactura tFactura = (TransferFactura)datos;
			int id = -1;
			if(tFactura != null)
				id = saFactura.generaFactura(tFactura);
			if(id != -1)
				window.getFrameFactura().update(EventoGUI.GENERA_FACTURA_OK, id);
			else
				window.getFrameFactura().update(EventoGUI.GENERA_FACTURA_ERROR, null);
			break;
		}
		case EventoNegocio.DEVOLUCION_FACTURA:{
			SAFactura saFactura = FactoriaSA.getInstancia().generaSAFactura();
			@SuppressWarnings("unchecked")
			ArrayList<Object> arrayTransfers = (ArrayList<Object>)datos;
			int idFactura = (Integer)arrayTransfers.get(0);
			int idProducto =  (Integer)arrayTransfers.get(1);
			int unidades = (Integer)arrayTransfers.get(2);
			boolean ok = saFactura.devolucion(idFactura, idProducto, unidades);
			if(ok)
				window.getFrameFactura().update(EventoGUI.DEVOLUCION_OK, idFactura);
			else
				window.getFrameFactura().update(EventoGUI.DEVOLUCION_ERROR, idFactura);
			break;
		}
		//PRODUCTO=======================================
		case EventoNegocio.ALTA_PRODUCTO: {
			SAProducto saProducto = FactoriaSA.getInstancia().generaSAProducto();
			TransferProducto tProducto = (TransferProducto)datos;
			int nuevoId = saProducto.altaProducto(tProducto);
			
			System.out.println(nuevoId);
			
			if(nuevoId != -1)
				window.getFrameProducto().update(EventoGUI.ALTA_PRODUCTO_OK, nuevoId);
			else
				window.getFrameProducto().update(EventoGUI.ALTA_PRODUCTO_ERROR, tProducto.getID());
				
			break;
		}
		case EventoNegocio.BAJA_PRODUCTO: {
			SAProducto saProducto = FactoriaSA.getInstancia().generaSAProducto();
			int idProducto = (Integer)datos;
			Boolean exito = saProducto.bajaProducto(idProducto);
			
			if(exito)
				window.getFrameProducto().update(EventoGUI.BAJA_PRODUCTO_OK, idProducto);
			else
				window.getFrameProducto().update(EventoGUI.BAJA_PRODUCTO_ERROR, null);
			
			break;
		}

		case EventoNegocio.MODIFICA_PRODUCTO:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			if(sa.generaSAProducto().modificaProducto((TransferProducto)datos)!= false)
				window.getFrameProducto().update(EventoGUI.MODIFICA_PRODUCTO_OK, null);
			else
				window.getFrameProducto().update(EventoGUI.MODIFICA_PRODUCTO_ERROR, null);
		};break;
	
		case EventoNegocio.MUESTRA_PRODUCTO: {
			SAProducto saProducto = FactoriaSA.getInstancia().generaSAProducto();
			int idProducto = (Integer)(datos);
			TransferProducto tProducto = saProducto.muestraProducto(idProducto);

			if(tProducto != null)
				window.getFrameProducto().update(EventoGUI.MUESTRA_PRODUCTO_OK, tProducto);
			else
				window.getFrameProducto().update(EventoGUI.MUESTRA_PRODUCTO_ERROR, idProducto);

			break;
		}
		case EventoNegocio.MUESTRA_TODOS_PRODUCTO: {
			SAProducto saProducto = FactoriaSA.getInstancia().generaSAProducto();
			ArrayList<TransferProducto> array = saProducto.muestraProductos();

			if(array != null)
				window.getFrameProducto().update(EventoGUI.MUESTRA_TODOS_PRODUCTO_OK, array);
			else
				window.getFrameProducto().update(EventoGUI.MUESTRA_TODOS_PRODUCTO_ERROR, null);


			break;
		}
		case EventoNegocio.MUESTRA_PRODUCTO_GUI:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			TransferProducto producto = sa.generaSAProducto().muestraProducto((Integer)datos);
			if(producto == null)
				window.getFrameProducto().update(EventoGUI.MUESTRA_PRODUCTO_ERROR, null);
			else
			{
				if( !producto.getActivo())
				window.getFrameProducto().update(EventoGUI.MUESTRA_PRODUCTO_TEXTFIELDS_ERROR, null);
			else
			window.getFrameProducto().update(EventoGUI.MUESTRA_PRODUCTO_TEXTFIELDS, producto);	
			}
		};break;
		//PROVEEDOR=======================================
		case EventoNegocio.ALTA_PROVEEDOR: {
			SAProveedor saProveedor = FactoriaSA.getInstancia().generaSAProveedor();
			TransferProveedor tProveedor = (TransferProveedor)datos;
			int exito = saProveedor.altaProveedor(tProveedor);
			
			System.out.println(window.getClass());
			
			if(exito != -1)
				window.getFrameProveedor().update(EventoGUI.ALTA_PROVEEDOR_OK, tProveedor.getID());
			else{
				System.out.println("error");
				window.getFrameProveedor().update(EventoGUI.ALTA_PROVEEDOR_ERROR, tProveedor.getID());
				}
			
			break;
		}
		
		case EventoNegocio.BAJA_PROVEEDOR: {
			SAProveedor saProveedor = FactoriaSA.getInstancia().generaSAProveedor();
			Boolean exito = saProveedor.bajaProveedor((Integer) datos);
			
			if(exito)
				window.getFrameProveedor().update(EventoGUI.BAJA_PROVEEDOR_OK,null);
			else{
				System.out.println();
				if(saProveedor.muestraProveedor((Integer)datos)== null)
					window.getFrameProveedor().update(EventoGUI.MUESTRA_PROVEEDOR_ERROR,null);
					//Si ya esta dada de baja
				else
				window.getFrameProveedor().update(EventoGUI.BAJA_PROVEEDOR_ERROR, null);
			}
			break;
		}
		
		case EventoNegocio.MODIFICA_PROVEEDOR:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			if(sa.generaSAProveedor().modificaProveedor((TransferProveedor) datos)!= false)
				window.getFrameProveedor().update(EventoGUI.MODIFICA_PROVEEDOR_OK,null);
			else
				window.getFrameProveedor().update(EventoGUI.MODIFICA_PROVEEDOR_ERROR,null);
		
		break;
		}
		
		case EventoNegocio.MUESTRA_PROVEEDOR: {
			SAProveedor saProveedor = FactoriaSA.getInstancia().generaSAProveedor();
			int idProveedor = (Integer)(datos);
			TransferProveedor tProveedor = saProveedor.muestraProveedor(idProveedor);

			if(tProveedor != null)
				window.getFrameProveedor().update(EventoGUI.MUESTRA_PROVEEDOR_OK, tProveedor);
			else
				window.getFrameProveedor().update(EventoGUI.MUESTRA_PROVEEDOR_ERROR, idProveedor);

			break;
		}
		
		case EventoNegocio.MUESTRA_TODOS_PROVEEDOR: {
			SAProveedor saProveedor = FactoriaSA.getInstancia().generaSAProveedor();
			ArrayList<TransferProveedor> array = saProveedor.muestraProveedores();

			if(array.size() != 0)
				window.getFrameProveedor().update(EventoGUI.MUESTRA_TODOS_PROVEEDOR_OK, array);
			else
				window.getFrameProveedor().update(EventoGUI.MUESTRA_TODOS_PROVEEDOR_ERROR, null);


			break;
		}
		
		case EventoNegocio.MUESTRA_PROVEEDOR_GUI:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			TransferProveedor proveedor = sa.generaSAProveedor().muestraProveedor((Integer)datos);
			if(proveedor == null)
				window.getFrameProveedor().update(EventoGUI.MUESTRA_PROVEEDOR_ERROR, null);
			
			else
			{
				if( !proveedor.getActivo())
					window.getFrameProveedor().update(EventoGUI.MUESTRA_PROVEEDOR_TEXTFIELDS_ERROR, null);
				else
				window.getFrameProveedor().update(EventoGUI.MUESTRA_PROVEEDOR_TEXTFIELDS, proveedor);		
			}
			break;
		}
		
		//CLIENTE=======================================
		
		case EventoNegocio.ALTA_CLIENTE: {
			SACliente saCliente = FactoriaSA.getInstancia().generaSACliente();
			TCliente tCliente = (TCliente)datos;
			int exito = saCliente.altaCliente(tCliente);
			
			System.out.println(window.getClass());

			if(exito != -1)
				window.getFrameCliente().update(EventoGUI.ALTA_CLIENTE_OK, tCliente.getID());
			else
				window.getFrameCliente().update(EventoGUI.ALTA_CLIENTE_ERROR, tCliente.getID());


			break;
		}
		case EventoNegocio.BAJA_CLIENTE: {
			FactoriaSA sa = FactoriaSA.getInstancia();
			if(sa.generaSACliente().bajaCliente((Integer)datos)!= false)
				window.getFrameCliente().update(EventoGUI.BAJA_CLIENTE_OK, null);
			else
				window.getFrameCliente().update(EventoGUI.BAJA_CLIENTE_ERROR, null);
			break;
		}
		
		case EventoNegocio.MODIFICA_CLIENTE:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			if(sa.generaSACliente().modificaCliente((TCliente) datos)!= false)
				window.getFrameCliente().update(EventoGUI.MODIFICA_CLIENTE_OK,null);
			else
				window.getFrameCliente().update(EventoGUI.MODIFICA_CLIENTE_ERROR,null);
		break;
		}
		
		case EventoNegocio.MUESTRA_CLIENTE: {
			SACliente saCliente = FactoriaSA.getInstancia().generaSACliente();
			int idCliente = (Integer)(datos);
			TCliente tCliente = saCliente.muestraCliente(idCliente);

			if(tCliente != null)
				window.getFrameCliente().update(EventoGUI.MUESTRA_CLIENTE_OK, tCliente);
			else
				window.getFrameCliente().update(EventoGUI.MUESTRA_CLIENTE_ERROR, idCliente);

			break;
		}
		
		case EventoNegocio.MUESTRA_TODOS_CLIENTE: {
			SACliente saCliente = FactoriaSA.getInstancia().generaSACliente();
			ArrayList<TCliente> array = saCliente.muestraClientes();

			if(array.size() != 0)
				window.getFrameCliente().update(EventoGUI.MUESTRA_TODOS_CLIENTE_OK, array);
			else
				window.getFrameCliente().update(EventoGUI.MUESTRA_TODOS_CLIENTE_ERROR, null);


			break;
		}
		
		case EventoNegocio.MUESTRA_CLIENTE_GUI:{
			FactoriaSA sa = FactoriaSA.getInstancia();
			TCliente tCliente = sa.generaSACliente().muestraCliente((Integer)datos);
			if(tCliente == null)
				window.getFrameCliente().update(EventoGUI.MODIFICA_CLIENTE_ERROR, null);
			
			else
			{
				if( !tCliente.getActivo())
					window.getFrameCliente().update(EventoGUI.MUESTRA_CLIENTE_TEXTFIELDS_ERROR, null);
				else
				window.getFrameCliente().update(EventoGUI.MUESTRA_CLIENTE_TEXTFIELDS, tCliente);		
			}
			break;
		}
		default: {
			break;
		}
		
		}//FIN SWITCH
		
	}//FIN M�TODO accion()
	
} //FIN Clase ControladorImp