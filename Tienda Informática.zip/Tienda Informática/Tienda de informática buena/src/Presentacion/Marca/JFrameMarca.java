

package Presentacion.Marca;


import java.util.ArrayList;

import javax.swing.JOptionPane;

import Negocio.Marca.TransferMarca;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.Controlador;
import Presentacion.controlador.EventoNegocio;

/**
 *
 * @author usuario_local
 */
public class JFrameMarca extends javax.swing.JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1185784134696728177L;
	/**
     * Creates new form TiendaBuenaJFrame
     */
    public JFrameMarca() {
        super("MARCA");
        initComponents();
    }
           
    private void initComponents() {

        JPanelMarca = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        nombreMarca = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        comboBoxMarca = new javax.swing.JComboBox();
        OKMarca = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaMarca = new javax.swing.JTextArea();
        IDMarca = new javax.swing.JTextField();
        Modifica = new javax.swing.JButton();


        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("NOMBRE:");

      

        jLabel2.setText("ID Marca:");

        comboBoxMarca.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "ALTA", "BAJA", "MODIFICA", "MUESTRA", "MUESTRA TODO" }));
        comboBoxMarca.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                jComboBox1ComponentAdded(evt);
            }
        });
        comboBoxMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        OKMarca.setText("OK");
        OKMarca.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OKMarcaMouseClicked(evt);

            }
        });
        
        Modifica.setText("MODIFICA");
        Modifica.setVisible(false);
        Modifica.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ModificaMouseClicked(evt);

            }
        });
        areaMarca.setColumns(20);
        areaMarca.setRows(5);
        jScrollPane1.setViewportView(areaMarca);

        IDMarca.setEnabled(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(JPanelMarca);
        JPanelMarca.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboBoxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(IDMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(OKMarca)
                                .addComponent(Modifica)
)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nombreMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(133, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(comboBoxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(nombreMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(OKMarca)
                     .addComponent(Modifica)

                    .addComponent(IDMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(71, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(JPanelMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(JPanelMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>                        


    private void jComboBox1ComponentAdded(java.awt.event.ContainerEvent evt) {                                          
        // TODO add your handling code here:
    }                                         

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
        String opcion = comboBoxMarca.getSelectedItem().toString();
        Modifica.setVisible(false);
        if(opcion.equals("ALTA")){
            nombreMarca.setEnabled(true);
            IDMarca.setEnabled(false);
        }
        if(opcion.equals("BAJA")){
            nombreMarca.setEnabled(false);
            IDMarca.setEnabled(true);
        }
        if(opcion.equals("MODIFICA")){
        	Modifica.setVisible(true);
            Modifica.setEnabled(false);
            nombreMarca.setEnabled(false);
            IDMarca.setEnabled(true);
        }
        if(opcion.equals("MUESTRA")){
            nombreMarca.setEnabled(false);
            IDMarca.setEnabled(true);
        }
        if(opcion.equals("MUESTRA TODO")){
            Modifica.setVisible(false);
            nombreMarca.setEnabled(false);
            IDMarca.setEnabled(false);
        }
      	reiniciaComponentes();
    }                                          

    private void ModificaMouseClicked(java.awt.event.MouseEvent evt) {
       TransferMarca marca = new TransferMarca();
       marca.setNombre(nombreMarca.getText());
       marca.setID(Integer.parseInt(IDMarca.getText()));
       marca.setActivo(estado);
       Controlador.getInstancia().accion(EventoNegocio.MODIFICA_MARCA,marca);
       reiniciaComponentes();
       OKMarca.setEnabled(true);
       IDMarca.setEnabled(true);
       nombreMarca.setEnabled(false);
       Modifica.setEnabled(false);
       comboBoxMarca.setEnabled(true);
      }    
    private void OKMarcaMouseClicked(java.awt.event.MouseEvent evt) {                                       
        String opcion = comboBoxMarca.getSelectedItem().toString();

        OKMarca.setEnabled(true);
        if(opcion.equals("ALTA")){
        	 TransferMarca marca = new TransferMarca(nombreMarca.getText());
        	 Controlador.getInstancia().accion(EventoNegocio.ALTA_MARCA,marca);

         }
        if(opcion.equals("BAJA")){
        	Integer id = Integer.parseInt(IDMarca.getText());
        	Controlador.getInstancia().accion(EventoNegocio.BAJA_MARCA, id);
        }
        
        if(opcion.equals("MUESTRA")){
        	Integer id = Integer.parseInt(IDMarca.getText());
        	Controlador.getInstancia().accion(EventoNegocio.MUESTRA_MARCA, id);	
        }
        if(opcion.equals("MODIFICA")){
        	Integer id = Integer.parseInt(IDMarca.getText());
        	Controlador.getInstancia().accion(EventoNegocio.MUESTRA_MARCA_GUI, id);	
      
        }
        
        if(opcion.equals("MUESTRA TODO")){
        	Controlador.getInstancia().accion(EventoNegocio.MUESTRA_TODAS_MARCAS, null);
        }
      }    

    private void reiniciaComponentes(){
    	IDMarca.setText("");
    	nombreMarca.setText("");
    	areaMarca.setText("");

    }
 
    private void actualiza(){
   	 javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(JPanelMarca);
        JPanelMarca.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboBoxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(IDMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(OKMarca)              
                                .addComponent(Modifica)
                            )
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nombreMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(133, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(comboBoxMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(nombreMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(OKMarca)
                    .addComponent(Modifica)
                    .addComponent(IDMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(71, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(JPanelMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(JPanelMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

   }
  
    public  void update(int evento, Object datos) {

    	switch(evento){
    	case EventoGUI.ALTA_MARCA_OK:{JOptionPane.showMessageDialog(null,
				   "Marca dada de alta correctamente", 
				    "OK", 			
				    JOptionPane.PLAIN_MESSAGE);
    	};break;
    	
    	case EventoGUI.ALTA_MARCA_ERROR:{
    		JOptionPane.showMessageDialog(null,
    				 "No se pudo dar de alta, ya existe una marca con ese nombre",   			 	
    				    "ERROR", //T�tulo
    				    JOptionPane.ERROR_MESSAGE);
    		};break;
    	
    	case EventoGUI.BAJA_MARCA_OK:{JOptionPane.showMessageDialog(null,
				   "Marca dada de baja correctamente", //Mensaje
				    "OK", //T�tulo			
				    JOptionPane.PLAIN_MESSAGE);
    	};break;
    	
    	case EventoGUI.BAJA_MARCA_ERROR:{
    		JOptionPane.showMessageDialog(null,
   				 "No se pudo dar de baja,el elemento ya esta dado de baja", //Mensaje  				
   				    "ERROR", //T�tulo
   				    JOptionPane.ERROR_MESSAGE);
    	};break;
    	
    	case EventoGUI.MUESTRA_MARCA_OK:{
    		StringBuffer cadena = new StringBuffer();
    		TransferMarca marca = (TransferMarca)datos;
    		cadena.append("---------Marca " + Integer.toString(marca.getID())+"---------");
    		cadena.append('\n');
    		cadena.append("Nombre: " + marca.getNombre());
    		cadena.append('\n');
    		cadena.append("Num productos: " + marca.getNumProductos());
    		cadena.append('\n');
    		cadena.append("Estado: ");
    		if(marca.getActivo())
    			cadena.append("activo");
    		else
    			cadena.append("inactivo");
    		areaMarca.setText(cadena.toString());
    		};break;
    		
    	case EventoGUI.MUESTRA_MARCA_ERROR:{
    		JOptionPane.showMessageDialog(null,
      				 "No existe la marca", //Mensaje  				
      				    "ERROR", //T�tulo
      				    JOptionPane.ERROR_MESSAGE);
    	};break;
    	
    	case EventoGUI.MUESTRA_TODOS_MARCA_OK:{
    		@SuppressWarnings("unchecked")
			ArrayList<TransferMarca> array = (ArrayList<TransferMarca>)datos;
    		StringBuffer cadena = new StringBuffer();
    		for(int i = 0; i < array.size(); i++){
    			TransferMarca marca = array.get(i);
    			cadena.append("---------Marca " + Integer.toString(marca.getID())+"---------");
        		cadena.append('\n');
        		cadena.append("Nombre: " + marca.getNombre());
        		cadena.append('\n');
        		cadena.append("Num productos: " + marca.getNumProductos());
        		cadena.append('\n');
        		cadena.append("Estado: ");
        		if(marca.getActivo())
        			cadena.append("activo");
        		else
        			cadena.append("inactivo");
        		cadena.append('\n');
        		cadena.append('\n');

    		}
    		areaMarca.setText(cadena.toString());
    		};break;
    		
    	case EventoGUI.MUESTRA_TODOS_MARCA_ERROR:{JOptionPane.showMessageDialog(null,
				 	"No existen marcas", //Mensaje  				
				    "ERROR", //T�tulo
				    JOptionPane.ERROR_MESSAGE);
    	};break;
    	
    	case EventoGUI.MUESTRA_MARCA_TEXTFIELDS:{
    		TransferMarca marca = (TransferMarca)datos;
    		estado = marca.getActivo();
    		nombreMarca.setText(marca.getNombre());
    	  	IDMarca.setEnabled(false);
        	nombreMarca.setEnabled(true);
        	Modifica.setEnabled(true);
        	OKMarca.setEnabled(false);
        	comboBoxMarca.setEnabled(false);
    	};break;
    	

    	case EventoGUI.MUESTRA_MARCA_TEXTFIELDS_ERROR:{
    		JOptionPane.showMessageDialog(null,
    				 "La marca esta dada de baja", //Mensaje  				
    				    "ERROR", //T�tulo
    				    JOptionPane.ERROR_MESSAGE);
    	};break;
    	
    	case EventoGUI.MODIFICA_MARCA_OK:{
    		JOptionPane.showMessageDialog(null,
 				   "Marca actualizada", //Mensaje
 				    "OK", //T�tulo			
 				    JOptionPane.PLAIN_MESSAGE);
    	};break;
  
    	case EventoGUI.MODIFICA_MARCA_ERROR:{
    		JOptionPane.showMessageDialog(null,
    				 "Yo existe una marca con ese nombre", //Mensaje  				
    				    "ERROR", //T�tulo
    				    JOptionPane.ERROR_MESSAGE);
    		};break;
    	}
    	
    	actualiza();
    	
    }
                                 

    
    private javax.swing.JTextField IDMarca;
    private javax.swing.JButton OKMarca;
    private javax.swing.JButton Modifica;

    private javax.swing.JComboBox comboBoxMarca;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel JPanelMarca;
    private javax.swing.JScrollPane jScrollPane1;
    private  javax.swing.JTextArea areaMarca;
    private javax.swing.JTextField nombreMarca;
    private boolean estado;
    // End of variables declaration                   
}
