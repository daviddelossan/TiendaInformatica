/**
 * 
 */
package Presentacion.Factura;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class ActionListenerImp implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Ap�ndice de m�todo generado autom�ticamente
		
	}
	
}