/**
 * 
 */
package Presentacion.Cliente;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class ActionListenerImp implements ActionListener {

	public void actionPerformed(ActionEvent arg0) {

	}
}