/**
 * 
 */
package Negocio.Proveedor;

import java.util.ArrayList;


import Integraci�n.Proveedor.DAOProveedor;
import Integraci�n.factoria.FactDAO;


/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SAProveedorImp implements SAProveedor {
	/** 
	 * (sin Javadoc)
	 * @see SAProveedor#altaProveedor(TransferProveedor TProveedor)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int altaProveedor(TransferProveedor TProveedor) {
		int id = -1;
		DAOProveedor dao = FactDAO.getInstancia().generaDAOProveedor();
		//SI existe un archivo que se llama asi
		if(TProveedor != null){
			if (TProveedor.getNombre().equalsIgnoreCase(""))
				return -1;
			TransferProveedor esta = dao.readByName(TProveedor.getNombre());
			if(esta == null)
				id = dao.creaProveedor(TProveedor);
			
			else{
				if(!esta.getActivo()){
					esta.setActivo(true);
					dao.modificaProveedor(esta);
					return esta.getID();
				}
				else return -1;
			}
			
			}
		return id;
	}

	/** 
	 * (sin Javadoc)
	 * @see SAProveedor#bajaProveedor(int ID)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean bajaProveedor(int ID) {
	DAOProveedor dao = FactDAO.getInstancia().generaDAOProveedor();
		if (dao.eliminaProveedor(ID))
			return true;

		else
			return false;
	}

	/** 
	 * (sin Javadoc)
	 * @see SAProveedor#muestraProveedor(int ID)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public TransferProveedor muestraProveedor(int ID) {
		DAOProveedor dao = FactDAO.getInstancia().generaDAOProveedor();
		return dao.readById(ID);
		
	}

	/** 
	 * (sin Javadoc)
	 * @see SAProveedor#muestraProveedores()
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ArrayList<TransferProveedor> muestraProveedores() {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		DAOProveedor dao = FactDAO.getInstancia().generaDAOProveedor();
		return dao.muestraProveedor();
		// end-user-code
	}

	/** 
	 * (sin Javadoc)
	 * @see SAProveedor#modificaProveedor(TransferProveedor TProveedor)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean modificaProveedor(TransferProveedor TProveedor) {
		DAOProveedor dao = FactDAO.getInstancia().generaDAOProveedor();
		TransferProveedor proveedorAux = dao.readByName(TProveedor.getNombre());
		if(dao.readByName( TProveedor.getNombre()) == null || (TProveedor.getID() == proveedorAux.getID())){
			dao.modificaProveedor(TProveedor);
			return true;}
		else
			return false;
		// end-user-code
	}
}