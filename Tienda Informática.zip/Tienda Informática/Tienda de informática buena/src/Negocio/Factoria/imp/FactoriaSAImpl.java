/**
 * 
 */
package Negocio.Factoria.imp;

import Negocio.Cliente.SACliente;
import Negocio.Cliente.SAClienteImp;
import Negocio.Factoria.FactoriaSA;
import Negocio.Factura.SAFactura;
import Negocio.Factura.SAFacturaImp;
import Negocio.Marca.SAMarca;
import Negocio.Marca.imp.SAMarcaImpl;
import Negocio.Producto.SAProducto;
import Negocio.Producto.SAProductoImp;
import Negocio.Proveedor.SAProveedor;
import Negocio.Proveedor.SAProveedorImp;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class FactoriaSAImpl extends FactoriaSA {

	@Override
	public SAMarca generaSAMarca() {
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return new SAMarcaImpl();
	}

	@Override
	public SACliente generaSACliente() {
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return new SAClienteImp();
	}

	@Override
	public SAProveedor generaSAProveedor() {
		return new SAProveedorImp();
	}

	@Override
	public SAProducto generaSAProducto() {
		return new SAProductoImp();
	}

	@Override
	public SAFactura generaSAFactura() {
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return new SAFacturaImp();
	}
}