package Negocio.Factoria;

import Negocio.Cliente.SACliente;
import Negocio.Factoria.imp.FactoriaSAImpl;
import Negocio.Factura.SAFactura;
import Negocio.Marca.SAMarca;
import Negocio.Proveedor.SAProveedor;
import Negocio.Producto.SAProducto;

public abstract class FactoriaSA {

	private static FactoriaSA instancia;

	public static FactoriaSA getInstancia() {
		if(instancia == null)
			instancia =	new FactoriaSAImpl();
		return instancia;
	}
	
	public abstract SAMarca generaSAMarca();
	public abstract SACliente generaSACliente();
	public abstract SAProveedor generaSAProveedor();
	public abstract SAProducto generaSAProducto();
	public abstract SAFactura generaSAFactura();
	
}