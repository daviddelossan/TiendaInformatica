/**
 * 
 */
package Negocio.Producto;

import java.util.ArrayList;

import Integraci�n.Marca.DAOMarca;
import Integraci�n.Producto.DAOProducto;
import Integraci�n.Proveedor.DAOProveedor;
import Integraci�n.factoria.FactDAO;
import Negocio.Marca.TransferMarca;
import Negocio.Proveedor.TransferProveedor;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SAProductoImp implements SAProducto {
	
	public int altaProducto(TransferProducto TProducto) {
		int id = -1; //Si no se crea, se quedar� con -1, o sea error

		DAOProducto daoProducto = FactDAO.getInstancia().generaDAOProducto();

		DAOMarca daoMarca = FactDAO.getInstancia().generaDAOMarca();
		DAOProveedor daoProveedor = FactDAO.getInstancia().generaDAOProveedor();

		if(TProducto != null){
			if(TProducto.getNombre().equalsIgnoreCase(""))
				return -1;
			if(TProducto.getPrecio() >= 0){
				TransferProducto esta = daoProducto.readByName(TProducto.getNombre());
				if(esta == null){
					int idMarca = TProducto.getIDMarca();
					int idProveedor = TProducto.getIDProveedor();
					TransferMarca tMarca = daoMarca.readById(idMarca);
					TransferProveedor tProveedor = daoProveedor.readById(idProveedor);
					//Comprobamos de que exista el proveedor y la marca y de que est� activo
					if(tMarca != null && tProveedor != null && tMarca.getActivo() && tProveedor.getActivo()){
						id = daoProducto.creaProducto(TProducto);
						daoMarca.aumentaNumProductos(idMarca);}
					else
						return -1;}
				else{

						if(!esta.getActivo()){
							esta.setActivo(true);
							daoMarca.aumentaNumProductos(esta.getIDMarca());
							daoProducto.modificaProducto(esta);
							return esta.getID();
							}	
				}
			}
		}
		return id;
	}

	public Boolean bajaProducto(int ID) {
		DAOProducto daoProducto = FactDAO.getInstancia().generaDAOProducto();
		TransferProducto producto = daoProducto.readById(ID);
		if(producto != null && producto.getActivo()){
			DAOMarca daoMarca = FactDAO.getInstancia().generaDAOMarca();
			daoMarca.restaNumProductos(producto.getIDMarca());
			return daoProducto.eliminaProducto(ID);
		}
		return false;
	}

	
	public TransferProducto muestraProducto(int ID) {
		DAOProducto daoProducto = FactDAO.getInstancia().generaDAOProducto();
		
		return daoProducto.readById(ID);
	}

	
	public ArrayList<TransferProducto> muestraProductos() {
		DAOProducto daoProducto = FactDAO.getInstancia().generaDAOProducto();

		return daoProducto.muestraProductos();
	}

	
	public Boolean modificaProducto(TransferProducto tProducto) {
		Boolean exito = false;
		DAOProducto daoProducto = FactDAO.getInstancia().generaDAOProducto();
		
		int idMarca = tProducto.getIDMarca();
		int idProveedor = tProducto.getIDProveedor();
		
		DAOMarca daoMarca = FactDAO.getInstancia().generaDAOMarca();
		DAOProveedor daoProveedor = FactDAO.getInstancia().generaDAOProveedor();
		
		TransferMarca tMarca = daoMarca.readById(idMarca);
		TransferProveedor tProveedor = daoProveedor.readById(idProveedor); 
		
		TransferProducto productoAux = daoProducto.readByName(tProducto.getNombre());
		if(tMarca != null && tProveedor != null){
			if(tProducto.getPrecio() >= 0){
				if(productoAux == null || (productoAux.getID() == tProducto.getID()))
					exito = daoProducto.modificaProducto(tProducto);
			}
		}
		
		return exito;
	}
}