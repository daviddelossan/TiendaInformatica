/**
 * 
 */
package Negocio.Cliente;

import Integraci�n.Cliente.*;
import Integraci�n.factoria.FactDAO;
import java.util.ArrayList;

public class SAClienteImp implements SACliente {
	
	public int altaCliente(TCliente tCliente) {
		int id = -1;
		DAOCliente dao = FactDAO.getInstancia().generaDAOCliente();
		
		//SI existe un archivo que se llama asi
		if(tCliente != null){
			if (tCliente.getCorreo().equalsIgnoreCase(""))
				return -1;
			TCliente esta = dao.readByName(tCliente.getCorreo());
			
			if(esta == null)
				id = dao.creaCliente(tCliente);
			
			else{
				if(!esta.getActivo()){
					esta.setActivo(true);
					dao.modificaCliente(esta);
					return esta.getID();
				}
				else return -1;
			}
		}
		
		return id;
	}

	public boolean bajaCliente(int id) {
		DAOCliente dao = FactDAO.getInstancia().generaDAOCliente();
		
		return dao.eliminaCliente(id);
	}
	
	public TCliente muestraCliente(int ID) {
		DAOCliente dao = FactDAO.getInstancia().generaDAOCliente();
		
		return dao.muestraCliente(ID);
	}
	


	public ArrayList<TCliente> muestraClientes() {
		DAOCliente dao = FactDAO.getInstancia().generaDAOCliente();
		
		return dao.muestraClientes();
	}
	
	public boolean modificaCliente(TCliente tCliente) {
		DAOCliente dao = FactDAO.getInstancia().generaDAOCliente();
		
		if(tCliente.getClass() == TransferClienteVip.class){
			TransferClienteVip transferCliente = new TransferClienteVip();
			transferCliente = (TransferClienteVip)dao.readByName(tCliente.getCorreo());
			if(transferCliente == null || transferCliente.getID() == tCliente.getID()){
				dao.modificaCliente(tCliente);
				return true;
			}
			else return false;
		}
		else {
			TransferClienteNormal transferCliente = new TransferClienteNormal();
			transferCliente = (TransferClienteNormal)dao.readByName(tCliente.getCorreo());
			if(transferCliente == null || transferCliente.getID() == tCliente.getID()){
				dao.modificaCliente(tCliente);
				return true;
			}
			else return false;
		}		
	}


}