package Negocio.Cliente;

import java.util.ArrayList;

public interface SACliente {

	public int altaCliente(TCliente tCliente);
	public boolean bajaCliente(int ID);
	public boolean modificaCliente(TCliente tCliente);
	public TCliente muestraCliente(int ID);
	public ArrayList<TCliente> muestraClientes();
}