/**
 * 
 */
package Negocio.Cliente;

public class TransferClienteVip extends TCliente{

	private int ID;
	private String correo;
	private String nombre;
	private String direccion;
	private int telefono;
	private int limiteTarjeta;
	private boolean activo;
	
	public int getID() {

		return this.ID;
	}

	//--- STEFANO WAS HERE ---//
	public void setID(int ID) {
		
		this.ID = ID;
	}
	//------------------------//
	
	public String getDireccion() {
		
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		
		this.direccion = direccion;
	}

	public int getLimiteTarjeta() {
		
		return this.limiteTarjeta;
	}


	public void setLimiteTarjeta(int limiteTarjeta) {
		
		this.limiteTarjeta = limiteTarjeta;
	}

	public boolean getActivo() {

		return this.activo;
	}


	public void setActivo(Boolean estado) {
		
		this.activo = estado;
	}


	public String getNombre() {

		return this.nombre;
	}

	public void setNombre(String nombre) {
		
		this.nombre = nombre;
	}

	public String getCorreo() {

		return this.correo;
	}


	public void setCorreo(String correo) {
		
		this.correo = correo;
	}

	
	public int getTelefono() {
		
		return this.telefono;
	}


	public void setTelefono(int telefono) {
		
		this.telefono = telefono;
	}
}