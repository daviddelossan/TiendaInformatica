package Negocio.Cliente;

public abstract class TCliente {

	public abstract int getID();
	public abstract void setID(int ID);
	public abstract String getDireccion();
	public abstract void setDireccion(String direccion);
	public abstract boolean getActivo();
	public abstract void setActivo(Boolean estado);
	public abstract String getNombre();
	public abstract void setNombre(String nombre);
	public abstract String getCorreo();
	public abstract void setCorreo(String correo);
	public abstract int getTelefono();
	public abstract void setTelefono(int telefono);
}
