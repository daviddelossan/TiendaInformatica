/**
 * 
 */
package Negocio.Marca.imp;

import Integraci�n.Marca.DAOMarca;
import Integraci�n.factoria.FactDAO;
import Negocio.Marca.SAMarca;
import Negocio.Marca.TransferMarca;
import java.util.ArrayList;


public class SAMarcaImpl implements SAMarca {
	
	public int altaMarca(TransferMarca TMarca) {
		int id = -1;
		DAOMarca dao = FactDAO.getInstancia().generaDAOMarca();
		//SI existe un archivo que se llama asi
		if(TMarca != null){
			if(TMarca.getNombre().equalsIgnoreCase(""))
				return -1;
			TransferMarca esta = dao.readByName(TMarca.getNombre());
			if(esta == null)
				id = dao.creaMarca(TMarca);
			else{
				if(!esta.getActivo()){
					esta.setActivo(true);
					dao.modificaMarca(esta);
					return esta.getID();
				}
			}
			}
		
	
		return id;
	}


	public boolean bajaMarca(Integer ID) {
		DAOMarca dao = FactDAO.getInstancia().generaDAOMarca();
		if (dao.eliminaMarca(ID))
			return true;

		else
			return false;

	}

	
	public TransferMarca muestraMarca(int ID) {
		DAOMarca dao = FactDAO.getInstancia().generaDAOMarca();
		return dao.readById(ID);
	}

	
	public ArrayList<TransferMarca> muestraMarcas() {
		DAOMarca dao = FactDAO.getInstancia().generaDAOMarca();
		return dao.muestraMarcas();
	}

	/** 
	 * (sin Javadoc)
	 * @see SAMarca#modificaMarca(TransferMarca TMarca)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public boolean modificaMarca(TransferMarca TMarca) {
		DAOMarca dao = FactDAO.getInstancia().generaDAOMarca();
		TransferMarca marcaAux = dao.readByName(TMarca.getNombre());
		if(dao.readByName( TMarca.getNombre()) == null || (TMarca.getID() ==  marcaAux.getID())){
			dao.modificaMarca(TMarca);
			return true;}
		else
			return false;
	}
}