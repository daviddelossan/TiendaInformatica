/**
 * 
 */
package Negocio.Marca;

import java.util.ArrayList;


public interface SAMarca {
	
	public int altaMarca(TransferMarca TMarca);
	public boolean bajaMarca(Integer ID);
	public TransferMarca muestraMarca(int ID);
	public ArrayList<TransferMarca> muestraMarcas();
	public boolean modificaMarca(TransferMarca TMarca);
}