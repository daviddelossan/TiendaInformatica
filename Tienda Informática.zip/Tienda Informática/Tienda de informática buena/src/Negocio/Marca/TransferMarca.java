/**
 * 
 */
package Negocio.Marca;


public class TransferMarca {
	private String nombre;
	private int ID;
	private boolean activo;
	private int numProductos;
	//Constructoras
	public TransferMarca(){
		
	}
	public TransferMarca(String nombre){
		this.nombre = nombre;
		this.activo = true;
		this.numProductos = 0;
		// end-user-cod
		}
	public String getNombre() {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return this.nombre;
		// end-user-code
	}
	public void setNombre(String nombre) {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		this.nombre = nombre;
		// end-user-code
	}
	public boolean getActivo() {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return this.activo;
		// end-user-code
	}
	public void setActivo(boolean estado) {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		this.activo = estado;
	
		// end-user-code
	}
	public int getID() {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return this.ID;
		// end-user-code
	}
	public void setID(int ID){
		this.ID = ID;
	}
	public int getNumProductos(){
		return this.numProductos;
	}
	public void setNumProductos(int numProductos){
		this.numProductos = numProductos;
	}
}