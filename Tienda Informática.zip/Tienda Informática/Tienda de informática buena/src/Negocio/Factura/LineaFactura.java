/**
 * 
 */
package Negocio.Factura;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class LineaFactura {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private float precio;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private int cantidad;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private int id;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	
	public LineaFactura(int id, int cantidad, int precio) {
		this.id = id;
		this.cantidad = cantidad;
		this.precio = precio;
	}
	
	public LineaFactura() {
		// TODO Ap�ndice de constructor generado autom�ticamente
	}

	public float getPrecio() {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return this.precio;
		// end-user-code
	}
	
	public void setPrecio(float precio) {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		this.precio = precio;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getCantidad() {
		// begin-user-code
		return this.cantidad;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getID() {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return this.id;
		// end-user-code
	}
	
	public void setID(int id) {
		// begin-user-code
		// TODO Ap�ndice de m�todo generado autom�ticamente
		this.id = id;	// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param cantidad
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setCantidad(int cantidad) {
		// begin-user-code
		this.cantidad = cantidad;
		// end-user-code
	}
}