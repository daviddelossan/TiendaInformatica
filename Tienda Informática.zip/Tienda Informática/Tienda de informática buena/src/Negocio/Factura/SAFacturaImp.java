/**
 * 
 */
package Negocio.Factura;

import java.io.IOException;
import java.util.ArrayList;

import Integraci�n.Cliente.DAOCliente;
import Integraci�n.Factura.DAOFactura;
import Integraci�n.Producto.DAOProducto;
import Integraci�n.factoria.FactDAO;
import Negocio.Cliente.TCliente;
import Negocio.Producto.TransferProducto;
import Negocio.Factura.LineaFactura;
/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Javier
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SAFacturaImp implements SAFactura {
	/** 
	 * (sin Javadoc)
	 * @see SAFactura#altaCarrito(int ID)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */


	/** 
	 * (sin Javadoc)
	 * @see SAFactura#muestraFactura(int ID)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public TransferFactura muestraFactura(int ID) {

		DAOFactura daoFactura = FactDAO.getInstancia().generaDAOFactura();

		return daoFactura.readById(ID);
	}

	/** 
	 * (sin Javadoc)
	 * @see SAFactura#muestraFacturas()
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ArrayList muestraFacturas() {
		DAOFactura daoFactura = FactDAO.getInstancia().generaDAOFactura();

		return daoFactura.muestraFacturas();
	}

	/** 
	 * (sin Javadoc)
	 * @see SAFactura#devolucion(int IDFactura, int IDProducto, int unidades)
	 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public boolean devolucion(int IDFactura, int IDProducto, int unidades) { //DEVOLUCION DE USUARIO A TIENDA O AL REV�S??
		DAOFactura daoFactura = FactDAO.getInstancia().generaDAOFactura();
		DAOProducto daoProducto = FactDAO.getInstancia().generaDAOProducto();
		TransferFactura tFactura = daoFactura.readById(IDFactura); 
		if(tFactura == null)
			return false;
		else{
			@SuppressWarnings("unchecked")
			ArrayList<LineaFactura> lineasFactura = tFactura.getProductos(); //cogemos el array
			for(int i = 0; i < lineasFactura.size(); i++)//para cada lineaFactura
				if(lineasFactura.get(i).getID() == IDProducto){//comprobamos el id del producto
					if(unidades <= lineasFactura.get(i).getCantidad()){ //si son suficientes
						TransferProducto producto = daoProducto.readById(IDProducto);
						int numProductos = producto.getStock();
						numProductos += unidades;
						producto.setStock(numProductos);
						daoProducto.modificaProducto(producto);
						lineasFactura.get(i).setCantidad(lineasFactura.get(i).getCantidad() - unidades); 
						daoFactura.modificaFactura(tFactura);
						return true;
					}
					else {
						return false;
					}
				}
		}
		return false;
	}

	
	public boolean modificaFactura(TransferFactura tFactura) throws IOException{
		DAOFactura daoFactura = FactDAO.getInstancia().generaDAOFactura();

		return daoFactura.modificaFactura(tFactura);
	}
	
	
	
	public int generaFactura(TransferFactura tFactura) {
		int id = -1; //Si no se crea, se quedar� con -1, o sea error

		DAOFactura daoFactura = FactDAO.getInstancia().generaDAOFactura();

		int idCliente = tFactura.getIDCliente();
		DAOCliente daoCliente = FactDAO.getInstancia().generaDAOCliente();
		TCliente transferCliente = daoCliente.readById(idCliente);

		if(transferCliente != null) {
			for(int i = 0; i < tFactura.getProductos().size(); i++) {
				int idProducto = ((LineaFactura) tFactura.getProductos().get(i)).getID();
				DAOProducto daoProducto = FactDAO.getInstancia().generaDAOProducto();
				TransferProducto transferProductoObtenido = daoProducto.readById(idProducto);
				if(transferProductoObtenido != null) {
					int cantidad = ((LineaFactura) tFactura.getProductos().get(i)).getCantidad();
					int stockAnterior = transferProductoObtenido.getStock();
					if(cantidad <= transferProductoObtenido.getStock()) {
						transferProductoObtenido.setStock(stockAnterior-cantidad);
						daoProducto.modificaProducto(transferProductoObtenido);
						float precioActualProducto = transferProductoObtenido.getPrecio();
						((LineaFactura) tFactura.getProductos().get(i)).setPrecio(precioActualProducto);
					}
					else {
						//Append a log
						tFactura.getProductos().remove(i); //Eliminamos este producto, ya no es valido
					}
				}
				else {
					tFactura.getProductos().remove(i); //Eliminamos este producto, ya no es valido
				}

			} //Fin for

			if(tFactura.getProductos().size() > 0)
				id = daoFactura.creaFactura(tFactura);

		} //Fin if

		return id;
	} //Fin Metodo GeneraFactura



}