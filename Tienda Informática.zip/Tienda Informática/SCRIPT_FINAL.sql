
DROP DATABASE IF EXISTS TiendaDeInformatica_DB;
CREATE DATABASE TiendaDeInformatica_DB;
USE TiendaDeInformatica_DB;

-- Estructura de la tabla Producto

DROP TABLE IF EXISTS `Producto`;
CREATE TABLE IF NOT EXISTS `Producto`(
	`ID_Producto` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT, 
	`Nombre` VARCHAR(30) NOT NULL, 
	`Precio` FLOAT, 
	`Stock` INTEGER NOT NULL DEFAULT '0',
	`Activo` BOOLEAN,
	
	PRIMARY KEY (ID_Producto)	
) ENGINE=INNODB;

-- Estructura de la tabla Cliente

DROP TABLE IF EXISTS `Cliente`;
CREATE TABLE IF NOT EXISTS `Cliente`(
	`ID_Cliente` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT, 
	`Activo` BOOLEAN,
	`Correo` VARCHAR(25), 
	`Nombre` VARCHAR(50) NOT NULL, 
	`Direccion` VARCHAR(50) NOT NULL, 
	`Telefono` VARCHAR(10),
	
	PRIMARY KEY (`ID_Cliente`)
) ENGINE=INNODB;


-- Estructura de la tabla Cliente_Normal

DROP TABLE IF EXISTS `Cliente_Normal`;
CREATE TABLE IF NOT EXISTS `Cliente_Normal`(
	`ID_Cliente_Normal` INTEGER UNSIGNED NOT NULL,
	`intencionVip` BOOLEAN,
	
	PRIMARY KEY (`ID_Cliente_Normal`), 
	FOREIGN KEY (`ID_Cliente_Normal`) REFERENCES `Cliente`(`ID_Cliente`) ON DELETE CASCADE
) ENGINE=INNODB;


-- Estructura de la tabla Cliente_VIP

DROP TABLE IF EXISTS `Cliente_VIP`;
CREATE TABLE IF NOT EXISTS `Cliente_VIP`(
	`ID_Cliente_VIP` INTEGER UNSIGNED NOT NULL,
	`LimiteTarjeta` FLOAT, 
	
    	PRIMARY KEY (`ID_Cliente_VIP`), 
	FOREIGN KEY (`ID_Cliente_VIP`) REFERENCES `Cliente`(`ID_Cliente`) ON DELETE CASCADE
) ENGINE=INNODB;

-- Estructura de la tabla Factura

DROP TABLE IF EXISTS `Factura`;
CREATE TABLE IF NOT EXISTS `Factura`(
	`ID_Factura` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT, 
	`Cliente` INTEGER UNSIGNED NOT NULL,
	`Fecha` VARCHAR(40),

    	PRIMARY KEY (`ID_Factura`)
	
) ENGINE=INNODB;


-- Estructura de la tabla Linea_Factura


DROP TABLE IF EXISTS `LineaFactura`;
CREATE TABLE IF NOT EXISTS `LineaFactura`(
	`ID_Factura` INTEGER UNSIGNED NOT NULL REFERENCES `Factura`(`ID_Factura`), 
	`ID_Producto` INTEGER UNSIGNED NOT NULL REFERENCES `Producto`(`ID_Producto`), 
	`Precio` FLOAT NOT NULL, 
	`Cantidad` TINYINT NOT NULL, 
	
	PRIMARY KEY (`ID_Factura`, `ID_Producto`), 
	FOREIGN KEY (`ID_Factura`) REFERENCES `Factura`(`ID_Factura`) ON DELETE CASCADE, 
	FOREIGN KEY (`ID_Producto`) REFERENCES `Producto`(`ID_Producto`) ON DELETE NO ACTION -- es lo mismo que ON DELETE RESTRICT (no permite la eliminaci�n del padre)
) ENGINE=INNODB;

GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' IDENTIFIED BY '1234' WITH GRANT OPTION;

FLUSH PRIVILEGES;

SET autocommit = 0;