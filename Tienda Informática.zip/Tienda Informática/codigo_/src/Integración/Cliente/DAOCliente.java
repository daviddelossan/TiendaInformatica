/**
 * 
 */
package Integraci�n.Cliente;

import Negocio.Cliente.TCliente;
import java.util.ArrayList;

public interface DAOCliente {

	public ArrayList<TCliente> muestraClientes() throws Exception;
	
	public TCliente muestraCliente(int ID) throws Exception;

	public int creaCliente(TCliente TCliente) throws Exception;
	
	public boolean eliminaCliente(int ID) throws Exception;
	
	public TCliente modificaCliente(TCliente TCliente) throws Exception;

	public TCliente readById(int IDCliente) throws Exception;
	
	public TCliente readByName(String nombre) throws Exception;
	
	public int getNumFacturas(int idCliente) throws Exception;
}