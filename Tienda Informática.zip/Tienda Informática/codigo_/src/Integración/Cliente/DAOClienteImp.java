/**
 * 
 */
package Integraci�n.Cliente;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Integraci�n.Queries.FactoriaQuery;
import Integraci�n.Transaction.TransactionManager;
import Negocio.Cliente.TCliente;
import Negocio.Cliente.TClienteNormal;
import Negocio.Cliente.TClienteVIP;
import Negocio.Factura.TransferFactura;

public class DAOClienteImp implements DAOCliente {

	public ArrayList<TCliente> muestraClientes() throws Exception {
	
		ArrayList<TCliente> listaClientes = null;
		
		try {
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
			
			ResultSet rs =  c.createStatement().executeQuery("SELECT p.*,c.intencionVip "
															+ "FROM cliente p, cliente_normal c  "
															+ "WHERE p.ID_Cliente = c.ID_Cliente_Normal "
														//	+ "ORDER BY c.ID_Cliente_Normal"
															+ " FOR UPDATE");
			
			listaClientes = new ArrayList<TCliente>();
			
			while(rs.next()) {
				
				TClienteNormal tClienteNormal = new TClienteNormal();
				
				tClienteNormal.setID(rs.getInt("ID_Cliente"));
				
//				if(rs.getInt("Activo") == 1)				
//					tClienteNormal.setActivo(true);
//				else
//					tClienteNormal.setActivo(false);	
				
				tClienteNormal.setCorreo(rs.getString("Correo"));				
				tClienteNormal.setNombre(rs.getString("Nombre"));
				tClienteNormal.setDireccion(rs.getString("Direccion"));
				tClienteNormal.setTelefono(rs.getInt("Telefono"));
				tClienteNormal.setActivo(rs.getBoolean("Activo"));
				tClienteNormal.setIntencionVIP(rs.getBoolean("intencionVip"));
				
//				if(rs.getInt("intencionVip") == 1)				
//					tClienteNormal.setIntencionVIP(true);
//				else
//					tClienteNormal.setIntencionVIP(false);

				
				listaClientes.add(tClienteNormal);

			}
			
			rs =  c.createStatement().executeQuery("SELECT p.*,c.LimiteTarjeta "
					+ "FROM cliente p, cliente_vip c  "
					+ "WHERE p.ID_Cliente = c.ID_Cliente_Vip "
				//	+ "ORDER BY c.ID_Cliente_Vip"
					+ " FOR UPDATE");
			
			while(rs.next()) {
				
				TClienteVIP tClienteVip = new TClienteVIP();
				
				tClienteVip.setID(rs.getInt("ID_Cliente"));
				
//				if(rs.getInt("Activo") == 1)				
//					tClienteVip.setActivo(true);
//				else
//					tClienteVip.setActivo(false);	
				
				tClienteVip.setActivo(rs.getBoolean("Activo"));
				tClienteVip.setCorreo(rs.getString("Correo"));				
				tClienteVip.setNombre(rs.getString("Nombre"));
				tClienteVip.setTelefono(rs.getInt("Telefono"));
				tClienteVip.setDireccion(rs.getString("Direccion"));
				tClienteVip.setLimiteTarjeta(rs.getInt("LimiteTarjeta"));
				
				listaClientes.add(tClienteVip);

			}
		
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
			
		} catch (Exception e) {			
			e.printStackTrace();	
			throw new Exception ("Error inesperado en la BBDD");
		}
 
        return listaClientes;	
	}

	public TCliente muestraCliente(int ID) throws Exception { 
			
		try {
			
			TClienteNormal tClienteNormal = null;
			TClienteVIP tClienteVip = null;
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
			
			
			ResultSet rs =  c.createStatement().executeQuery("SELECT p.*,c.intencionVip "
					+ "FROM cliente p, cliente_normal c  "
					+ "WHERE p.ID_Cliente = c.ID_Cliente_Normal AND p.ID_Cliente = " + ID
				///	+ "ORDER BY c.ID_Cliente_Normal"
					+ " FOR UPDATE");
			
		/*	ResultSet rs =  c.createStatement().executeQuery("SELECT p.* FROM cliente p " 
					+ " WHERE p.ID_Cliente = " + ID + " FOR UPDATE");
			*/
			if (rs.next()) {
				tClienteNormal = new TClienteNormal();
				
				tClienteNormal.setID(rs.getInt("ID_Cliente"));
				
//				if(rs.getInt("Activo") == 1)				
//					tClienteNormal.setActivo(true);
//				else
//					tClienteNormal.setActivo(false);		
				
				tClienteNormal.setCorreo(rs.getString("Correo"));				
				tClienteNormal.setNombre(rs.getString("Nombre"));
				tClienteNormal.setDireccion(rs.getString("Direccion"));
				tClienteNormal.setTelefono(rs.getInt("Telefono"));
				tClienteNormal.setActivo(rs.getBoolean("Activo"));
				tClienteNormal.setIntencionVIP(rs.getBoolean("intencionVip"));
				
//				if(rs.getInt("intencionVip") == 1)				
//					tClienteNormal.setIntencionVIP(true);
//				else
//					tClienteNormal.setIntencionVIP(false);

				
				return tClienteNormal;
				
			}
			else
			{
				tClienteVip =  new TClienteVIP();
				rs =  c.createStatement().executeQuery("SELECT p.*,c.LimiteTarjeta "
						+ "FROM cliente p, cliente_vip c  "
						+ "WHERE p.ID_Cliente = c.ID_Cliente_Vip AND p.ID_Cliente = " + ID
					//	+ "ORDER BY c.ID_Cliente_Vip"
						+ " FOR UPDATE");
				
				if (rs.next()) {
					
					tClienteVip.setID(rs.getInt("ID_Cliente"));
					
//					if(rs.getInt("Activo") == 1)				
//						tClienteVip.setActivo(true);
//					else
//						tClienteVip.setActivo(false);	
					
					tClienteVip.setActivo(rs.getBoolean("Activo"));
					tClienteVip.setCorreo(rs.getString("Correo"));				
					tClienteVip.setNombre(rs.getString("Nombre"));
					tClienteVip.setTelefono(rs.getInt("Telefono"));
					tClienteVip.setDireccion(rs.getString("Direccion"));
					tClienteVip.setLimiteTarjeta(rs.getInt("LimiteTarjeta"));
					
					return tClienteVip;
				}
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {		
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}

		return null;
		
	}

	public int creaCliente(TCliente TCliente) throws Exception {
			
		try {
		
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
			
			c.createStatement().executeUpdate("INSERT INTO Cliente (`ID_Cliente`, `Activo`, `Correo`, `Nombre`, `Direccion`, `Telefono`) " +
					"VALUES (" + TCliente.getID() + ", "  + TCliente.getActivo() + ", '"  + TCliente.getCorreo() + "','" + TCliente.getNombre() + "','" + TCliente.getDireccion() + "','" + TCliente.getTelefono() + "')");
			
			ResultSet rs = c.createStatement().executeQuery("SELECT ID_Cliente "
															+ "FROM Cliente "
															+ "WHERE  Nombre = '" +  TCliente.getNombre() +"'"
															+ " FOR UPDATE");
			
			int id = 0;
			if(rs.next())
			{
				id = rs.getInt(1);
			}
			if(TCliente instanceof TClienteNormal) 
			{
				TClienteNormal p = (TClienteNormal) TCliente;
				
				c.createStatement().executeUpdate("INSERT INTO cliente_normal (ID_Cliente_Normal, intencionVip) VALUES (" + id + ", "  + p.getIntencionVIP() +")");
			
				return 1;
				
			}
			
			if(TCliente instanceof TClienteVIP) 
			{
				TClienteVIP p = (TClienteVIP) TCliente;	

				c.createStatement().executeUpdate("INSERT INTO cliente_vip (ID_Cliente_Vip, limiteTarjeta) VALUES (" + id + ", "  + p.getLimiteTarjeta() +")");
				
				return 1;
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {		
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
		return 0;
	
	}

	public boolean eliminaCliente(int ID) throws Exception {
		
		int rdo = 0;
			
		try {
		
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
						
			rdo = c.createStatement().executeUpdate("UPDATE Cliente SET Activo = '0' " + "WHERE ID_Cliente = " + ID );
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {		
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
		if(rdo == 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	
	}

	public TCliente modificaCliente(TCliente TCliente) throws Exception {
		System.out.println("MODIFICA");
		try {
			int aux = 0;
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
			if(TCliente.getActivo())
				aux = 1;
			c.createStatement().executeUpdate("UPDATE Cliente SET Activo = '" + aux +"',  Correo = '" + TCliente.getCorreo() + "' , Nombre = '" + TCliente.getNombre() + "', Direccion = '" + TCliente.getDireccion() + "', Telefono = '" + TCliente.getTelefono()  
											+ "' WHERE ID_Cliente = " + TCliente.getID() );
			
			
			if(TCliente instanceof TClienteNormal) 
			{
				int aux1 = 0;
				TClienteNormal p = (TClienteNormal) TCliente;
				if(p.getIntencionVIP()){
					aux1 = 1;
				}
				c.createStatement().executeUpdate("UPDATE Cliente_Normal SET intencionVip = '" + aux1 + "' "
												+ "WHERE ID_Cliente_Normal = " + TCliente.getID() );
				
				return TCliente;
				
			}
			
			if(TCliente instanceof TClienteVIP) 
			{
				TClienteVIP p = (TClienteVIP) TCliente;
				
				c.createStatement().executeUpdate("UPDATE Cliente_VIP SET limiteTarjeta = " + p.getLimiteTarjeta() + " "
												+ "WHERE ID_Cliente_VIP = " + TCliente.getID() );
				
				return TCliente;
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {		
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
		return null;
	}

	@Override
	public TCliente readById(int IDCliente) throws Exception { 
			
		try {
			
			TClienteNormal tClienteNormal = new TClienteNormal();
			TClienteVIP tClienteVip = new TClienteVIP();
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
			
			
			ResultSet rs =  c.createStatement().executeQuery("SELECT p.*,c.intencionVip "
					+ "FROM cliente p, cliente_normal c  "
					+ "WHERE p.ID_Cliente = c.ID_Cliente_Normal AND p.ID_Cliente = " + IDCliente
				//	+ "ORDER BY c.ID_Cliente_Normal"
					+ " FOR UPDATE");
			
			if (rs.next()) {
				
				tClienteNormal.setID(rs.getInt("ID_Cliente"));
				
//				if(rs.getInt("Activo") == 1)				
//					tClienteNormal.setActivo(true);
//				else
//					tClienteNormal.setActivo(false);		
				
				tClienteNormal.setCorreo(rs.getString("Correo"));				
				tClienteNormal.setNombre(rs.getString("Nombre"));
				tClienteNormal.setDireccion(rs.getString("Direccion"));
				tClienteNormal.setTelefono(rs.getInt("Telefono"));
				tClienteNormal.setActivo(rs.getBoolean("Activo"));
				tClienteNormal.setIntencionVIP(rs.getBoolean("intencionVip"));
				
//				if(rs.getInt("intencionVip") == 1)				
//					tClienteNormal.setIntencionVIP(true);
//				else
//					tClienteNormal.setIntencionVIP(false);

				
				return tClienteNormal;
				
			}
			else
			{
				rs =  c.createStatement().executeQuery("SELECT p.*,c.LimiteTarjeta "
						+ "FROM cliente p, cliente_vip c  "
						+ "WHERE p.ID_Cliente = c.ID_Cliente_Vip AND p.ID_Cliente = " + IDCliente
					//	+ "ORDER BY c.ID_Cliente_Vip"
						+ " FOR UPDATE");
				
				if (rs.next()) {
					
					tClienteVip.setID(rs.getInt("ID_Cliente"));
					
//					if(rs.getInt("Activo") == 1)				
//						tClienteVip.setActivo(true);
//					else
//						tClienteVip.setActivo(false);	
					
					tClienteVip.setActivo(rs.getBoolean("Activo"));
					tClienteVip.setCorreo(rs.getString("Correo"));				
					tClienteVip.setNombre(rs.getString("Nombre"));
					tClienteVip.setTelefono(rs.getInt("Telefono"));
					tClienteVip.setDireccion(rs.getString("Direccion"));
					tClienteVip.setLimiteTarjeta(rs.getInt("LimiteTarjeta"));
					
					return tClienteVip;
				}
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {		
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}

		return null;
		
	}

	public TCliente readByName(String correo) throws Exception { 
			
		try {
			
			TClienteNormal tClienteNormal = new TClienteNormal();
			TClienteVIP tClienteVip = new TClienteVIP();
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
			
			
			ResultSet rs =  c.createStatement().executeQuery("SELECT p.*,c.intencionVip "
					+ "FROM cliente p, cliente_normal c  "
					+ "WHERE p.ID_Cliente = c.ID_Cliente_Normal AND p.correo = '" + correo + "' "
					+ "ORDER BY c.ID_Cliente_Normal"
					+ " FOR UPDATE");
			
			if (rs.next()) {
				
				tClienteNormal.setID(rs.getInt("ID_Cliente"));
				
//				if(rs.getInt("Activo") == 1)				
//					tClienteNormal.setActivo(true);
//				else
//					tClienteNormal.setActivo(false);		
				
				tClienteNormal.setCorreo(rs.getString("Correo"));				
				tClienteNormal.setNombre(rs.getString("Nombre"));
				tClienteNormal.setDireccion(rs.getString("Direccion"));
				tClienteNormal.setTelefono(rs.getInt("Telefono"));
				tClienteNormal.setActivo(rs.getBoolean("Activo"));
				tClienteNormal.setIntencionVIP(rs.getBoolean("intencionVip"));
				
//				if(rs.getInt("intencionVip") == 1)				
//					tClienteNormal.setIntencionVIP(true);
//				else
//					tClienteNormal.setIntencionVIP(false);

				
				return tClienteNormal;
				
			}
			else
			{
				rs =  c.createStatement().executeQuery("SELECT p.*,c.LimiteTarjeta "
						+ "FROM cliente p, cliente_vip c  "
						+ "WHERE p.ID_Cliente = c.ID_Cliente_Vip AND p.correo = '" + correo + "' "
						+ "ORDER BY c.ID_Cliente_Vip"
						+ " FOR UPDATE");
				
				if (rs.next()) {
					
					tClienteVip.setID(rs.getInt("ID_Cliente"));
					
//					if(rs.getInt("Activo") == 1)				
//						tClienteVip.setActivo(true);
//					else
//						tClienteVip.setActivo(false);	
					
					tClienteVip.setActivo(rs.getBoolean("Activo"));
					tClienteVip.setCorreo(rs.getString("Correo"));				
					tClienteVip.setNombre(rs.getString("Nombre"));
					tClienteVip.setTelefono(rs.getInt("Telefono"));
					tClienteVip.setDireccion(rs.getString("Direccion"));
					tClienteVip.setLimiteTarjeta(rs.getInt("LimiteTarjeta"));
					
					return tClienteVip;
				}
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {		
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}

		return null;
		
	}

	@SuppressWarnings("unchecked")
	public int getNumFacturas(int idCliente) throws Exception {
		
		ArrayList<TransferFactura> lista = (ArrayList<TransferFactura>) FactoriaQuery.obtenerInstancia().creaQuery(1).execute(idCliente);
				
		return lista.size();
		
	}
	
}