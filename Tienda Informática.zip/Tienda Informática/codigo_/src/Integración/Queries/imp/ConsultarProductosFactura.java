package Integraci�n.Queries.imp;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Integraci�n.Queries.Query;
import Integraci�n.Transaction.Transaction;
import Integraci�n.Transaction.TransactionManager;
import Negocio.Factura.TransferFactura;

public class ConsultarProductosFactura implements Query {

	// Le pasas un id de producto y un precio y te saca todas las facturas en las que esta ese producto y que superan el precio que les has metido
	
	public Object execute(Object objeto) 
	{
		
		int ID = (Integer)objeto;
		
		TransactionManager tManager = TransactionManager.getInstance();

		Transaction transaction;
		try {
			transaction = tManager.getTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		java.sql.Connection c;
		try {
			c = (Connection) transaction.getResource();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
				
		ArrayList<TransferFactura> listaFacturas = new ArrayList<TransferFactura>();
		
        try {        
                	
            ResultSet rs = c.createStatement().executeQuery("SELECT * FROM lineafactura, factura WHERE ID_Producto = " + ID +  " AND factura.ID_Factura = lineaFactura.ID_Factura FOR UPDATE");
            //" AND PRECIO > " + idValor.getValor() +
            while (rs.next())
            {
            	TransferFactura transferFactura = new TransferFactura();
            	transferFactura.setIDFactura(rs.getInt("ID_Factura"));
            	transferFactura.setIDCliente(rs.getInt("Cliente"));
            	listaFacturas.add(transferFactura);            
            
            }
                       
        } catch (SQLException ex) {
            System.out.println("Imposible realizar consulta");
			return false;
        }
    	
		return listaFacturas;

	}
}