
package Integraci�n.Queries.imp;

import Integraci�n.Queries.FactoriaQuery;
import Integraci�n.Queries.Query;

public class FactoriaQueryImp extends FactoriaQuery {

	public Query creaQuery(int numQuery) 
	{

		switch(numQuery)
		{
		
			case 1:
					return new ConsultarClienteFactura();
		
			case 2:
					return new ConsultarProductosFactura();
			
			
		}
		return null;
	}
	
	

	
}