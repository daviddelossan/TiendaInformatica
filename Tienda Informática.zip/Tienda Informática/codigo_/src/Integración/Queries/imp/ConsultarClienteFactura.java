package Integraci�n.Queries.imp;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Integraci�n.Queries.Query;
import Integraci�n.Transaction.Transaction;
import Integraci�n.Transaction.TransactionManager;
import Negocio.Factura.TransferFactura;

// Damos un cliente y nos saca las facturas asociadas a el

public class ConsultarClienteFactura implements Query{

	public Object execute(Object objeto) 
	{
		int ID = (Integer)objeto;
		
		TransactionManager tManager = TransactionManager.getInstance();

		Transaction transaction;
		try {
			transaction = tManager.getTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		java.sql.Connection c;
		try {
			c = (Connection) transaction.getResource();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
				
		ArrayList<TransferFactura> listaFacturas = new ArrayList<TransferFactura>();
		
		
        try {
        	
            ResultSet rs = c.createStatement().executeQuery("SELECT * FROM factura WHERE Cliente = " + ID +  " FOR UPDATE");
            
            while (rs.next())
            {
            	TransferFactura transferFactura = new TransferFactura();
            	transferFactura.setIDFactura(rs.getInt("ID_Factura"));
            	transferFactura.setIDCliente(rs.getInt("Cliente"));
            	transferFactura.setFecha(rs.getString("Fecha"));
            	listaFacturas.add(transferFactura);            
            
            }
                       
        } catch (SQLException ex) {
            System.out.println("Imposible realizar consulta");
			return false;
        }
    	
		return listaFacturas;

	}
}