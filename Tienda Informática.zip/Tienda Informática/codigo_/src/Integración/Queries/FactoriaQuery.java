
package Integraci�n.Queries;

import Integraci�n.Queries.imp.FactoriaQueryImp;

public abstract class FactoriaQuery {

	private static FactoriaQuery factoria;

	public static FactoriaQuery obtenerInstancia() {

		if (factoria == null)
			factoria = new FactoriaQueryImp();

		return factoria;
	}

	public abstract Query creaQuery(int numQuery) ;

}