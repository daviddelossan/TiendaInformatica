
package Integraci�n.Queries;

public interface Query {
	
	public Object execute(Object param);
}