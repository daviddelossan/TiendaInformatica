
package Integraci�n.Factura;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import Integraci�n.Queries.FactoriaQuery;
import Integraci�n.Transaction.TransactionManager;
import Negocio.Factura.LineaFactura;
import Negocio.Factura.TransferFactura;

public class DAOFacturaImp implements DAOFactura {

	public TransferFactura muestraFactura(int ID) throws Exception{
		
		TransferFactura tFactura = null;
		LineaFactura lineaFactura = null;
		ArrayList<LineaFactura> lFacturas= null;
		
		try {
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
					
			ResultSet rs =  c.createStatement().executeQuery("SELECT * FROM Factura WHERE ID_Factura = " + ID + " FOR UPDATE");
					
			tFactura = new TransferFactura();
			
			ResultSet rs2 =  c.createStatement().executeQuery("SELECT * FROM LineaFactura WHERE ID_Factura = " + ID + " FOR UPDATE");

			
			while(rs.next()) {
						
				tFactura.setIDFactura(rs.getInt("ID_Factura"));
				tFactura.setFecha(rs.getString("Fecha"));
				tFactura.setIDCliente(rs.getInt("Cliente"));				
				
			}
			
			lFacturas = new ArrayList<LineaFactura>();
			while(rs2.next()) {
				lineaFactura = new LineaFactura();
				int idFactAux = rs2.getInt("ID_Factura");
				lineaFactura.setID((rs2.getInt("ID_Producto"))) ;			
				lineaFactura.setPrecio((rs2.getInt("Precio")));			
				lineaFactura.setCantidad(rs2.getInt("Cantidad"));
				lFacturas.add(lineaFactura);
			}
			tFactura.setProductos(lFacturas);

				
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
        return tFactura;
				
	
			
}

	public ArrayList<TransferFactura> muestraFacturas() throws Exception {
		
		ArrayList<TransferFactura> listaFacturas = null; 
		
		TransferFactura tFacturaAuxiliar = null;
		
		try {
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
					
			ResultSet rs =  c.createStatement().executeQuery("SELECT * FROM Factura FOR UPDATE");
					
			listaFacturas = new ArrayList<TransferFactura>();			
			
			while(rs.next()) {
				
				tFacturaAuxiliar = new TransferFactura();
						
				tFacturaAuxiliar.setIDFactura(rs.getInt("ID_Factura"));
				tFacturaAuxiliar.setFecha(rs.getString("Fecha"));
				tFacturaAuxiliar.setIDCliente(rs.getInt("Cliente"));
				
				ArrayList<LineaFactura> lFacturas = new ArrayList<LineaFactura>();
				
				ResultSet rs2 =  c.createStatement().executeQuery("SELECT * FROM LineaFactura WHERE ID_Factura = " + tFacturaAuxiliar.getIDFactura() + " FOR UPDATE");

				while(rs2.next()) {
					LineaFactura lineaFactura = new LineaFactura();
					int idFactAux = rs2.getInt("ID_Factura");
					lineaFactura.setID((rs2.getInt("ID_Producto"))) ;			
					lineaFactura.setPrecio((rs2.getInt("Precio")));			
					lineaFactura.setCantidad(rs2.getInt("Cantidad"));
					lFacturas.add(lineaFactura);
				}
				tFacturaAuxiliar.setProductos(lFacturas);

				listaFacturas.add(tFacturaAuxiliar);

			}
			
				
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
        return listaFacturas;
				
	}
	
	public int creaFactura(TransferFactura transferFactura) throws Exception{	
			
		int idUltimoFactura = 0;
		int resultado = 0, resultado2 = 0;
		LineaFactura lineaFacturaAux = null;
		
		try {
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();					
						

			String query = "INSERT INTO FACTURA " + "VALUES ('" + transferFactura.getIDFactura() + "', '"  + transferFactura.getIDCliente() + "', '" + transferFactura.getFecha() + "')";

			PreparedStatement stmt = c.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);


			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()){
				idUltimoFactura=rs.getInt(1);
			}
			/*
			boolean returnLastInsertId;
			if(returnLastInsertId) {
			   ResultSet rs = stmt.getGeneratedKeys();
			    rs.next();
			   int auto_id = rs.getInt(1);
			}
			*/
			try {
				PreparedStatement commit = c.prepareStatement("COMMIT");
				commit.execute();
			} catch (SQLException e) {
				//rollback();
				throw new Exception("Error al realizar commit");		
			}	
			for(int i = 0; i < transferFactura.getProductos().size(); i++) {
				lineaFacturaAux = (LineaFactura) transferFactura.getProductos().get(i);
				resultado2 = c.createStatement().executeUpdate("INSERT INTO LINEAFACTURA " + "VALUES ('" + idUltimoFactura + "', '"  + lineaFacturaAux.getID() + "', '" + lineaFacturaAux.getPrecio() + "', '"  + lineaFacturaAux.getCantidad() + "')");	
			}
			


			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {	
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}

		return idUltimoFactura;
		
	}	

	public boolean eliminaFactura(int ID) throws Exception{
				
		try {
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource(); 
			
			return c.createStatement().executeUpdate("DELETE FROM Factura WHERE ID_Factura = " + ID) >= 1;
				
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {		
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
	}

	public boolean modificaFactura(TransferFactura tFactura) throws Exception  {
		int resultado2 = 0;
		boolean exito = true;
		try {
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource(); // Obtenemos conexion con la BBDD

			exito = c.createStatement().executeUpdate("UPDATE Factura SET Cliente = '" + tFactura.getIDCliente() + "' , Fecha = '" + tFactura.getFecha() + "' "
													+ "WHERE ID_Factura = " + tFactura.getIDFactura() ) >= 1;
													
													
			for(int i = 0; i < tFactura.getProductos().size(); i++) {
				LineaFactura lineaFacturaAux = new LineaFactura();
				lineaFacturaAux = (LineaFactura) tFactura.getProductos().get(i);
				resultado2 = c.createStatement().executeUpdate("UPDATE lineafactura SET Cantidad = '" + lineaFacturaAux.getCantidad() + "' "
						+ "WHERE ID_Factura = " + tFactura.getIDFactura() + " AND ID_Producto = " + lineaFacturaAux.getID() );	
			}		
			if(resultado2 >= 1)
				return true;
			else
				return false;
		} catch (SQLException e) {			
			e.printStackTrace();			
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
	}

	@SuppressWarnings("unchecked")
	public ArrayList<TransferFactura> consultaFacturas(int idCliente) throws Exception{
		
		return (ArrayList<TransferFactura>) FactoriaQuery.obtenerInstancia().creaQuery(1).execute(idCliente);
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<TransferFactura> consultaProducto(int idProducto){
		
		return (ArrayList<TransferFactura>) FactoriaQuery.obtenerInstancia().creaQuery(2).execute(idProducto);
	}
	
	public int a�adirProductoAFactura(LineaFactura lineaFactura) throws Exception{	
			
		int resultado = 0;
		
		try {
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();					
			
			resultado = c.createStatement().executeUpdate("INSERT INTO lineafactura (`ID_Factura`, `ID_Producto`, `Precio`, `Cantidad`)) "
					+ "VALUES ('" + lineaFactura.getID() + "', '"  + lineaFactura.getProducto() + "', '"  + lineaFactura.getPrecio() + "', '"  + lineaFactura.getCantidad() + "')");			
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {	
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}

		return resultado;
		
	}

	@Override
	public TransferFactura readById(int ID) throws Exception {

		TransferFactura tFactura = null;
		LineaFactura lineaFactura = null;
		ArrayList<LineaFactura> lFacturas= null;
		
		try {
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
					
			ResultSet rs =  c.createStatement().executeQuery("SELECT * FROM Factura WHERE ID_Factura = " + ID + " FOR UPDATE");
					
			tFactura = new TransferFactura();
			
			ResultSet rs2 =  c.createStatement().executeQuery("SELECT * FROM LineaFactura WHERE ID_Factura = " + ID + " FOR UPDATE");

			TransferFactura tFacturaAux = null;
			while(rs.next()) {
				tFacturaAux = new TransferFactura();
				tFacturaAux.setIDFactura(rs.getInt("ID_Factura"));
				tFacturaAux.setFecha(rs.getString("Fecha"));
				tFacturaAux.setIDCliente(rs.getInt("Cliente"));				
			}
			
			lFacturas = new ArrayList<LineaFactura>();
			while(rs2.next()) {
				lineaFactura = new LineaFactura();
				int idFactAux = rs2.getInt("ID_Factura");
				lineaFactura.setID((rs2.getInt("ID_Producto"))) ;			
				lineaFactura.setPrecio((rs2.getInt("Precio")));			
				lineaFactura.setCantidad(rs2.getInt("Cantidad"));
				lFacturas.add(lineaFactura);
			}
			if(tFacturaAux != null)
				tFacturaAux.setProductos(lFacturas);
			tFactura = tFacturaAux;
				
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
        return tFactura;
				
	}	
	
}