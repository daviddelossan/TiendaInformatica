/**
 * 
 */
package Integraci�n.Factura;

import Negocio.Factura.LineaFactura;
import Negocio.Factura.TransferFactura;
import java.util.ArrayList;

public interface DAOFactura {
	
	public TransferFactura muestraFactura(int ID) throws Exception;

	public ArrayList<TransferFactura> muestraFacturas() throws Exception;
	
	public int creaFactura(TransferFactura transferFactura) throws Exception;

	public boolean eliminaFactura(int ID) throws Exception;

	public boolean modificaFactura(TransferFactura tFactura) throws Exception;

	public ArrayList<TransferFactura> consultaFacturas(int idCliente) throws Exception;
	
	public int a�adirProductoAFactura(LineaFactura lineaFactura) throws Exception;

	public TransferFactura readById(int ID) throws Exception;
	
	public ArrayList<TransferFactura> consultaProducto(int idProducto);
	
}