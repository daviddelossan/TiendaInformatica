
package Integraci�n.Producto;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Integraci�n.Transaction.TransactionManager;
import Negocio.Producto.TransferProducto;

public class DAOProductoImp implements DAOProducto {

	public TransferProducto muestraProducto(int ID) throws Exception {
		
		TransferProducto tProducto = null;
		
		try {
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();
					
			ResultSet rs =  c.createStatement().executeQuery("SELECT * FROM Producto WHERE ID_Producto = " + ID + " FOR UPDATE");
					
			tProducto = new TransferProducto();
			
			while(rs.next()) {
						
				tProducto.setIdProducto(rs.getInt("ID_Producto"));
				tProducto.setNombre(rs.getString("Nombre"));
				tProducto.setPrecio(rs.getFloat("Precio"));
				tProducto.setStock(rs.getInt("Stock"));
				
				if(rs.getInt("Activo") == 1)				
					tProducto.setActivo(true);
				else
					tProducto.setActivo(false);					

			}
				
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
        return tProducto;
				
	}
	
	public ArrayList<TransferProducto> muestraProductos() throws Exception {
		
		ArrayList<TransferProducto> listaProductos = null; 
		
		try {
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource(); // Obtenemos conexion con la BBDD
					
			ResultSet rs =  c.createStatement().executeQuery("SELECT * FROM Producto FOR UPDATE");
					
			listaProductos = new ArrayList<TransferProducto>();
			while(rs.next()) {
						
				TransferProducto tProductoAux = new TransferProducto();
						
				tProductoAux.setIdProducto(rs.getInt("ID_Producto"));
				tProductoAux.setNombre(rs.getString("Nombre"));
				tProductoAux.setPrecio(rs.getFloat("Precio"));
				tProductoAux.setStock(rs.getInt("Stock"));
				
				if(rs.getInt("Activo") == 1)				
					tProductoAux.setActivo(true);
				else
					tProductoAux.setActivo(false);
					
				
				listaProductos.add(tProductoAux);

			}
				
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
        return listaProductos;
				
	}

	public int creaProducto(TransferProducto tProducto) throws Exception {	
			
		int resultado = 0;
		
		try {
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource();					
			
			resultado = c.createStatement().executeUpdate("INSERT INTO Producto " +"VALUES (" + tProducto.getID() + ", '"  + tProducto.getNombre() + "', "  + (float)tProducto.getPrecio() + ", "  + tProducto.getStock() + ", TRUE)");		
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {	
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}

		return resultado;
		
	}	

	public boolean modificaProducto(TransferProducto TProducto)	throws Exception  {
				
		try {
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource(); // Obtenemos conexion con la BBDD
			
			return c.createStatement().executeUpdate("UPDATE Producto SET Nombre = '" + TProducto.getNombre() + "' , Precio = " + TProducto.getPrecio() + " , Stock = " + TProducto.getStock() + " , Activo = " + TProducto.getActivo() + " "
													+ "WHERE ID_Producto = " + TProducto.getID()) >= 1;
				
		} catch (SQLException e) {			
			e.printStackTrace();			
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
	}

	public boolean eliminaProducto(int ID) throws Exception {
				
		try {
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource(); 
			
			return c.createStatement().executeUpdate("UPDATE Producto SET Activo = FALSE WHERE ID_Producto = " + ID) >= 1;
				
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {		
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
	}

	public TransferProducto readById(int IDProducto) throws Exception {
		
		TransferProducto tProducto = null;
		
		try {
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource(); // Obtenemos conexion con la BBDD
					
			ResultSet rs =  c.createStatement().executeQuery("SELECT * FROM Producto WHERE ID_Producto = " + IDProducto + " FOR UPDATE");
				
			tProducto = null;
			
			while(rs.next()) {
				TransferProducto tProductoAux = new TransferProducto();	
				tProductoAux.setIdProducto(rs.getInt("ID_Producto"));
				tProductoAux.setNombre(rs.getString("Nombre"));
				tProductoAux.setPrecio(rs.getFloat("Precio"));
				tProductoAux.setStock(rs.getInt("Stock"));
				
				if(rs.getInt("Activo") == 1)				
					tProductoAux.setActivo(true);
				else
					tProductoAux.setActivo(false);					
				tProducto = tProductoAux;
			}
				
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
        return tProducto;
				
	}

	public TransferProducto readByName(String nombre) throws Exception {
		
		TransferProducto tProducto = null;
		
		try {
			
			Connection c = (Connection)TransactionManager.getInstance().getTransaction().getResource(); // Obtenemos conexion con la BBDD
					
			ResultSet rs =  c.createStatement().executeQuery("SELECT * FROM Producto WHERE Nombre = '" + nombre + "' FOR UPDATE");
					
			tProducto = null;
			
			while(rs.next()) {
				tProducto= new TransferProducto();
				tProducto.setIdProducto(rs.getInt("ID_Producto"));
				tProducto.setNombre(rs.getString("Nombre"));
				tProducto.setPrecio(rs.getFloat("Precio"));
				tProducto.setStock(rs.getInt("Stock"));
				
				if(rs.getInt("Activo") == 1)				
					tProducto.setActivo(true);
				else
					tProducto.setActivo(false);					

			}
				
		} catch (SQLException e) {			
			e.printStackTrace();
			throw new Exception ("Problema con SQL de la BBDD");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception ("Error inesperado en la BBDD");
		}
		
        return tProducto;	
	
	}
	
}