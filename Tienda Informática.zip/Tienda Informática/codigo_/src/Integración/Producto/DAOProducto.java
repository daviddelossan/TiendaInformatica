/**
 * 
 */
package Integraci�n.Producto;

import Negocio.Producto.TransferProducto;
import java.util.ArrayList;

public interface DAOProducto {
	
	public TransferProducto muestraProducto(int ID) throws Exception;

	public ArrayList<TransferProducto> muestraProductos() throws Exception;
	
	public int creaProducto(TransferProducto tProducto) throws Exception;
	
	public boolean modificaProducto(TransferProducto TProducto) throws Exception;
	
	public boolean eliminaProducto(int ID) throws Exception;
	
	public TransferProducto readById(int IDProducto) throws Exception;

	public TransferProducto readByName(String nombre) throws Exception;
}