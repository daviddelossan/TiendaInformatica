
package Integraci�n.factoria;

import Integraci�n.Producto.DAOProducto;
import Integraci�n.Cliente.DAOCliente;
import Integraci�n.Factura.DAOFactura;

public abstract class FactoriaDAO {
	
	private static FactoriaDAO instancia;
	
	public static FactoriaDAO getInstancia() {
		
		if (instancia == null)
			instancia = new FactoriaDAOImp();

		return instancia;
	}		
	
	public abstract DAOProducto generaDAOProducto();

	public abstract DAOCliente generaDAOCliente();
	
	public abstract DAOFactura generaDAOFactura();
	
}