
package Integraci�n.factoria;

import Integraci�n.Cliente.DAOCliente;
import Integraci�n.Cliente.DAOClienteImp;
import Integraci�n.Factura.DAOFactura;
import Integraci�n.Factura.DAOFacturaImp;
import Integraci�n.Producto.DAOProducto;
import Integraci�n.Producto.DAOProductoImp;


public class FactoriaDAOImp extends FactoriaDAO {
	
	public DAOCliente generaDAOCliente() {

		return new DAOClienteImp();
			
	}
	
	public DAOFactura generaDAOFactura() {
		
		return new DAOFacturaImp();
		
	}

	public DAOProducto generaDAOProducto() {

		return new DAOProductoImp();
		
	}
}