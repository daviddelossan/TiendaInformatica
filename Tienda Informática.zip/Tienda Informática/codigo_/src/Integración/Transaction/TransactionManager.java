package Integraci�n.Transaction;

import Integraci�n.Transaction.imp.TransactionManagerImp;

public class TransactionManager {

	private static TransactionManager instancia;
	private Transaction transaction;
	
	public Transaction nuevaTransaccion() throws Exception {

		return this.transaction;
	}

	public void eliminarTransaccion() throws Exception {

	}

	public static TransactionManager getInstance() {
		if(instancia == null){
			instancia = new TransactionManagerImp();
		}
		return instancia;
	}

	public Transaction getTransaction() throws Exception {

		return null;
	}
}