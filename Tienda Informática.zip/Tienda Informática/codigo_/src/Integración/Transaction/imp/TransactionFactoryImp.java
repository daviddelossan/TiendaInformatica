package Integraci�n.Transaction.imp;

import Integraci�n.Transaction.TransactionFactory;

public class TransactionFactoryImp extends TransactionFactory {
	
	public TransactionMySQL crearTransactionMySQL() {
		return new TransactionMySQL("localhost","tiendadeinformatica_db","root","1234");
	}
	
}