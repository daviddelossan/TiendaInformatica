package Integraci�n.Transaction.imp;

public class ConcurrentHashMapThreadTransaction {

	public void containsKeythread() {

	}

	public void getcurrentThread() {

	}
}