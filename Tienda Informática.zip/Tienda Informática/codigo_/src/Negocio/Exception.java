package Negocio;

public class Exception {

	public void _new() {
	}

	public void _throw() {
	}
}