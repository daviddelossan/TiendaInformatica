package Negocio.Producto;


public class TransferProducto {

	private int ID;
	private float precio;
	private boolean activo;
	private String nombre;
	private int stock;

	public String getNombre() {

		return this.nombre;
	}

	public float getPrecio() {

		return this.precio;
	}

	public void setPrecio(float precio) {

		this.precio = precio;
	}

	public boolean getActivo() {

		return this.activo;
	}

	public void setActivo(boolean estado) {

		this.activo = estado;
	}


	public void setNombre(String nombre) {

		this.nombre = nombre;
	}


	public int getStock() {

		return this.stock;
	}

	public int getID() {

		return this.ID;
	}

	public void setStock(int cantidad) {

		this.stock = cantidad;
	}

	public void setIdProducto(int idProducto) {

		this.ID = idProducto;
	}
}