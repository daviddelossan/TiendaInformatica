package Negocio.Producto;

import java.util.ArrayList;

import Integraci�n.Cliente.DAOCliente;
import Integraci�n.Factura.DAOFactura;
import Integraci�n.Producto.DAOProducto;
import Integraci�n.Transaction.Transaction;
import Integraci�n.Transaction.TransactionManager;
import Integraci�n.factoria.FactoriaDAO;
import Integraci�n.factoria.FactoriaDAOImp;
import Negocio.Cliente.TCliente;
import Negocio.Factura.LineaFactura;
import Negocio.Factura.TransferFactura;

public class SAProductoImp implements SAProducto {

	public int altaProducto(TransferProducto TProducto) throws Exception {
		int id = -1; //Si no se crea, se quedar� con -1, o sea error

		DAOProducto daoProducto = FactoriaDAOImp.getInstancia().generaDAOProducto();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();

		if(TProducto != null){
			if(TProducto.getNombre().equalsIgnoreCase(""))
				return -1;
			try{
				TransferProducto esta = daoProducto.readByName(TProducto.getNombre());
				if(esta == null){
					transaccion.start();
					id = daoProducto.creaProducto(TProducto);
				} else{
					if(!esta.getActivo()){
						esta.setActivo(true);
						daoProducto.modificaProducto(esta);
						id = esta.getID();
					}
					else
						throw new Exception();
				}
				transaccion.commit();
			}
			catch (Exception e){
				transaccion.rollback();
			}	
			transactionManager.eliminarTransaccion();
		}

		return id;
	}

	public boolean bajaProducto(int ID) throws Exception {
		DAOProducto daoProducto = FactoriaDAOImp.getInstancia().generaDAOProducto();

		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		boolean ok = false;

		TransferProducto tProducto = daoProducto.readById(ID);

		if(tProducto != null && tProducto.getActivo()){
			try{
				transaccion.start();
				ok = daoProducto.eliminaProducto(ID);
				transaccion.commit();
			}
			catch(Exception e){
				transaccion.rollback();
			}
		}
		transactionManager.eliminarTransaccion();
		return ok;
	}


	public TransferProducto muestraProducto(int ID) throws Exception {
		DAOProducto daoProducto = FactoriaDAOImp.getInstancia().generaDAOProducto();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		TransferProducto tProducto = null;

		try{
			transaccion.start();
			tProducto = daoProducto.readById(ID);
			transaccion.commit();
		}catch(Exception e){
			transaccion.rollback();
		}

		transactionManager.eliminarTransaccion();
		return tProducto;
	}

	public ArrayList<TransferProducto> muestraProductos() throws Exception {
		DAOProducto daoProducto = FactoriaDAOImp.getInstancia().generaDAOProducto();

		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		ArrayList<TransferProducto> listaProductos = new ArrayList<TransferProducto>();

		try{
			transaccion.start();
			listaProductos = daoProducto.muestraProductos();
			transaccion.commit();
		}catch(Exception e){
			transaccion.rollback();
		}
		transactionManager.eliminarTransaccion();
		return listaProductos;
	}

	public boolean modificaProducto(TransferProducto tProducto) throws Exception {
		DAOProducto daoProducto = FactoriaDAOImp.getInstancia().generaDAOProducto();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();

		boolean ok = false;
		TransferProducto productoAux = daoProducto.readByName(tProducto.getNombre());

		if(productoAux == null || (productoAux.getID() == tProducto.getID())){
			try{
				transaccion.start();
				daoProducto.modificaProducto(tProducto);
				transaccion.commit();
				ok = true;
			} 
			catch (Exception e){
				transaccion.rollback();
			}
		}
		transactionManager.eliminarTransaccion();
		return ok;
	}

	public ArrayList<TransferFactura> consultarProducto(int idProducto) throws Exception {
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();

		FactoriaDAO factoriaDao = FactoriaDAO.getInstancia();
		DAOProducto daoProducto = factoriaDao.generaDAOProducto();
		DAOFactura daoFactura = factoriaDao.generaDAOFactura();
		ArrayList<TransferFactura> lista = new ArrayList<TransferFactura>();

		TransferProducto tProducto = daoProducto.readById(idProducto);

		if(tProducto != null){
			try{
				transaccion.start();
				lista = daoFactura.consultaProducto(idProducto);
				transaccion.commit();
			}
			catch(Exception e){
				transaccion.rollback();
			}
		}
		transactionManager.eliminarTransaccion();

		return lista;
	}
}