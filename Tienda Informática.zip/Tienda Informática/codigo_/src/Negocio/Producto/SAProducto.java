/**
 * 
 */
package Negocio.Producto;

import java.util.ArrayList;

public interface SAProducto {

	public int altaProducto(TransferProducto TProducto) throws Exception;
	public boolean bajaProducto(int ID) throws Exception;
	public TransferProducto muestraProducto(int ID) throws Exception;
	public ArrayList<TransferProducto> muestraProductos() throws Exception;
	public boolean modificaProducto(TransferProducto TProducto) throws Exception;
	public ArrayList consultarProducto(int idProducto) throws Exception;
}