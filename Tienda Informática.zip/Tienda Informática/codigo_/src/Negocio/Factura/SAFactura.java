package Negocio.Factura;

import java.io.IOException;
import java.util.ArrayList;


public interface SAFactura {

	public int altaCarrito();

	public boolean a�adirProductoCarrito(int ID, int unidades);

	public int eliminaProductoCarrito(int IDProducto);

	public TransferFactura muestraFactura(int ID) throws Exception;

	public ArrayList<TransferFactura> muestraFacturas() throws Exception;

	public TransferFactura devolucion(int IDFactura, int IDProducto, int unidades) throws Exception;

	public boolean modificaFactura(TransferFactura tFactura) throws IOException, Exception;

	public int generaFactura(TransferFactura tFactura) throws Exception;
}