package Negocio.Factura;

import java.util.ArrayList;

public class TransferFactura {

	private int IDFactura;
	private String fecha;
	private int IDCliente;
	private ArrayList lineasFactura;

	public int getIDFactura() {

		return this.IDFactura;
	}

	public void setIDFactura(int idFactura) {
		this.IDFactura = idFactura;
	}

	public int getIDCliente() {

		return this.IDCliente;
	}

	public String getFecha() {

		return this.fecha;
	}


	public void setFecha(String fecha) {

		this.fecha = fecha;
	}

	public void setIDCliente(int idCliente) {
		this.IDCliente = idCliente;
	}

	public ArrayList getProductos() {

		return this.lineasFactura;
	}

	public void setProductos(ArrayList<LineaFactura> lineasFactura) {

		this.lineasFactura = lineasFactura;
	}

	public TransferFactura(String fecha, int idCliente, int idFactura) {
		this.fecha = fecha;
		this.IDCliente = idCliente;
		this.IDFactura = idFactura;
	}

	public TransferFactura() {
	}

	public void remove() {

	}
}