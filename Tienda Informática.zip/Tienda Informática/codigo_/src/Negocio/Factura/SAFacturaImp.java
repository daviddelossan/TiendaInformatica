package Negocio.Factura;

import java.io.IOException;
import java.util.ArrayList;

import Integraci�n.Cliente.DAOCliente;
import Integraci�n.Factura.DAOFactura;
import Integraci�n.Producto.DAOProducto;
import Integraci�n.Transaction.Transaction;
import Integraci�n.Transaction.TransactionManager;
import Integraci�n.factoria.*;
import Negocio.Cliente.TCliente;
import Negocio.Producto.TransferProducto;


public class SAFacturaImp implements SAFactura {

	public int altaCarrito(int ID) { //NO SE USA

		return ID;
	}

	public boolean a�adirProductoCarrito(int ID, int unidades) { //NO SE USA

		boolean exito = true;
		
		return exito;
	}


	public int eliminaProductoCarrito(int IDProducto) { //NO SE USA

		return IDProducto;
	}

	public TransferFactura muestraFactura(int ID) throws Exception {
		DAOFactura daoFactura = FactoriaDAO.getInstancia().generaDAOFactura();

		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		TransferFactura tFactura = new TransferFactura();
		try{
			transaccion.start();
			tFactura = daoFactura.readById(ID);
			transaccion.commit();
		}catch(Exception e){
			transaccion.rollback();
		}
		
		transactionManager.eliminarTransaccion();

		return tFactura;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<TransferFactura> muestraFacturas() throws Exception {
		DAOFactura daoFactura = FactoriaDAO.getInstancia().generaDAOFactura();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		ArrayList<TransferFactura> listaFacturas = new ArrayList<TransferFactura>();

		try{
			transaccion.start();
			listaFacturas = daoFactura.muestraFacturas();
			transaccion.commit();
		}catch(Exception e){
			transaccion.rollback();
		}
		transactionManager.eliminarTransaccion();

		return listaFacturas;
	}

	
	public TransferFactura devolucion(int IDFactura, int IDProducto, int unidades) throws Exception {
		DAOFactura daoFactura = FactoriaDAO.getInstancia().generaDAOFactura();
		DAOProducto daoProducto = FactoriaDAO.getInstancia().generaDAOProducto();
		
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		TransferFactura tFactura = null;
		try{
			transaccion.start();
			
			tFactura = daoFactura.readById(IDFactura); 
			if(tFactura == null)
				throw new Exception();
			else{
				@SuppressWarnings("unchecked")
				ArrayList<LineaFactura> lineasFactura = tFactura.getProductos(); //cogemos el array
				for(int i = 0; i < lineasFactura.size(); i++)//para cada lineaFactura
					if(lineasFactura.get(i).getID() == IDProducto){//comprobamos el id del producto
						if(unidades <= lineasFactura.get(i).getCantidad()){ //si son suficientes
							TransferProducto producto = daoProducto.readById(IDProducto);
							if(producto == null)
								throw new Exception();
							int numProductos = producto.getStock();
							numProductos += unidades;
							producto.setStock(numProductos);
							daoProducto.modificaProducto(producto);
							lineasFactura.get(i).setCantidad(lineasFactura.get(i).getCantidad() - unidades); 
							tFactura.setProductos(lineasFactura);
							daoFactura.modificaFactura(tFactura);
							//return tFactura;
						}
						else {
							throw new Exception();
						}
					}
					else{
						throw new Exception();
					}
			}	
			transaccion.commit();
		}catch(Exception e){
			tFactura = null;
			transaccion.rollback();
		}
		transactionManager.eliminarTransaccion();

		return tFactura;
	}

	public int generaFactura(TransferFactura tFactura) throws Exception {
		int id = -1; //Si no se crea, se quedar� con -1, o sea error

		DAOFactura daoFactura = FactoriaDAO.getInstancia().generaDAOFactura();

		int idCliente = tFactura.getIDCliente();
		DAOCliente daoCliente = FactoriaDAO.getInstancia().generaDAOCliente();
		
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();		
		

		try{
			transaccion.start();
			TCliente transferCliente = daoCliente.readById(idCliente);
			///////////////////////////////////
			/*
			TCliente transferCliente = new TCliente();
			transferCliente.setActivo(true);
			transferCliente.setCorreo("correo");
			transferCliente.setDireccion("direccion");
			transferCliente.setID(1);
			transferCliente.setNombre("nombre");
			transferCliente.setTelefono(9188);
			*/
			//////////////////////////////////////
			if(transferCliente != null && transferCliente.getActivo()) {
				for(int i = 0; i < tFactura.getProductos().size(); i++) {
					int idProducto = ((LineaFactura) tFactura.getProductos().get(i)).getID();
					DAOProducto daoProducto = FactoriaDAO.getInstancia().generaDAOProducto();
					TransferProducto transferProductoObtenido = daoProducto.readById(idProducto);
					if(transferProductoObtenido != null && transferProductoObtenido.getActivo()) {
						int cantidad = ((LineaFactura) tFactura.getProductos().get(i)).getCantidad();
						int stockAnterior = transferProductoObtenido.getStock();
						if(cantidad <= transferProductoObtenido.getStock()) {
							transferProductoObtenido.setStock(stockAnterior-cantidad);
							daoProducto.modificaProducto(transferProductoObtenido);
							float precioActualProducto = transferProductoObtenido.getPrecio();
							((LineaFactura) tFactura.getProductos().get(i)).setPrecio(precioActualProducto);
						}
						else {
							//Append a log
							tFactura.getProductos().remove(i); //Eliminamos este producto, ya no es valido
						}
					}
					else {
						tFactura.getProductos().remove(i); //Eliminamos este producto, ya no es valido
					}

				} //Fin for

				if(tFactura.getProductos().size() > 0) {
					id = daoFactura.creaFactura(tFactura);
				} else
					throw new Exception();
			}  else //Fin if
				throw new Exception();
			
			transaccion.commit();
		}catch(Exception e){
			transaccion.rollback();
		}
		
		transactionManager.eliminarTransaccion();

		return id;
	}

	
	public boolean modificaFactura(TransferFactura tFactura) throws Exception{ //NO SE USA
		DAOFactura daoFactura = FactoriaDAO.getInstancia().generaDAOFactura();
		
		
		
		return daoFactura.modificaFactura(tFactura);
	}

	public int altaCarrito() { //NO SE USA

		return 0;
	}
}