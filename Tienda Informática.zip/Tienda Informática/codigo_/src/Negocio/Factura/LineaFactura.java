package Negocio.Factura;

public class LineaFactura {
	private int producto;

	
	public LineaFactura() {
		// TODO Ap�ndice de constructor generado autom�ticamente
	}
	
	public LineaFactura(int id, int cantidad, int precio, int producto) {
		this.id = id;
		this.setProducto(producto);
		this.cantidad = cantidad;
		this.precio = precio;
	}
	
	private float precio;
	private int cantidad;
	private int id;
	public float getPrecio() {

		return this.precio;
	}

	public void setPrecio(float precio) {

		this.precio = precio;
	}

	public int getCantidad() {

		return this.cantidad;
	}

	public int getID() {

		return this.id;
	}

	public void setCantidad(int cantidad) {

		this.cantidad = cantidad;
	}

	public void setID(int idProducto) {
		
		this.id = idProducto;
	}

	public void setProducto(int producto) {
		this.producto = producto;
	}

	public int getProducto() {
		return producto;
	}
}