package Negocio.Cliente;

import java.util.ArrayList;

import Integraci�n.Cliente.DAOCliente;
import Integraci�n.Factura.DAOFactura;
import Integraci�n.Transaction.Transaction;
import Integraci�n.Transaction.TransactionManager;
import Integraci�n.factoria.FactoriaDAO;
import Negocio.Factura.TransferFactura;
import Negocio.Producto.TransferProducto;

public class SAClienteImp implements SACliente {

	public int altaCliente(TCliente tCliente) throws Exception {
		int id = -1; //Si no se crea, se quedar� con -1, o sea error

		DAOCliente daoCliente = FactoriaDAO.getInstancia().generaDAOCliente();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		if(tCliente != null) {
			if (tCliente.getCorreo().equalsIgnoreCase(""))
				id = -1;

			else{
				TCliente esta = daoCliente.readByName(tCliente.getCorreo());

				if(esta == null){
					try{
						transaccion.start();
						id = daoCliente.creaCliente(tCliente);
						transaccion.commit();
					}
					catch (Exception e){
						transaccion.rollback();
					}

				}
				else{
					if(!esta.getActivo()){
						esta.setActivo(true);
						daoCliente.modificaCliente(esta);
						id = esta.getID();
					}
					else id = -1;
				}	
			}
		}
		transactionManager.eliminarTransaccion();

		return id;
	}

	@Override
	public boolean bajaCliente(int ID) throws Exception {
		DAOCliente daoCliente = FactoriaDAO.getInstancia().generaDAOCliente();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		boolean ok = false;

		TCliente tCliente = daoCliente.readById(ID);
		if(tCliente != null && tCliente.getActivo()){
			try{
				transaccion.start();
				ok = daoCliente.eliminaCliente(ID);
				transaccion.commit();
			}
			catch(Exception e){
				transaccion.rollback();
			}
		}
		transactionManager.eliminarTransaccion();
		return ok;
	}

	@Override
	public boolean modificaCliente(TCliente tCliente) throws Exception {
		DAOCliente daoCliente = FactoriaDAO.getInstancia().generaDAOCliente();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();

		boolean ok = false;

		TCliente transferCliente = daoCliente.readByName(tCliente.getCorreo());

		if(transferCliente == null || (transferCliente.getID() == tCliente.getID())){//Vemos si no existe un cliente con el mismo correo alg�n error
			try{
				transaccion.start();
				daoCliente.modificaCliente(tCliente);
				transaccion.commit();
				ok = true;
			}
			catch(Exception e){
				transaccion.rollback();
			}

		}
		else
			ok = false;

		transactionManager.eliminarTransaccion();
		return ok;
	}

	public TCliente muestraCliente(int ID) throws Exception {
		DAOCliente daoCliente = FactoriaDAO.getInstancia().generaDAOCliente();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		TCliente tCliente = new TCliente();

		try{
			transaccion.start();
			tCliente = daoCliente.readById(ID);
			transaccion.commit();
		}catch(Exception e){
			transaccion.rollback();
		}
		transactionManager.eliminarTransaccion();

		return tCliente;
	}

	public ArrayList<TCliente> muestraClientes() throws Exception {
		DAOCliente daoCliente = FactoriaDAO.getInstancia().generaDAOCliente();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();
		ArrayList<TCliente> listaCliente = new ArrayList<TCliente>();

		try{
			transaccion.start();
			listaCliente = daoCliente.muestraClientes();
			transaccion.commit();
		}catch(Exception e){
			transaccion.rollback();
		}
		transactionManager.eliminarTransaccion();

		return listaCliente;
	}

	public ArrayList<TransferFactura> consultaClientesFactura(int idCliente) throws Exception {
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaccion = transactionManager.nuevaTransaccion();

		FactoriaDAO factoriaDao = FactoriaDAO.getInstancia();
		DAOCliente daoCliente = factoriaDao.generaDAOCliente();
		DAOFactura daoFactura = factoriaDao.generaDAOFactura();
		ArrayList<TransferFactura> lista = new ArrayList<TransferFactura>();

		TCliente tCliente = daoCliente.readById(idCliente);

		if(tCliente != null){
			try{
			transaccion.start();

			lista = daoFactura.consultaFacturas(idCliente);	
			transaccion.commit();
		}
		catch(Exception e){
			transaccion.rollback();
		}
	}
	transactionManager.eliminarTransaccion();

	return lista;
}
}