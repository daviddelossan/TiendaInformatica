package Negocio.Cliente;

import java.util.ArrayList;

import Negocio.Factura.TransferFactura;


public interface SACliente {

	public int altaCliente(TCliente tCliente) throws Exception;

	public boolean bajaCliente(int ID) throws Exception;

	public boolean modificaCliente(TCliente TCliente) throws Exception;

	public TCliente muestraCliente(int ID) throws Exception;

	public ArrayList<TCliente> muestraClientes() throws Exception;
	
	public ArrayList<TransferFactura> consultaClientesFactura(int idCliente) throws Exception;
}