package Negocio.Factoria;

import Negocio.Cliente.SACliente;
import Negocio.Cliente.SAClienteImp;
import Negocio.Producto.SAProducto;
import Negocio.Producto.SAProductoImp;
import Negocio.Factura.SAFactura;
import Negocio.Factura.SAFacturaImp;


public class FactoriaSAImpl extends FactoriaSA {

	public SACliente generaSACliente() {

		return new SAClienteImp();
	}


	public SAProducto generaSAProducto() {

		return new SAProductoImp();
	}

	public SAFactura generaSAFactura() {

		return new SAFacturaImp();
	}
}