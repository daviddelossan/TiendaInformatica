package Negocio.Factoria;

import Negocio.Cliente.SACliente;
import Negocio.Producto.SAProducto;
import Negocio.Factura.SAFactura;


public abstract class FactoriaSA {

	private static FactoriaSA instancia;


	public static FactoriaSA getInstancia() {
		if(instancia == null)
			instancia =	new FactoriaSAImpl();
		return instancia;
	}

	public abstract SACliente generaSACliente();
	public abstract SAProducto generaSAProducto();
	public abstract SAFactura generaSAFactura();
}