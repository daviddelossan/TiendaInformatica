package Presentacion.FrameTienda;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JOptionPane;

import Negocio.Factura.LineaFactura;
import Negocio.Factura.TransferFactura;
import Presentacion.Factura.JFrameFactura;
import Presentacion.controlador.*;

public class JFrameFacturaImp extends JFrameFactura {

	private static final long serialVersionUID = -8163764029489439376L;
	private TransferFactura tFactura; //Se hace en memoria esta gesti�n, por eso se pone aqui como atributo
	

    public JFrameFacturaImp() {
    	super("Factura");
        initComponents();
    }
                   
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        IDFactura = new javax.swing.JTextField();
        facturaCantidadProducto = new javax.swing.JTextField();
        facturaProducto = new javax.swing.JTextField();
        facturaIDCliente = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        carritoComboBox = new javax.swing.JComboBox();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        OKFactura = new javax.swing.JButton();
        comboBoxFactura = new javax.swing.JComboBox();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        OKCarrito = new javax.swing.JButton();
        aniadeCliente = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

      //===========================================================   
        OKFactura.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
            	OKFacturaActionPerformed(evt);
            }
        });
        OKCarrito.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
            	OKCarritoActionPerformed(evt);
            }
        });
        
        aniadeCliente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
            	aniadeClienteActionPerformed(evt);
            }
        });
        
        
     //===========================================================   
        
        IDFactura.setEnabled(false);
        IDFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IDFacturaActionPerformed(evt);
            }
        });

        facturaCantidadProducto.setEnabled(false);
        facturaCantidadProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                facturaCantidadProductoActionPerformed(evt);
            }
        });

        facturaProducto.setEnabled(false);
        facturaProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                facturaProductoActionPerformed(evt);
            }
        });

        facturaIDCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                facturaIDClienteActionPerformed(evt);
            }
        });

        jLabel12.setText("ID CLIENTE:");

        carritoComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "A�ADE PRODUCTO", "ELIMINA PRODUCTO" }));
        carritoComboBox.setEnabled(false);
        carritoComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carritoComboBoxActionPerformed(evt);
            }
        });

        jLabel13.setText("ID PRODUCTO:");

        jLabel14.setText("CANTIDAD:");

        jLabel15.setText("ID FACTURA:");

        OKFactura.setText("OK");
        OKFactura.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OKFacturaMouseClicked(evt);
            }
        });

        comboBoxFactura.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PAGAR", "DEVOLUCION", "MUESTRA", "MUESTRA TODO" }));
        comboBoxFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxFacturaActionPerformed(evt);
            }
        });

        jTextArea5.setColumns(20);
        jTextArea5.setRows(5);
        jScrollPane5.setViewportView(jTextArea5);

        OKCarrito.setText("OK Carrito");
        OKCarrito.setEnabled(false);

        aniadeCliente.setText("A�ADE CLIENTE");
        aniadeCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aniadeClienteMouseClicked(evt);
            }
        });
 

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(carritoComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel13))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(facturaProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(facturaCantidadProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(OKCarrito)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(comboBoxFactura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(IDFactura, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(OKFactura))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(facturaIDCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(aniadeCliente)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(facturaIDCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(aniadeCliente))
                .addGap(7, 7, 7)
                .addComponent(carritoComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(facturaProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(OKCarrito))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(facturaCantidadProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(comboBoxFactura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(IDFactura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(OKFactura))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 576, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 382, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>                        

    private void IDFacturaActionPerformed(java.awt.event.ActionEvent evt) {                                          
        // TODO add your handling code here:
    }                                         

    private void facturaCantidadProductoActionPerformed(java.awt.event.ActionEvent evt) {                                                        
        // TODO add your handling code here:
    }                                                       

    private void facturaProductoActionPerformed(java.awt.event.ActionEvent evt) {                                                
        // TODO add your handling code here:
    }                                               

    private void facturaIDClienteActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        // TODO add your handling code here:
    }                                                

    private void carritoComboBoxActionPerformed(java.awt.event.ActionEvent evt) {                                                
        String opcion = carritoComboBox.getSelectedItem().toString();
        if(opcion.equals("A�ADE PRODUCTO")){
            facturaProducto.setEnabled(true);
            facturaProducto.setEnabled(true);
        }
    }                                               

    private void comboBoxFacturaActionPerformed(java.awt.event.ActionEvent evt) {                                                
        String opcion = comboBoxFactura.getSelectedItem().toString();
       if(opcion.equals("PAGAR")){
           IDFactura.setEnabled(false);
           facturaProducto.setEnabled(false);
           facturaCantidadProducto.setEnabled(false);
           aniadeCliente.setEnabled(true);
           facturaIDCliente.setEnabled(true);
       }
       if(opcion.equals("DEVOLUCION")){
           IDFactura.setEnabled(true);
           facturaProducto.setEnabled(true);
           facturaCantidadProducto.setEnabled(true);
           aniadeCliente.setEnabled(false);
           facturaIDCliente.setEnabled(false);
           OKCarrito.setEnabled(false);
           carritoComboBox.setEnabled(false);
           

       }
       if(opcion.equals("MUESTRA")){
         IDFactura.setEnabled(true);
           facturaProducto.setEnabled(false);
           facturaCantidadProducto.setEnabled(false);
           facturaIDCliente.setEnabled(false);
           aniadeCliente.setEnabled(false);
           OKCarrito.setEnabled(false);
           carritoComboBox.setEnabled(false);
           
       }
       if(opcion.equals("MUESTRA TODO")){
            IDFactura.setEnabled(false);
           facturaProducto.setEnabled(false);
           facturaCantidadProducto.setEnabled(false);
           aniadeCliente.setEnabled(false);
           facturaIDCliente.setEnabled(false);
           OKCarrito.setEnabled(false);
           carritoComboBox.setEnabled(false);
       }
    }                                               


                                         

    private void aniadeClienteMouseClicked(java.awt.event.MouseEvent evt) {                                           
            facturaIDCliente.setEnabled(false);
            aniadeCliente.setEnabled(false);
            facturaProducto.setEnabled(true);
            facturaCantidadProducto.setEnabled(true);
            carritoComboBox.setEnabled(true);
            OKCarrito.setEnabled(true);
    }                                          

    private void OKFacturaMouseClicked(java.awt.event.MouseEvent evt) {                                       
      String opcion = comboBoxFactura.getSelectedItem().toString();
       if(opcion.equals("PAGAR")){
            facturaIDCliente.setEnabled(true);
            aniadeCliente.setEnabled(true);
            facturaProducto.setEnabled(false);
            facturaCantidadProducto.setEnabled(false);
            carritoComboBox.setEnabled(false);
            OKCarrito.setEnabled(false);
            facturaProducto.setText("");
            facturaCantidadProducto.setText("");
            
       }
    }                                      

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFrameFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFrameFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFrameFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFrameFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFrameFacturaImp().setVisible(true);
            }
        });
    }
   
   //==================================================================================== 
    //==================================================================================== 

    protected void OKFacturaActionPerformed(ActionEvent evt) {
    	String opcion = comboBoxFactura.getSelectedItem().toString();
    	Context contexto = new Context(0, null);
    	
    	
    	if(opcion.equals("PAGAR")){
    		Date fecha = new Date();
    		this.tFactura.setFecha(fecha.toString());
    		contexto.setEvento(EventoNegocio.GENERA_FACTURA);
    		contexto.setDatos(this.tFactura);
    		AppControlador.getInstancia().accion(contexto);
    	}else
    		if(opcion.equals("DEVOLUCION")){
    			int idFactura = Integer.parseInt(IDFactura.getText());
    	  		int idProducto = Integer.parseInt(facturaProducto.getText());
    	  		int cantidadProducto = Integer.parseInt(facturaCantidadProducto.getText());
    	  		ArrayList<Object> array = new ArrayList<Object>();
    	  		array.add(idFactura);
    	  		array.add(idProducto);
    	  		array.add(cantidadProducto);
    	  		contexto.setEvento(EventoNegocio.DEVOLUCION_FACTURA);
    	  		contexto.setDatos(array);
    			AppControlador.getInstancia().accion(contexto);
    		} else
    			if(opcion.equals("MUESTRA")){
    				int idFactura = Integer.parseInt(IDFactura.getText());
    				contexto.setEvento(EventoNegocio.MUESTRA_FACTURA);
        	  		contexto.setDatos(idFactura);
        	  		AppControlador.getInstancia().accion(contexto);
    			} else
    				if(opcion.equals("MUESTRA TODO")){
    					contexto.setEvento(EventoNegocio.MUESTRA_FACTURAS);
            	  		contexto.setDatos(null);
    					AppControlador.getInstancia().accion(contexto);
    				}
    	
    	
    }
  @SuppressWarnings("unchecked")
protected void OKCarritoActionPerformed(ActionEvent evt) {
	  String opcion = carritoComboBox.getSelectedItem().toString();
	  ContextRetorno contexto = new ContextRetorno(0, null);
	  
  	if(opcion.equals("A�ADE PRODUCTO")){
  		int idProducto = Integer.parseInt(facturaProducto.getText());
  		int cantidadProducto = Integer.parseInt(facturaCantidadProducto.getText());
  		LineaFactura lFactura = new LineaFactura();
  		lFactura.setID(idProducto);
  		lFactura.setCantidad(cantidadProducto);
  		if(this.tFactura != null) {
  			if(this.tFactura.getProductos() == null)
  				this.tFactura.setProductos(new ArrayList<LineaFactura>());
  	  		this.tFactura.getProductos().add(lFactura);
  	  	contexto.setEvento(EventoGUI.ANADIR_PRODUCTO_CARRITO_OK);
  	  	contexto.setDatos(idProducto);
  	  		this.update(contexto);
  		}else {
  			contexto.setEvento(EventoGUI.ANADIR_PRODUCTO_CARRITO_ERROR);
  	  	  	contexto.setDatos(idProducto);
  		  	this.update(contexto);
  		}
  	}else
  		if(opcion.equals("ELIMINA PRODUCTO")){
  			int idProducto = Integer.parseInt(facturaProducto.getText());
  	  		//int cantidadProducto = Integer.parseInt(facturaCantidadProducto.getText());
  			boolean encontrado = false;
  			int size = this.tFactura.getProductos().size();
  			int i = 0;
  			while(!encontrado && i < size) {
  				if((Integer)((LineaFactura) this.tFactura.getProductos().get(i)).getID() == idProducto)
  					encontrado = true;
  				else
  					i++;
  			}
  			if(encontrado) {
  				this.tFactura.getProductos().remove(i);
  				//remove(idProducto);
  	  			contexto.setEvento(EventoGUI.ELIMINAR_PRODUCTO_CARRITO_OK);
  	  			contexto.setDatos(idProducto);
  	  			this.update(contexto);
  			} else{
  				contexto.setEvento(EventoGUI.ELIMINAR_PRODUCTO_CARRITO_ERROR);
  		  	  	contexto.setDatos(idProducto);
  	  	  	  	this.update(contexto);
  			}
  			} 

    }
    
  protected void aniadeClienteActionPerformed(ActionEvent evt) {
	this.tFactura = new TransferFactura();
	int idCliente = Integer.parseInt(facturaIDCliente.getText());
	this.tFactura.setIDCliente(idCliente);
	ContextRetorno contexto = new ContextRetorno(0,null);

	
	if(idCliente >= 0) {
		contexto.setEvento(EventoGUI.ALTA_CARRITO_OK);
	  	contexto.setDatos(idCliente);
		this.update(contexto);
	}
	else {
		contexto.setEvento(EventoGUI.ALTA_CARRITO_OK);
	  	contexto.setDatos(idCliente);
		this.update(contexto);
	}
	 facturaIDCliente.setEnabled(false);
     aniadeCliente.setEnabled(false);
     facturaProducto.setEnabled(true);
     facturaCantidadProducto.setEnabled(true);
     carritoComboBox.setEnabled(true);
     OKCarrito.setEnabled(true);
  }
    
    
	public void update(ContextRetorno contextEntrada) {
		int evento = contextEntrada.getEvento();
		Object datos = contextEntrada.getDatos();
		
		switch(evento) {
		case(EventoGUI.ALTA_CARRITO_OK): {
			JOptionPane.showMessageDialog (
				null, "Carrito de la compra dado de alta, para el cliente con ID: " + (Integer)datos
			);
			break;
		}

		case(EventoGUI.ALTA_CARRITO_ERROR): {
			JOptionPane.showMessageDialog(
					null, "Error al dar de alta el carrito de la compra, para el cliente con ID" + (Integer)datos
				);
			break;
		}
		
		case(EventoGUI.GENERA_FACTURA_OK): {
			JOptionPane.showMessageDialog (
				null, "Factura generada correctamente, con ID: " + ((TransferFactura)datos).getIDFactura()
			);
			//textFieldIdFactura.setText((Integer)datos);
			break;
		}
		
		case(EventoGUI.ELIMINAR_PRODUCTO_CARRITO_OK): {
			jTextArea5.setText(jTextArea5.getText() + "\n" + "Producto eliminado del carrito correctamente"+ "\n");
			//textFieldIdFactura.setText((Integer)datos);
			break;
		}

		case(EventoGUI.ELIMINAR_PRODUCTO_CARRITO_ERROR): {
			JOptionPane.showMessageDialog (
				null, "Error al eliminar el producto, con ID: " + (Integer)datos
			);
			//textFieldIdFactura.setText((Integer)datos);
			break;
		}
		
		case(EventoGUI.GENERA_FACTURA_ERROR): {
			JOptionPane.showMessageDialog(null, "Error al generar la factura");
			break;
		}
		
		case(EventoGUI.ANADIR_PRODUCTO_CARRITO_OK): {
			//JOptionPane.showMessageDialog(null, "Producto a�adido");
			//Es incomodo que cada vez que a�adimos un producto nos diga "Producto a�adido en un dialog
			//Mejor as�:
			jTextArea5.setText(jTextArea5.getText() + "\n" + "Producto A�adido al carrito correctamente" + "\n");
			break;
		}
		
		case(EventoGUI.ANADIR_PRODUCTO_CARRITO_ERROR): {
			JOptionPane.showMessageDialog(null, "Error al a�adir el producto");
			break;
		}
		
		case(EventoGUI.MUESTRA_FACTURAS_ERROR): {
			JOptionPane.showMessageDialog(null, "No hay ninguna factura");
			break;
		}
		
		case(EventoGUI.MUESTRA_FACTURAS_OK): {
			 @SuppressWarnings("unchecked")
			ArrayList<TransferFactura> todasFacturas = (ArrayList<TransferFactura>)datos;
			 jTextArea5.setText("");
			for(int i = 0; i < todasFacturas.size(); i++) {
				TransferFactura tFactura = todasFacturas.get(i);
				jTextArea5.setText(jTextArea5.getText() +  muestraFactura(tFactura) + "\n");
			}
			
			break;
		}
		
		case(EventoGUI.DEVOLUCION_OK): {
			JOptionPane.showMessageDialog (
				null, "Devolucion realizada con exito"
			);
			//textFieldIdFactura.setText((Integer)datos);
			break;
		}
		
		case(EventoGUI.DEVOLUCION_ERROR): {
			JOptionPane.showMessageDialog (
				null, "Error al realizar la devolucion referente a la factura"
			);
			//textFieldIdFactura.setText((Integer)datos);
			break;
		}
		
		case(EventoGUI.MUESTRA_FACTURA_OK): {
			jTextArea5.setText(muestraFactura((TransferFactura)datos) + "\n");
			//textFieldIdFactura.setText((Integer)datos);
			break;
		}
		case(EventoGUI.MUESTRA_FACTURA_ERROR): {
			JOptionPane.showMessageDialog (
				null, "Error al mostrar la factura" + "\n"
			);
			//textFieldIdFactura.setText((Integer)datos);
			break;
		}
		
		
		
		} //FIN SWITCH

	} //Fin metodo update

	private String muestraFactura(TransferFactura factura) {
		String facturaMostrada = "";
		facturaMostrada+= "---------Factura " + factura.getIDFactura()		+ "--------- \n";
		facturaMostrada += "ID Cliente: " + factura.getIDCliente() + "\n";
		facturaMostrada += "Fecha: " + factura.getFecha() + "\n";
		facturaMostrada += "Productos: " + "\n";

		for(int i = 0; i < factura.getProductos().size(); i++) {
			facturaMostrada += "---------Producto " + (i+1) + "--------- \n";
			facturaMostrada += muestraLineaFactura((LineaFactura)factura.getProductos().get(i));
		}
		facturaMostrada+= "\n";
		facturaMostrada+= "\n";
		return facturaMostrada;
	}
    
	
	private String muestraLineaFactura(LineaFactura lFactura) {
		String lFacturaMostrada = "";
		lFacturaMostrada += "ID Producto: " + lFactura.getID() + "\n";
		lFacturaMostrada += "Cantidad: " + lFactura.getCantidad() + "\n";
		lFacturaMostrada += "Precio: " + lFactura.getPrecio() + "\n";

		return lFacturaMostrada;
	}
	
    
    
    
    
 

    // Variables declaration - do not modify                     
    private javax.swing.JTextField IDFactura;
    private javax.swing.JButton OKCarrito;
    private javax.swing.JButton OKFactura;
    private javax.swing.JButton aniadeCliente;
    private javax.swing.JComboBox carritoComboBox;
    private javax.swing.JComboBox comboBoxFactura;
    private javax.swing.JTextField facturaCantidadProducto;
    private javax.swing.JTextField facturaIDCliente;
    private javax.swing.JTextField facturaProducto;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTextArea jTextArea5;
    // End of variables declaration                   



}