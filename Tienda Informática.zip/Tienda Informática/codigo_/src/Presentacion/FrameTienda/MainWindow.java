package Presentacion.FrameTienda;

import Presentacion.Cliente.JFrameCliente;
import Presentacion.Factura.JFrameFactura;
import Presentacion.Producto.JFrameProducto;

public class MainWindow {
	
	public static void main(String[] args)
	{
		java.awt.EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				JFrameProducto jFrameProducto = JFrameProducto.getInstancia();
				JFrameCliente jFrameCliente = JFrameCliente.getInstancia();
				JFrameFactura jFrameFactura = JFrameFactura.getInstancia();
				jFrameProducto.setVisible(true);
				jFrameCliente.setVisible(true);
				jFrameFactura.setVisible(true);
			}
		});
	}
}