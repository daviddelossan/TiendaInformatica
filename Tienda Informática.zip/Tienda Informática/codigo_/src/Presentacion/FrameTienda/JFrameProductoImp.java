
package Presentacion.FrameTienda;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Negocio.Factura.TransferFactura;
import Negocio.Producto.TransferProducto;
import Presentacion.Producto.JFrameProducto;
import Presentacion.controlador.AppControlador;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;
import Presentacion.controlador.EventoNegocio;


public class JFrameProductoImp  extends JFrameProducto {

	private static final long serialVersionUID = -2027508712530778895L;
		public JFrameProductoImp() {
	    	super("Producto");
	        initComponents();
	    }


    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        comboBoxProducto = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        nombreProducto = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        IDProducto = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        stockProducto = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        precioProducto = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        area = new javax.swing.JTextArea();
        OkProducto = new javax.swing.JButton();
        Modifica = new javax.swing.JButton();

        IDProducto.setEnabled(false);
        Modifica.setVisible(false);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        comboBoxProducto.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "ALTA", "BAJA", "MODIFICA", "MUESTRA", "MUESTRA TODOS", "CONSULTAR PRODUCTO" }));
        comboBoxProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxProductoActionPerformed(evt);
            }
        });

        jLabel1.setText("Nombre:");

        nombreProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreProductoActionPerformed(evt);
            }
        });

        jLabel2.setText("ID:");

        IDProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IDProductoActionPerformed(evt);
            }
        });

        jLabel3.setText("Stock:");

        stockProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stockProductoActionPerformed(evt);
            }
        });

        jLabel4.setText("Precio:");

        precioProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precioProductoActionPerformed(evt);
            }
        });

        area.setEditable(false);
        area.setColumns(20);
        area.setRows(5);
        jScrollPane1.setViewportView(area);

        OkProducto.setText("OK");
        OkProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OkProductoMouseClicked(evt);
            }
        });
        OkProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OkProductoActionPerformed(evt);
            }
        });

        Modifica.setText("Modifica");
        Modifica.setEnabled(false);
        Modifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificaActionPerformed(evt);
            }
        });

        Modifica.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ModificaMouseClicked(evt);
            }
        });
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(5, 5, 5)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel1)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(IDProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(nombreProducto)
                                    .addComponent(stockProducto)
                                    .addComponent(precioProducto)))
                            .addComponent(comboBoxProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(OkProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Modifica))
                        .addGap(0, 241, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(comboBoxProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(nombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(IDProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(stockProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Modifica))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(precioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(OkProducto)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }                     

    private void actualiza(){
    	 javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
         jPanel1.setLayout(jPanel1Layout);
         jPanel1Layout.setHorizontalGroup(
             jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
             .addGroup(jPanel1Layout.createSequentialGroup()
                 .addContainerGap()
                 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                     .addComponent(jScrollPane1)
                     .addGroup(jPanel1Layout.createSequentialGroup()
                         .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                             .addGroup(jPanel1Layout.createSequentialGroup()
                                 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                     .addGroup(jPanel1Layout.createSequentialGroup()
                                         .addGap(5, 5, 5)
                                         .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                             .addComponent(jLabel1)
                                             .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                     .addComponent(jLabel3)
                                     .addComponent(jLabel4))
                                 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                     .addGroup(jPanel1Layout.createSequentialGroup()
                                         .addComponent(IDProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                         .addGap(0, 0, Short.MAX_VALUE))
                                     .addComponent(nombreProducto)
                                     .addComponent(stockProducto)
                                     .addComponent(precioProducto)))
                             .addComponent(comboBoxProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                         .addGap(18, 18, 18)
                         .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                             .addComponent(OkProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                             .addComponent(Modifica))
                         .addGap(0, 241, Short.MAX_VALUE)))
                 .addContainerGap())
         );
         jPanel1Layout.setVerticalGroup(
             jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
             .addGroup(jPanel1Layout.createSequentialGroup()
                 .addComponent(comboBoxProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                     .addComponent(jLabel1)
                     .addComponent(nombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                     .addComponent(jLabel2)
                     .addComponent(IDProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                     .addComponent(jLabel3)
                     .addComponent(stockProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                     .addComponent(Modifica))
                 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                     .addComponent(jLabel4)
                     .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                         .addComponent(precioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                         .addComponent(OkProducto)))
                 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                 .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                 .addContainerGap())
         );

         javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
         getContentPane().setLayout(layout);
         layout.setHorizontalGroup(
             layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
             .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                 .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                 .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                 .addContainerGap())
         );
         layout.setVerticalGroup(
             layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
             .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                 .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                 .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                 .addContainerGap())
         );

         pack();
    }
	
	private void ModificaMouseClicked(java.awt.event.MouseEvent evt) {
			TransferProducto producto = new TransferProducto();
			producto.setNombre(nombreProducto.getText());
			producto.setIdProducto(Integer.parseInt(IDProducto.getText()));
			producto.setPrecio(Float.parseFloat(precioProducto.getText()));
			producto.setStock(Integer.parseInt(stockProducto.getText()));
			producto.setActivo(estado);
			AppControlador.getInstancia().accion(new Context(EventoNegocio.MODIFICA_PRODUCTO,producto));
			OkProducto.setEnabled(true);
			IDProducto.setEnabled(true);
			nombreProducto.setEnabled(false);
			stockProducto.setEnabled(false);
			precioProducto.setEnabled(false);
			Modifica.setEnabled(false);
			comboBoxProducto.setEnabled(true);
		} 
	    
	    private void reiniciaComponentes() {
			IDProducto.setText("");
			nombreProducto.setText("");
			stockProducto.setText("");
			precioProducto.setText("");
			area.setText("");

		}
	    
	    public void update(ContextRetorno context) {
	    		switch(context.getEvento()) {

	    		case EventoGUI.ALTA_PRODUCTO_OK:{JOptionPane.showMessageDialog(null,
	    				"Producto dado de alta: " + ((TransferProducto)context.getDatos()).getNombre(), 
	    				"OK", 			
	    				JOptionPane.PLAIN_MESSAGE);
	    		};break;

	    		case EventoGUI.ALTA_PRODUCTO_ERROR:{
	    			JOptionPane.showMessageDialog(null,
	    					"No se pudo dar de alta",   			 	
	    					"ERROR", //T�tulo
	    					JOptionPane.ERROR_MESSAGE);
	    		};break;



	    		case EventoGUI.BAJA_PRODUCTO_OK:{JOptionPane.showMessageDialog(null,
	    				"Producto dado de baja: " + ((TransferProducto)context.getDatos()).getID(), //Mensaje
	    				"OK", //T�tulo			
	    				JOptionPane.PLAIN_MESSAGE);
	    		};break;

	    		case EventoGUI.BAJA_PRODUCTO_ERROR:{
	    			JOptionPane.showMessageDialog(null,
	    					"No se pudo dar de baja", //Mensaje  				
	    					"ERROR", //T�tulo
	    					JOptionPane.ERROR_MESSAGE);
	    		};break;

	    		case(EventoGUI.MODIFICA_PRODUCTO_OK): {
	    			JOptionPane.showMessageDialog(null,
	    					"Producto actualizado", //Mensaje
	    					"OK", //T�tulo			
	    					JOptionPane.PLAIN_MESSAGE);
	    		};break;

	    		case(EventoGUI.MODIFICA_PRODUCTO_ERROR): {
	    			JOptionPane.showMessageDialog(null,
	    					"Ya existe un producto con ese nombre", //Mensaje  				
	    					"ERROR", //T�tulo
	    					JOptionPane.ERROR_MESSAGE);
	    		};break;

	    		case(EventoGUI.MUESTRA_PRODUCTO_OK): {
	    			area.setText(muestraProducto((TransferProducto)context.getDatos()));

	    		};break;
	    		case(EventoGUI.MUESTRA_PRODUCTO_ERROR): {
	    			JOptionPane.showMessageDialog(null,
	    					"No existe el producto", //Mensaje  				
	    					"ERROR", //T�tulo
	    					JOptionPane.ERROR_MESSAGE);
	    		};break;

	    		case(EventoGUI.MUESTRA_TODOS_PRODUCTO_OK): {
	    			@SuppressWarnings("unchecked")
	    			ArrayList<TransferProducto> todosProductos = (ArrayList<TransferProducto>)context.getDatos();

	    			for(int i = 0; i < todosProductos.size(); i++) {
	    				TransferProducto elemento = todosProductos.get(i);
	    				area.setText(area.getText() + muestraProducto(elemento) + "\n");
	    			}
	    		};break;

	    		case(EventoGUI.MUESTRA_TODOS_PRODUCTO_ERROR): {JOptionPane.showMessageDialog(null,
	    				"No existen productos", //Mensaje  				
	    				"ERROR", //T�tulo
	    				JOptionPane.ERROR_MESSAGE);
	    		};break;

	    		case EventoGUI.MUESTRA_PRODUCTO_TEXTFIELDS:{
	    			TransferProducto producto = (TransferProducto)context.getDatos();
	    			estado = producto.getActivo();
	    			nombreProducto.setText(producto.getNombre());
	    			precioProducto.setText(Float.toString(producto.getPrecio()));
	    			stockProducto.setText(Integer.toString(producto.getStock()));
	    			IDProducto.setEnabled(false);
	    			nombreProducto.setEnabled(true);
	    			precioProducto.setEnabled(true);
	    			stockProducto.setEnabled(true);
	    			Modifica.setEnabled(true);
	    			OkProducto.setEnabled(false);
	    			comboBoxProducto.setEnabled(false);
	    		};break;


	    		case EventoGUI.MUESTRA_PRODUCTO_TEXTFIELDS_ERROR:{
	    			JOptionPane.showMessageDialog(null,
	    					"El producto esta dado de baja o no existe", //Mensaje  				
	    					"ERROR", //T�tulo
	    					JOptionPane.ERROR_MESSAGE);
	    		};break;
	    		
	    		case EventoGUI.CONSULTAR_PRODUCTO_OK:
	    			JOptionPane.showMessageDialog(null, "Mostrada lista de facturas", "OK", JOptionPane.PLAIN_MESSAGE);
	    			ArrayList<TransferFactura> todasFacturas = (ArrayList<TransferFactura>)context.getDatos();
	    			area.setText("");
	    			for(int i = 0; i < todasFacturas.size(); i++) {
	    				TransferFactura elemento = todasFacturas.get(i);
	    				area.setText(area.getText() + muestraFactura(elemento) + "\n");
	    			}	
	    			
	    			break;
	    			
	    		case EventoGUI.CONSULTAR_PRODUCTO_ERROR:
	    			JOptionPane.showMessageDialog(null, "No existe una lista para el producto solicitado", "ERROR", JOptionPane.ERROR_MESSAGE);
	    			break;
	    		}//Fin switch
	    		actualiza(); 
	    	} //Fin metodo update
		
	    
	    private void comboBoxProductoActionPerformed(java.awt.event.ActionEvent evt) {                                                 
			String opcion = comboBoxProducto.getSelectedItem().toString();
			Modifica.setVisible(false);
			if(opcion.equals("ALTA")){
				nombreProducto.setEnabled(true);
				IDProducto.setEnabled(false);
				precioProducto.setEnabled(true);
				stockProducto.setEnabled(true);
			}
			if(opcion.equals("BAJA")){
				nombreProducto.setEnabled(false);
				IDProducto.setEnabled(true);
				precioProducto.setEnabled(false);
				stockProducto.setEnabled(false);

			}
			if(opcion.equals("MODIFICA")){
				Modifica.setVisible(true);
				Modifica.setEnabled(false);
				nombreProducto.setEnabled(false);
				IDProducto.setEnabled(true);
				precioProducto.setEnabled(false);
				stockProducto.setEnabled(false);

			}
			if(opcion.equals("MUESTRA")){
				nombreProducto.setEnabled(false);
				IDProducto.setEnabled(true);
				stockProducto.setEnabled(false);
				precioProducto.setEnabled(false);
			}
			if(opcion.equals("MUESTRA TODOS")){
				nombreProducto.setEnabled(false);
				IDProducto.setEnabled(false);
				stockProducto.setEnabled(false);
				precioProducto.setEnabled(false);
			}
			if(opcion.equals("CONSULTAR PRODUCTO")){
				nombreProducto.setEnabled(false);
				IDProducto.setEnabled(true);
				stockProducto.setEnabled(false);
				precioProducto.setEnabled(false);
			}
			reiniciaComponentes();
	    }                                                

	    private void nombreProductoActionPerformed(java.awt.event.ActionEvent evt) {                                               
	        // TODO add your handling code here:
	    }                                              

	    private void stockProductoActionPerformed(java.awt.event.ActionEvent evt) {                                              
	        // TODO add your handling code here:
	    }                                             

	    private void precioProductoActionPerformed(java.awt.event.ActionEvent evt) {                                               
	        // TODO add your handling code here:
	    }                                              

	    private void OkProductoActionPerformed(java.awt.event.ActionEvent evt) {                                           
	        // TODO add your handling code here:
	    }                                          

	    private void ModificaActionPerformed(java.awt.event.ActionEvent evt) {                                         
	        // TODO add your handling code here:
	    }                                        

	    private void OkProductoMouseClicked(java.awt.event.MouseEvent evt) {                                        
	    	String opcion = comboBoxProducto.getSelectedItem().toString();

			if(opcion.equals("ALTA")){
				TransferProducto tProducto = new TransferProducto();
				
					tProducto.setNombre(nombreProducto.getText());
					if(!precioProducto.getText().toString().equalsIgnoreCase("")){ //Si es una reactivaci�n
					tProducto.setActivo(true);
					tProducto.setPrecio(Float.parseFloat(precioProducto.getText()));
					tProducto.setStock(Integer.parseInt(stockProducto.getText()));}
				
					AppControlador.getInstancia().accion(new Context(EventoNegocio.ALTA_PRODUCTO,tProducto));
				}
			else if(opcion.equals("BAJA")){
					int idProducto = Integer.parseInt(IDProducto.getText());
					TransferProducto tProducto = new TransferProducto();
					tProducto.setIdProducto(idProducto);
					AppControlador.getInstancia().accion(new Context(EventoNegocio.BAJA_PRODUCTO, tProducto));
				} 
			else if(opcion.equals("MODIFICA")){
				int idProducto = Integer.parseInt(IDProducto.getText());
				TransferProducto tProducto = new TransferProducto();
				tProducto.setIdProducto(idProducto);
				AppControlador.getInstancia().accion(new Context(EventoNegocio.MUESTRA_PRODUCTO_GUI, tProducto));
					}
			else if(opcion.equals("MUESTRA")){
				System.out.println("se mete en muestra");
				int idProducto = Integer.parseInt(IDProducto.getText());
				TransferProducto tProducto = new TransferProducto();
				tProducto.setIdProducto(idProducto);
				AppControlador.getInstancia().accion(new Context(EventoNegocio.MUESTRA_PRODUCTO, tProducto));
				} 
			else if(opcion.equals("MUESTRA TODOS")){
				AppControlador.getInstancia().accion(new Context(EventoNegocio.MUESTRA_TODOS_PRODUCTO, null));
							}
			else if(opcion.equals("CONSULTAR PRODUCTO")){
				TransferProducto tProducto = new TransferProducto();
				tProducto.setIdProducto(Integer.parseInt(IDProducto.getText()));
				AppControlador.getInstancia().accion(new Context(EventoNegocio.CONSULTAR_PRODUCTO_FACTURA, tProducto));
			}
	    }                                       

	    private void IDProductoActionPerformed(java.awt.event.ActionEvent evt) {                                           
	        // TODO add your handling code here:
	    }                                          

	    private static String muestraProducto(TransferProducto tProducto) {
			String productoMostrado = "";
			productoMostrado += "---------Producto " + tProducto.getID() + "--------- \n";
			productoMostrado += "Nombre: " + tProducto.getNombre() + "\n";
			productoMostrado += "Precio: " + tProducto.getPrecio() + "\n";
			productoMostrado += "Stock: " + tProducto.getStock() + "\n";
			productoMostrado += "Activo: " + tProducto.getActivo() + "\n";

			return productoMostrado;
		}
	    
	    private static String muestraFactura(TransferFactura tFactura){
	    	String facturaMostrada = "";
	    	facturaMostrada += "---------Factura " + tFactura.getIDFactura() + "--------- \n";
	    	facturaMostrada += "Cliente: " + tFactura.getIDCliente() + "\n";

	    	return facturaMostrada;
	    }
	    
	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String args[]) {
	        try {
	            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
	                if ("Nimbus".equals(info.getName())) {
	                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
	                    break;
	                }
	            }
	        } catch (ClassNotFoundException ex) {
	            java.util.logging.Logger.getLogger(JFrameProductoImp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {
	            java.util.logging.Logger.getLogger(JFrameProductoImp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {
	            java.util.logging.Logger.getLogger(JFrameProductoImp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
	            java.util.logging.Logger.getLogger(JFrameProductoImp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        }
	        //</editor-fold>

	        /* Create and display the form */
	        java.awt.EventQueue.invokeLater(new Runnable() {
	            public void run() {
	                new JFrameProductoImp().setVisible(true);
	            }
	        });
	    }
                    
	    private javax.swing.JTextField IDProducto;
	    private javax.swing.JButton Modifica;
	    private javax.swing.JButton OkProducto;
	    private javax.swing.JTextArea area;
	    private javax.swing.JComboBox comboBoxProducto;
	    private javax.swing.JLabel jLabel1;
	    private javax.swing.JLabel jLabel2;
	    private javax.swing.JLabel jLabel3;
	    private javax.swing.JLabel jLabel4;
	    private javax.swing.JPanel jPanel1;
	    private javax.swing.JScrollPane jScrollPane1;
	    private javax.swing.JTextField nombreProducto;
	    private javax.swing.JTextField precioProducto;
	    private javax.swing.JTextField stockProducto;
	    private boolean estado;               
	}


