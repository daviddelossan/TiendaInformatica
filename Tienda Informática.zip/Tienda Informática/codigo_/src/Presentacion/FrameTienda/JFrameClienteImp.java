/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Presentacion.FrameTienda;

import java.awt.geom.Area;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import Negocio.Cliente.TCliente;
import Negocio.Cliente.TClienteNormal;
import Negocio.Cliente.TClienteVIP;
import Negocio.Factura.TransferFactura;
import Presentacion.Cliente.JFrameCliente;
import Presentacion.controlador.*;

public class JFrameClienteImp extends JFrameCliente{

	private static final long serialVersionUID = 8303103871451023146L;

	public JFrameClienteImp() {
		super("Cliente");
		initComponents();
	}


	private void initComponents() {


		grupoEsVIP = new javax.swing.ButtonGroup();
		grupoIntencionVIP = new javax.swing.ButtonGroup();
		jPanel3 = new javax.swing.JPanel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		jLabel8 = new javax.swing.JLabel();
		direccionCliente = new javax.swing.JTextField();
		IDCliente = new javax.swing.JTextField();
		nombreCliente = new javax.swing.JTextField();
		telefonoCliente = new javax.swing.JTextField();
		jLabel9 = new javax.swing.JLabel();
		esVIPOpcionSI = new javax.swing.JRadioButton();
		esVIPOpcionNO = new javax.swing.JRadioButton();
		jLabel10 = new javax.swing.JLabel();
		jLabel11 = new javax.swing.JLabel();
		tarjetaCredito = new javax.swing.JTextField();
		IntencionVIPOpcionSI = new javax.swing.JRadioButton();
		IntencionVIPOpcionNO = new javax.swing.JRadioButton();
		comboBoxCliente = new javax.swing.JComboBox();
		okButton = new javax.swing.JButton();
		jScrollPane3 = new javax.swing.JScrollPane();
		textAreaCliente = new javax.swing.JTextArea();
		jLabelCorreo = new javax.swing.JLabel();
		correo = new javax.swing.JTextField();
		Modifica = new javax.swing.JButton();

		grupoEsVIP.add(esVIPOpcionSI);
		grupoEsVIP.add(esVIPOpcionNO);

		grupoIntencionVIP.add(IntencionVIPOpcionSI);
		grupoIntencionVIP.add(IntencionVIPOpcionNO);

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		comboBoxCliente.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "ALTA", "BAJA", "MODIFICA", "MUESTRA", "MUESTRA TODO" ,"CONSULTAR CLIENTE FACTURA"}));
		comboBoxCliente.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				comboBoxClienteActionPerformed(evt);
			}
		});

		jLabel5.setText("NOMBRE:");

		jLabel6.setText("ID:");

		jLabel7.setText("DIRECCI�N:");

		jLabel8.setText("TEL�FONO:");

		okButton.setText("OK");

		okButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {

			}
		});

		okButton.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				OKClienteButtonClicked(evt);
			}
		});

		Modifica.setText("MODIFICA");
		Modifica.setVisible(false);
		Modifica.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
			}
		});

		Modifica.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				ModificaMouseClicked(evt);
			}
		});

		nombreCliente.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				nombreClienteActionPerformed(evt);
			}
		});

		IDCliente.setEnabled(false);
		IDCliente.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				IDClienteActionPerformed(evt);
			}
		});

		direccionCliente.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				direccionClienteActionPerformed(evt);
			}
		});

		telefonoCliente.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				telefonoClienteActionPerformed(evt);
			}
		});

		correo.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				correoActionPerformed(evt);
			}
		});


		jLabel9.setText("�QUI�RES SER VIP?");

		esVIPOpcionSI.setSelected(true);
		esVIPOpcionSI.setText("SI");
		esVIPOpcionSI.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				esVIPOpcionSIActionPerformed(evt);
			}
		});

		esVIPOpcionNO.setText("NO");
		esVIPOpcionNO.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				esVIPOpcionNOMouseClicked(evt);
			}
		});

		jLabel10.setText("INTENCI�N DE SER VIP");

		jLabel11.setText("TARJETA DE CR�DITO:");

		IntencionVIPOpcionSI.setSelected(true);
		IntencionVIPOpcionSI.setText("SI");
		IntencionVIPOpcionSI.setEnabled(false);
		IntencionVIPOpcionSI.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				IntencionVIPOpcionSIActionPerformed(evt);
			}
		});

		IntencionVIPOpcionNO.setText("NO");
		IntencionVIPOpcionNO.setEnabled(false);
		IntencionVIPOpcionNO.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				IntencionVIPOpcionNOActionPerformed(evt);
			}
		});


		textAreaCliente.setColumns(20);
		textAreaCliente.setRows(5);
		jScrollPane3.setViewportView(textAreaCliente);
		jLabelCorreo.setText("CORREO:");

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout.setHorizontalGroup(
				jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
						.addContainerGap(89, Short.MAX_VALUE)
						.addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(40, 40, 40))
						.addGroup(jPanel3Layout.createSequentialGroup()
								.addContainerGap()
								.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGroup(jPanel3Layout.createSequentialGroup()
												.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
														.addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
														.addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
														.addComponent(jLabel6)
														.addComponent(jLabel5)
														.addComponent(jLabelCorreo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
														.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
																.addComponent(telefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
																.addGroup(jPanel3Layout.createSequentialGroup()
																		.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(nombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
																				.addComponent(IDCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
																				.addComponent(direccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
																				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(jPanel3Layout.createSequentialGroup()
																								.addComponent(jLabel11)
																								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																								.addComponent(tarjetaCredito, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
																								.addGroup(jPanel3Layout.createSequentialGroup()
																										.addComponent(jLabel10)
																										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(IntencionVIPOpcionSI)
																										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(IntencionVIPOpcionNO))
																										.addGroup(jPanel3Layout.createSequentialGroup()
																												.addComponent(jLabel9)
																												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																												.addComponent(esVIPOpcionSI)
																												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																												.addComponent(esVIPOpcionNO))))
																												.addGroup(jPanel3Layout.createSequentialGroup()
																														.addComponent(correo, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
																														.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(okButton)
																														.addComponent(Modifica)
																												))))
																												.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		jPanel3Layout.setVerticalGroup(
				jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel3Layout.createSequentialGroup()
						.addContainerGap()
						.addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel3Layout.createSequentialGroup()
										.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel5)
												.addComponent(nombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel6)
														.addComponent(IDCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
														.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																.addComponent(jLabel7)
																.addComponent(direccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
																.addGroup(jPanel3Layout.createSequentialGroup()
																		.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																				.addComponent(jLabel9)
																				.addComponent(esVIPOpcionSI)
																				.addComponent(esVIPOpcionNO))
																				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(jLabel10)
																						.addComponent(IntencionVIPOpcionSI)
																						.addComponent(IntencionVIPOpcionNO))
																						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																								.addComponent(jLabel11)
																								.addComponent(tarjetaCredito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
																								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																								.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																										.addComponent(telefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addComponent(jLabel8))
																										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																												.addComponent(correo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
																												.addComponent(jLabelCorreo)
																												.addComponent(Modifica)
																												.addComponent(okButton))
																												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
																												.addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
																												.addGap(29, 29, 29))
		);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 543, Short.MAX_VALUE)
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(layout.createSequentialGroup()
								.addGap(0, 0, Short.MAX_VALUE)
								.addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(0, 0, Short.MAX_VALUE)))
		);
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 352, Short.MAX_VALUE)
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(layout.createSequentialGroup()
								.addGap(0, 0, Short.MAX_VALUE)
								.addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(0, 0, Short.MAX_VALUE)))
		);

		pack();
	}// </editor-fold>                        

	private void direccionClienteActionPerformed(java.awt.event.ActionEvent evt) {                                                 
		// TODO add your handling code here:
	}

	private void comboBoxClienteActionPerformed(java.awt.event.ActionEvent evt) {                                                
		String opcion = comboBoxCliente.getSelectedItem().toString();


		if(opcion.equals("ALTA")){
			Modifica.setEnabled(false);
			Modifica.setVisible(false);
			correo.setEnabled(true);
			IDCliente.setEnabled(false);
			nombreCliente.setEnabled(true);
			telefonoCliente.setEnabled(true);
			direccionCliente.setEnabled(true);      
			esVIPOpcionSI.setEnabled(true);
			esVIPOpcionNO.setEnabled(true);
			tarjetaCredito.setEnabled(true);
		}
		if(opcion.equals("BAJA")){
			Modifica.setEnabled(false);
			Modifica.setVisible(false);
			correo.setEnabled(false);
			IDCliente.setEnabled(true);
			nombreCliente.setEnabled(false);
			direccionCliente.setEnabled(false);
			telefonoCliente.setEnabled(false);
			esVIPOpcionSI.setEnabled(false);
			esVIPOpcionNO.setEnabled(false);
			tarjetaCredito.setEnabled(false);
		}
		if(opcion.equals("MODIFICA")){
			Modifica.setVisible(true);
			Modifica.setEnabled(false);
			correo.setEnabled(false);
			IDCliente.setEnabled(true);
			nombreCliente.setEnabled(false);
			direccionCliente.setEnabled(false);
			esVIPOpcionSI.setEnabled(false);
			esVIPOpcionNO.setEnabled(false);
			tarjetaCredito.setEnabled(false);
			telefonoCliente.setEnabled(false);
		}

		if(opcion.equals("MUESTRA")){
			Modifica.setEnabled(false);
			Modifica.setVisible(false);
			correo.setEnabled(false);
			IDCliente.setEnabled(true);
			nombreCliente.setEnabled(false);
			direccionCliente.setEnabled(false);
			esVIPOpcionSI.setEnabled(false);
			esVIPOpcionNO.setEnabled(false);     
			telefonoCliente.setEnabled(false);
			IntencionVIPOpcionNO.setEnabled(false);
			IntencionVIPOpcionSI.setEnabled(false);
			tarjetaCredito.setEnabled(false);
			telefonoCliente.setEnabled(false);

		}
		if(opcion.equals("MUESTRA TODO")){
			Modifica.setEnabled(false);
			Modifica.setVisible(false);
			correo.setEnabled(false);
			IDCliente.setEnabled(false);
			nombreCliente.setEnabled(false);
			direccionCliente.setEnabled(false);
			esVIPOpcionSI.setEnabled(false);
			esVIPOpcionNO.setEnabled(false);
			IntencionVIPOpcionNO.setEnabled(false);
			IntencionVIPOpcionSI.setEnabled(false);
			tarjetaCredito.setEnabled(false);
			telefonoCliente.setEnabled(false);

		}
		if(opcion.equals("CONSULTAR CLIENTE FACTURA")){
			Modifica.setEnabled(false);
			Modifica.setVisible(false);
			correo.setEnabled(false);
			IDCliente.setEnabled(true);
			nombreCliente.setEnabled(false);
			direccionCliente.setEnabled(false);
			telefonoCliente.setEnabled(false);
			esVIPOpcionSI.setEnabled(false);
			esVIPOpcionNO.setEnabled(false);
			tarjetaCredito.setEnabled(false);
		}
	}  

	private void IDClienteActionPerformed(java.awt.event.ActionEvent evt) {                                          
		// TODO add your handling code here:
	}                                         

	private void nombreClienteActionPerformed(java.awt.event.ActionEvent evt) {                                              
		// TODO add your handling code here:
	}                                             

	private void telefonoClienteActionPerformed(java.awt.event.ActionEvent evt) {                                                
		// TODO add your handling code here:
	}                                               

	private void esVIPOpcionSIActionPerformed(java.awt.event.ActionEvent evt) {                                              
		// TODO add your handling code here:
		IntencionVIPOpcionSI.setEnabled(false);
		IntencionVIPOpcionNO.setEnabled(false);
		tarjetaCredito.setEnabled(true);
	}                                             

	private void esVIPOpcionNOMouseClicked(java.awt.event.MouseEvent evt) {                                           

		IntencionVIPOpcionSI.setEnabled(true);
		IntencionVIPOpcionNO.setEnabled(true);
		tarjetaCredito.setEnabled(false);

	}                                          

	private void IntencionVIPOpcionSIActionPerformed(java.awt.event.ActionEvent evt) {                                                     
		
	}                                                    

	private void IntencionVIPOpcionNOActionPerformed(java.awt.event.ActionEvent evt) {                                                     
		// TODO add your handling code here:
	}                                                    

	private void correoActionPerformed(java.awt.event.ActionEvent evt) {                                       
		// TODO add your handling code here:
	}                                      

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]){
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())){
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(JFrameClienteImp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(JFrameClienteImp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(JFrameClienteImp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(JFrameClienteImp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		//</editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new JFrameClienteImp().setVisible(true);
			}
		});
	}

	public void actualiza(){
		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout.setHorizontalGroup(
				jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
						.addContainerGap(89, Short.MAX_VALUE)
						.addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(40, 40, 40))
						.addGroup(jPanel3Layout.createSequentialGroup()
								.addContainerGap()
								.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGroup(jPanel3Layout.createSequentialGroup()
												.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
														.addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
														.addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
														.addComponent(jLabel6)
														.addComponent(jLabel5)
														.addComponent(jLabelCorreo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
														.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
																.addComponent(telefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
																.addGroup(jPanel3Layout.createSequentialGroup()
																		.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(nombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
																				.addComponent(IDCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
																				.addComponent(direccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
																				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(jPanel3Layout.createSequentialGroup()
																								.addComponent(jLabel11)
																								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																								.addComponent(tarjetaCredito, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
																								.addGroup(jPanel3Layout.createSequentialGroup()
																										.addComponent(jLabel10)
																										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(IntencionVIPOpcionSI)
																										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(IntencionVIPOpcionNO))
																										.addGroup(jPanel3Layout.createSequentialGroup()
																												.addComponent(jLabel9)
																												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																												.addComponent(esVIPOpcionSI)
																												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																												.addComponent(esVIPOpcionNO))))
																												.addGroup(jPanel3Layout.createSequentialGroup()
																														.addComponent(correo, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
																														.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(okButton)
																														.addComponent(Modifica)
																												))))
																												.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		jPanel3Layout.setVerticalGroup(
				jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel3Layout.createSequentialGroup()
						.addContainerGap()
						.addComponent(comboBoxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel3Layout.createSequentialGroup()
										.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel5)
												.addComponent(nombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel6)
														.addComponent(IDCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
														.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																.addComponent(jLabel7)
																.addComponent(direccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
																.addGroup(jPanel3Layout.createSequentialGroup()
																		.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																				.addComponent(jLabel9)
																				.addComponent(esVIPOpcionSI)
																				.addComponent(esVIPOpcionNO))
																				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																				.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(jLabel10)
																						.addComponent(IntencionVIPOpcionSI)
																						.addComponent(IntencionVIPOpcionNO))
																						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																								.addComponent(jLabel11)
																								.addComponent(tarjetaCredito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
																								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																								.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																										.addComponent(telefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addComponent(jLabel8))
																										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
																												.addComponent(correo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
																												.addComponent(jLabelCorreo)
																												.addComponent(okButton)
																												.addComponent(Modifica))
																												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
																												.addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
																												.addGap(29, 29, 29))
		);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 543, Short.MAX_VALUE)
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(layout.createSequentialGroup()
								.addGap(0, 0, Short.MAX_VALUE)
								.addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(0, 0, Short.MAX_VALUE)))
		);
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 352, Short.MAX_VALUE)
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(layout.createSequentialGroup()
								.addGap(0, 0, Short.MAX_VALUE)
								.addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(0, 0, Short.MAX_VALUE)))
		);
	}

	private boolean estado;

	private void reiniciaComponentes(){
		IDCliente.setText("");
		correo.setText("");
		nombreCliente.setText("");
		direccionCliente.setText("");
		telefonoCliente.setText("");
		textAreaCliente.setText("");

	}	

	private void ModificaMouseClicked(java.awt.event.MouseEvent evt) {
		Context context = new Context(0, null);
		
		
		if((esVIPOpcionSI.isSelected())){
			TClienteVIP transferCliente = new TClienteVIP();
			transferCliente.setNombre(nombreCliente.getText());
			transferCliente.setID(Integer.parseInt(IDCliente.getText()));
			transferCliente.setCorreo(correo.getText());
			transferCliente.setDireccion(direccionCliente.getText());
			transferCliente.setTelefono(Integer.parseInt(telefonoCliente.getText()));
			transferCliente.setLimiteTarjeta(Integer.parseInt(tarjetaCredito.getText()));
			transferCliente.setActivo(estado);

			context.setEvento(EventoNegocio.MODIFICA_CLIENTE);
			context.setDatos(transferCliente);
			AppControlador.getInstancia().accion(context);
			reiniciaComponentes();
			okButton.setEnabled(true);
			IDCliente.setEnabled(true);
			nombreCliente.setEnabled(false);
			Modifica.setEnabled(false);
			comboBoxCliente.setEnabled(true);
			tarjetaCredito.setEnabled(true);
		}
		else {
			TClienteNormal transferCliente = new TClienteNormal();
			transferCliente.setNombre(nombreCliente.getText());
			transferCliente.setID(Integer.parseInt(IDCliente.getText()));
			transferCliente.setCorreo(correo.getText());
			transferCliente.setDireccion(direccionCliente.getText());
			transferCliente.setTelefono(Integer.parseInt(telefonoCliente.getText()));
			transferCliente.setActivo(estado);
			if(IntencionVIPOpcionSI.isSelected()){
				transferCliente.setIntencionVIP(IntencionVIPOpcionSI.isSelected());
				}
			else if (IntencionVIPOpcionNO.isSelected()){
			transferCliente.setIntencionVIP(false);
			}
			

			context.setEvento(EventoNegocio.MODIFICA_CLIENTE);
			context.setDatos(transferCliente);
			AppControlador.getInstancia().accion(context);
			
			reiniciaComponentes();
			okButton.setEnabled(true);
			IDCliente.setEnabled(true);
			nombreCliente.setEnabled(false);
			Modifica.setEnabled(false);
			comboBoxCliente.setEnabled(true);
		}
		
		correo.setEnabled(false);
		IDCliente.setEnabled(true);
		nombreCliente.setEnabled(false);
		direccionCliente.setEnabled(false);
		esVIPOpcionSI.setEnabled(false);
		esVIPOpcionNO.setEnabled(false);
		tarjetaCredito.setEnabled(false);
		telefonoCliente.setEnabled(false);
	}

	private void OKClienteButtonClicked(java.awt.event.MouseEvent evt) {  
		Context context = new Context();
		String opcion = comboBoxCliente.getSelectedItem().toString();

		if(opcion.equals("ALTA")){
			if(esVIPOpcionSI.isSelected()){
				TClienteVIP transferClienteVip = new TClienteVIP();

				if(nombreCliente.getText().equalsIgnoreCase("")){
					TClienteVIP transferClienteVip2 = new TClienteVIP();
					transferClienteVip2.setCorreo(correo.getText());
					context.setEvento(EventoNegocio.ALTA_CLIENTE);
					context.setDatos(transferClienteVip2);
					 AppControlador.getInstancia().accion(context);
				}
				else{
					transferClienteVip.setActivo(true);
					transferClienteVip.setNombre(nombreCliente.getText());
					transferClienteVip.setDireccion(direccionCliente.getText());
					transferClienteVip.setTelefono(Integer.parseInt(telefonoCliente.getText()));
					transferClienteVip.setCorreo(correo.getText());
					transferClienteVip.setLimiteTarjeta(Integer.parseInt(tarjetaCredito.getText()));
					context.setEvento(EventoNegocio.ALTA_CLIENTE);
					context.setDatos(transferClienteVip);
					AppControlador.getInstancia().accion(context);
				}
			}
			else{

				if(nombreCliente.getText().equalsIgnoreCase("")){
					TClienteNormal transferClienteNormal2 = new TClienteNormal();
					transferClienteNormal2.setCorreo(correo.getText());
					context.setEvento(EventoNegocio.ALTA_CLIENTE);
					context.setDatos(transferClienteNormal2);
					AppControlador.getInstancia().accion(context);
				}

				else{
					TClienteNormal transferClienteNormal = new TClienteNormal();
					transferClienteNormal.setActivo(true);
					transferClienteNormal.setNombre(nombreCliente.getText());
					transferClienteNormal.setDireccion(direccionCliente.getText());
					transferClienteNormal.setTelefono(Integer.parseInt(telefonoCliente.getText()));
					transferClienteNormal.setCorreo(correo.getText());
					if(IntencionVIPOpcionSI.isSelected())
						transferClienteNormal.setIntencionVIP(true);
					else
						transferClienteNormal.setIntencionVIP(false);
					context.setEvento(EventoNegocio.ALTA_CLIENTE);
					context.setDatos(transferClienteNormal);
					AppControlador.getInstancia().accion(context);
					
				}
			}
		}

		else if(opcion.equals("BAJA")){
			Integer id = Integer.parseInt(IDCliente.getText());
			TCliente transferCliente = new TCliente();
			transferCliente.setID(id);
			context.setDatos(transferCliente);
			context.setEvento(EventoNegocio.BAJA_CLIENTE);
			AppControlador.getInstancia().accion(context);
		}

		if(opcion.equals("MUESTRA")){
			Integer id = Integer.parseInt(IDCliente.getText());
			TCliente transferCliente = new TCliente();
			transferCliente.setID(id);
			context.setDatos(transferCliente);
			context.setEvento(EventoNegocio.MUESTRA_CLIENTE);
			AppControlador.getInstancia().accion(context);
		}

		if(opcion.equals("MUESTRA TODO")){
			context.setEvento(EventoNegocio.MUESTRA_TODOS_CLIENTE);
			AppControlador.getInstancia().accion(context);        	
		}

		if(opcion.equals("MODIFICA")){			
			Integer id = Integer.parseInt(IDCliente.getText());
			TCliente transferCliente = new TCliente();
			transferCliente.setID(id);
			 AppControlador.getInstancia().accion(new Context(EventoNegocio.MUESTRA_CLIENTE_GUI, transferCliente));
			}
		if(opcion.equals("CONSULTAR CLIENTE FACTURA")){
			Integer id = Integer.parseInt(IDCliente.getText());
			TCliente transferCliente = new TCliente();
			transferCliente.setID(id);
			context.setDatos(transferCliente);
			context.setEvento(EventoNegocio.CONSULTAR_CLIENTE_FACTURA);
			AppControlador.getInstancia().accion(context);
		}
	}  
	@Override
	public void update(ContextRetorno context) {
		switch(context.getEvento()) {

		case(EventoGUI.ALTA_CLIENTE_OK): {
			JOptionPane.showMessageDialog(null,
					"Cliente dado de alta correctamente", 
					"OK", 			
					JOptionPane.PLAIN_MESSAGE);
		}
		break;
		case(EventoGUI.ALTA_CLIENTE_ERROR): {
			JOptionPane.showMessageDialog(null,
					"No se pudo dar de alta, ya existe un cliente con ese correo", 
					"OK", 			
					JOptionPane.ERROR_MESSAGE);
		}
		break;		
		case (EventoGUI.BAJA_CLIENTE_OK): {
			JOptionPane.showMessageDialog(null, "Cliente dado de baja correctamente", //Mensaje
					"OK", //T�tulo			
					JOptionPane.PLAIN_MESSAGE);
		} break;

		case (EventoGUI.BAJA_CLIENTE_ERROR): {
			JOptionPane.showMessageDialog(null, "No se pudo dar de baja o no existe", //Mensaje
					"ERROR", //T�tulo			
					JOptionPane.ERROR_MESSAGE);
		} break;

		case (EventoGUI.MUESTRA_CLIENTE_OK): {
			StringBuffer cadena = new StringBuffer();
			TCliente tCliente = (TCliente)context.getDatos();
			if(TClienteVIP.class == tCliente.getClass()){
				TClienteVIP transferCliente = (TClienteVIP)tCliente;
				cadena.append("---------Cliente " + Integer.toString(transferCliente.getID()) +"---------");
				cadena.append('\n');
				cadena.append("Limite tarjeta: " + Integer.toString(transferCliente.getLimiteTarjeta()));
				cadena.append('\n');
				cadena.append("Correo: " + transferCliente.getCorreo());
				cadena.append('\n');
				cadena.append("Nombre: " + transferCliente.getNombre());
				cadena.append('\n');
				cadena.append("Direccion: " + transferCliente.getDireccion());
				cadena.append('\n');
				cadena.append("Telefono: " + Integer.toString(transferCliente.getTelefono()));
				cadena.append('\n');
				if(transferCliente.getActivo() == true)
					cadena.append("Estado: Activo");
				else
					cadena.append("Estado: Inactivo");
			}
			else{
				TClienteNormal transferCliente = (TClienteNormal)tCliente;
				cadena.append("---------Cliente " + Integer.toString(transferCliente.getID()) +"---------");
				cadena.append('\n');
				if(transferCliente.getIntencionVIP() == true)
					cadena.append("Intencion de ser VIP: SI");
				else
					cadena.append("Intencion de ser VIP: NO");
				cadena.append('\n');
				cadena.append("Correo: " + transferCliente.getCorreo());
				cadena.append('\n');
				cadena.append("Nombre: " + transferCliente.getNombre());
				cadena.append('\n');
				cadena.append("Direccion: " + transferCliente.getDireccion());
				cadena.append('\n');
				cadena.append("Telefono: " + Integer.toString(transferCliente.getTelefono()));
				cadena.append('\n');
				if(transferCliente.getActivo() == true)
					cadena.append("Estado: Activo");
				else
					cadena.append("Estado: Inactivo");
			}
			textAreaCliente.setText(cadena.toString());
		} break;
		case (EventoGUI.MUESTRA_CLIENTE_ERROR): {
			JOptionPane.showMessageDialog(null,
					"No existe el cliente", //Mensaje
					"ERROR", //T�tulo			
					JOptionPane.ERROR_MESSAGE);
		}break;
		case (EventoGUI.MUESTRA_TODOS_CLIENTE_OK): {
			ArrayList<TCliente> array = (ArrayList<TCliente>)context.getDatos();
			StringBuffer cadena = new StringBuffer();
			for(int i = 0; i < array.size(); i++){
				TCliente tCliente = array.get(i);
				if(TClienteVIP.class == tCliente.getClass()){
					TClienteVIP transferCliente = (TClienteVIP)tCliente;
					cadena.append("---------Cliente " + Integer.toString(transferCliente.getID()) +"---------");
					cadena.append('\n');
					cadena.append("Limite Tarjeta: " + Integer.toString(transferCliente.getLimiteTarjeta()));
					cadena.append('\n');
					cadena.append("Correo: " + transferCliente.getCorreo());
					cadena.append('\n');
					cadena.append("Nombre: " + transferCliente.getNombre());
					cadena.append('\n');
					cadena.append("Direccion: " + transferCliente.getDireccion());
					cadena.append('\n');
					cadena.append("Telefono: " + Integer.toString(transferCliente.getTelefono()));
					cadena.append('\n');

					if(transferCliente.getActivo() == true)
						cadena.append("Estado: Activo");
					else
						cadena.append("Estado: Inactivo");
				}
				else{
					TClienteNormal transferCliente = (TClienteNormal)tCliente;
					cadena.append("---------Cliente " + Integer.toString(transferCliente.getID()) +"---------");
					cadena.append('\n');
					if(transferCliente.getIntencionVIP() == true)
						cadena.append("Intencion de ser VIP: SI");
					else
						cadena.append("Intencion de ser VIP: NO");
					cadena.append('\n');
					cadena.append("Correo: " + transferCliente.getCorreo());
					cadena.append('\n');
					cadena.append("Nombre: " + transferCliente.getNombre());
					cadena.append('\n');
					cadena.append("Direccion: " + transferCliente.getDireccion());
					cadena.append('\n');
					cadena.append("Telefono: " + Integer.toString(transferCliente.getTelefono()));
					cadena.append('\n');
					if(transferCliente.getActivo() == true)
						cadena.append("Estado: Activo");
					else
						cadena.append("Estado: Inactivo");
				}		
				cadena.append("\n");
				cadena.append("\n");
			}textAreaCliente.setText(cadena.toString());
		}break;
		case EventoGUI.MUESTRA_TODOS_CLIENTE_ERROR:{

			JOptionPane.showMessageDialog(null,
					"No existen clientes", //Mensaje
					"ERROR", //T�tulo			
					JOptionPane.ERROR_MESSAGE);
		};break;

		case EventoGUI.MUESTRA_CLIENTE_TEXTFIELDS:{
			comboBoxCliente.setEnabled(false);
			TCliente tCliente = (TCliente)context.getDatos();
			this.estado = tCliente.getActivo();

			if(TClienteVIP.class == tCliente.getClass()){
				TClienteVIP transferCliente = (TClienteVIP)tCliente;
				esVIPOpcionSI.setSelected(true);
				tarjetaCredito.setText(Integer.toString(transferCliente.getLimiteTarjeta()));
				correo.setText(transferCliente.getCorreo());
				nombreCliente.setText(transferCliente.getNombre());
				direccionCliente.setText(transferCliente.getDireccion());
				telefonoCliente.setText(Integer.toString(transferCliente.getTelefono()));
				tarjetaCredito.setEnabled(true);
			}
			else{
				TClienteNormal transferCliente = (TClienteNormal)tCliente;
				esVIPOpcionNO.setSelected(true);
				IntencionVIPOpcionNO.setEnabled(true);
				IntencionVIPOpcionSI.setEnabled(true);
				if(transferCliente.getIntencionVIP()) IntencionVIPOpcionSI.setSelected(true);
					
				else IntencionVIPOpcionNO.setSelected(false);
				
				correo.setText(transferCliente.getCorreo());
				nombreCliente.setText(transferCliente.getNombre());
				direccionCliente.setText(transferCliente.getDireccion());
				telefonoCliente.setText(Integer.toString(transferCliente.getTelefono()));
				tarjetaCredito.setEnabled(false);
			}

			IDCliente.setEnabled(false);
			correo.setEnabled(true);
			nombreCliente.setEnabled(true);
			direccionCliente.setEnabled(true);
			telefonoCliente.setEnabled(true);
			Modifica.setEnabled(true);
			okButton.setEnabled(false);
		};break;

		case EventoGUI.MODIFICA_CLIENTE_OK: {
			JOptionPane.showMessageDialog(null,
					"Cliente modificado", //Mensaje
					"OK", //T�tulo			
					JOptionPane.PLAIN_MESSAGE);
		};break;

		case EventoGUI.MODIFICA_CLIENTE_ERROR: {
			JOptionPane.showMessageDialog(null,
					"No se pudo modificar el cliente o no existe", //Mensaje
					"ERROR", //T�tulo			
					JOptionPane.ERROR_MESSAGE);
		};break;

		case EventoGUI.MUESTRA_CLIENTE_TEXTFIELDS_ERROR: {
			JOptionPane.showMessageDialog(null,
					"El cliente esta dado de baja o no existe", //Mensaje
					"ERROR", //T�tulo			
					JOptionPane.ERROR_MESSAGE);
		};break;
		
		case EventoGUI.CONSULTAR_CLIENTE_OK:{
			ArrayList<TransferFactura> array = ((ArrayList<TransferFactura>)context.getDatos());
			StringBuffer cadena = new StringBuffer();
			for(int i = 0; i < array.size();i++){
				TransferFactura tFactura = array.get(i);
				cadena.append("Factura: " + tFactura.getIDFactura() + "\n");
			}
			textAreaCliente.setText(cadena.toString());
		}
			//JOptionPane.showMessageDialog(null, "Mostrada lista de facturas", "OK", JOptionPane.PLAIN_MESSAGE);
			;break;
			
		case EventoGUI.CONSULTAR_CLIENTE_ERROR:
			JOptionPane.showMessageDialog(null, "No existe una lista para el cliente solicitado", "OK", JOptionPane.ERROR_MESSAGE);
			break;
		}
		
		actualiza();
	}

	// Variables declaration - do not modify                     
	private javax.swing.JTextField IDCliente;
	private javax.swing.JRadioButton IntencionVIPOpcionNO;
	private javax.swing.JRadioButton IntencionVIPOpcionSI;
	private javax.swing.JComboBox comboBoxCliente;
	private javax.swing.JTextField correo;
	private javax.swing.JTextField direccionCliente;
	private javax.swing.JRadioButton esVIPOpcionNO;
	private javax.swing.JRadioButton esVIPOpcionSI;
	private javax.swing.ButtonGroup grupoEsVIP;
	private javax.swing.ButtonGroup grupoIntencionVIP;
	private javax.swing.JButton okButton;
	private javax.swing.JButton Modifica;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel11;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JLabel jLabelCorreo;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JScrollPane jScrollPane3;
	private javax.swing.JTextArea textAreaCliente;
	private javax.swing.JTextField nombreCliente;
	private javax.swing.JTextField tarjetaCredito;
	private javax.swing.JTextField telefonoCliente;
	// End of variables declaration                   


}
