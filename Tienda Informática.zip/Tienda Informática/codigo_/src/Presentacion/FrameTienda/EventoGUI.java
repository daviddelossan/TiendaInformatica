package Presentacion.FrameTienda;

public class EventoGUI {
	
	//PRODUCTO==================================================
	public static final int ALTA_PRODUCTO_OK = 101;
	public static final int ALTA_PRODUCTO_ERROR = 102;
	public static final int BAJA_PRODUCTO_OK = 103;
	public static final int BAJA_PRODUCTO_ERROR = 104;
	public static final int MODIFICA_PRODUCTO_OK = 105;
	public static final int MODIFICA_PRODUCTO_ERROR = 106;
	public static final int MUESTRA_PRODUCTO_OK = 107;
	public static final int MUESTRA_PRODUCTO_ERROR = 108;
	public static final int MUESTRA_TODOS_PRODUCTO_OK = 109;
	public static final int MUESTRA_TODOS_PRODUCTO_ERROR = 110;
	public static final int MUESTRA_PRODUCTO_TEXTFIELDS = 111;
	public static final int MUESTRA_PRODUCTO_TEXTFIELDS_ERROR = 112;
	public static final int CONSULTAR_PRODUCTO_OK = 113;
	public static final int CONSULTAR_PRODUCTO_ERROR = 114;
	//FACTURA======================================
	public static final int ALTA_CARRITO_OK = 201;
	public static final int ALTA_CARRITO_ERROR = 202; 
	public static final int GENERA_FACTURA_OK = 203; 
	public static final int GENERA_FACTURA_ERROR = 204; 
	public static final int ANADIR_PRODUCTO_CARRITO_OK = 205;
	public static final int ANADIR_PRODUCTO_CARRITO_ERROR = 206;
	public static final int MUESTRA_FACTURAS_OK = 207;
	public static final int MUESTRA_FACTURAS_ERROR = 208;
	public static final int ELIMINAR_PRODUCTO_CARRITO_OK = 209;
	public static final int ELIMINAR_PRODUCTO_CARRITO_ERROR = 210;
	public static final int MUESTRA_FACTURA_OK = 211;
	public static final int MUESTRA_FACTURA_ERROR = 212;
	public static final int DEVOLUCION_OK = 213;
	public static final int DEVOLUCION_ERROR = 214;
	
	//CLIENTE======================================
	public static final int ALTA_CLIENTE_OK = 301;
	public static final int ALTA_CLIENTE_ERROR = 302;
	public static final int BAJA_CLIENTE_OK = 303;
	public static final int BAJA_CLIENTE_ERROR = 304;
	public static final int MODIFICA_CLIENTE_OK = 305;
	public static final int MODIFICA_CLIENTE_ERROR = 306;
	public static final int MUESTRA_CLIENTE_OK = 307;
	public static final int MUESTRA_CLIENTE_ERROR = 308;
	public static final int MUESTRA_TODOS_CLIENTE_OK = 309;
	public static final int MUESTRA_TODOS_CLIENTE_ERROR = 310;
	public static final int MUESTRA_CLIENTE_TEXTFIELDS = 311;
	public static final int MUESTRA_CLIENTE_TEXTFIELDS_ERROR = 312;
	public static final int CONSULTAR_CLIENTE_OK = 313;
	public static final int CONSULTAR_CLIENTE_ERROR = 314;
	
	

}
