package Presentacion.Factura;
import javax.swing.JFrame;
import Presentacion.FrameTienda.JFrameFacturaImp;
import Presentacion.controlador.ContextRetorno;


public abstract class JFrameFactura extends JFrame{
	
	
	private static final long serialVersionUID = 119588253389868879L;
	private static JFrameFactura instancia;

	public JFrameFactura(String nombre){
		super(nombre);
	}
	public abstract void update(ContextRetorno contextEntrada);

	public static JFrameFactura getInstancia() {
		if(instancia == null){
			instancia = new JFrameFacturaImp();			
		}
		return instancia;
	}
}