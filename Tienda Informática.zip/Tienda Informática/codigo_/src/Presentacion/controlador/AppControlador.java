
package Presentacion.controlador;

import Presentacion.controlador.imp.AppControladorImp;

public abstract class AppControlador {

	private static AppControlador instancia;
	
	public static AppControlador getInstancia() {
		if(instancia == null)
			instancia = new AppControladorImp();
		return instancia;
	}
	
	public abstract void accion(Context Context);
}