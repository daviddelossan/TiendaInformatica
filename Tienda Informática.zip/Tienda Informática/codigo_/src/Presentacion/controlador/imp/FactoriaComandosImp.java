package Presentacion.controlador.imp;

import Presentacion.controlador.EventoNegocio;
import Presentacion.controlador.FactoriaComandos;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Comando.ComandoCliente.*;
import Presentacion.controlador.Comando.ComandoFactura.*;
import Presentacion.controlador.Comando.ComandoProducto.*;

public class FactoriaComandosImp extends FactoriaComandos {

	@Override
	public ComandoInterfaz getCommand(int comando) {
		ComandoInterfaz evento = null;
		switch(comando){
		case EventoNegocio.ALTA_CLIENTE:{
			evento = new ComandoAltaCliente();};
			break;
			
		case EventoNegocio.BAJA_CLIENTE:{
			evento = new ComandoBajaCliente();};
			break;
			
		case EventoNegocio.MODIFICA_CLIENTE:{
			evento = new ComandoModificaCliente();};
			break;
		
		case EventoNegocio.MUESTRA_CLIENTE:{
			evento = new ComandoMuestraCliente();};
			break;
		
		case EventoNegocio.MUESTRA_TODOS_CLIENTE:{
			evento = new ComandoMuestraClientes();};
			break;
			
		case EventoNegocio.MUESTRA_CLIENTE_GUI:{
			evento = new ComandoMuestraClienteGUI();};
			break;

		case EventoNegocio.CONSULTAR_CLIENTE_FACTURA:{
			evento = new ComandoConsultaClienteFactura();};
			break;
			///////////////////////////////////////////

		case EventoNegocio.ALTA_PRODUCTO:{
			evento = new ComandoAltaProducto();};
			break;
			
		case EventoNegocio.BAJA_PRODUCTO:{
			evento = new ComandoBajaProducto();};
			break;
			
		case EventoNegocio.MODIFICA_PRODUCTO:{
			evento = new ComandoModificaProducto();};
			break;
			
		case EventoNegocio.MUESTRA_PRODUCTO:{
			evento = new ComandoMuestraProducto();};
			break;
			
		case EventoNegocio.MUESTRA_TODOS_PRODUCTO:{
			evento = new ComandoMuestraProductos();};
			break;
			
		case EventoNegocio.CONSULTAR_PRODUCTO_FACTURA:{
			evento = new ComandoConsultarProducto();};
			break;
		
		case EventoNegocio.MUESTRA_PRODUCTO_GUI:{
			evento = new ComandoMuestraProductoGUI();};
			break;
		
			///////////////////////////////////////////
			
		case EventoNegocio.GENERA_FACTURA:{
			evento = new ComandoAltaFactura();};
			break;
			
		case EventoNegocio.DEVOLUCION_FACTURA:{
			evento = new ComandoDevolucion();};
			break;
			
		case EventoNegocio.MUESTRA_FACTURA:{
			evento = new ComandoMuestraFactura();};
			break;
			
		case EventoNegocio.MUESTRA_FACTURAS:{
			evento = new ComandoMuestraFacturas();};
			break;
		
	
			
		
		}
		return evento;
	}
	
}