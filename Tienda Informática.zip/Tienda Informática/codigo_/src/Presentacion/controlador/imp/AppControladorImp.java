/**
 * 
 */
package Presentacion.controlador.imp;

import Presentacion.controlador.AppControlador;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;
import Presentacion.controlador.Dispatcher;
import Presentacion.controlador.FactoriaComandos;
import Presentacion.controlador.ComandoInterfaz;

public class AppControladorImp extends AppControlador {

	public void accion(Context context) {
		ContextRetorno contextRespuesta = null;
		
		try{
			int numComando = context.getEvento();
			FactoriaComandos factoriaComandos = FactoriaComandos.getInstancia();
			ComandoInterfaz comando = factoriaComandos.getCommand(numComando);
			contextRespuesta = comando.execute(context);
			Dispatcher dispatcher = Dispatcher.getInstancia();
			dispatcher.actualizaVista(contextRespuesta);
		}
		catch(Exception e){
			
		}
		
		//return contextRespuesta;
	}
}