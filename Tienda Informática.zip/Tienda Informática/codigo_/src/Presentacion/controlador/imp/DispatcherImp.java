/**
 * 
 */
package Presentacion.controlador.imp;

import Presentacion.Cliente.JFrameCliente;
import Presentacion.Factura.JFrameFactura;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.Producto.JFrameProducto;
import Presentacion.controlador.Dispatcher;
import Presentacion.controlador.ContextRetorno;


public class DispatcherImp extends Dispatcher {



	
	public void actualizaVista(ContextRetorno context) {
		int tipoEvento = context.getEvento() / 100;
		switch(tipoEvento){
		case 1: {
			JFrameProducto jFrameProducto = JFrameProducto.getInstancia();
			jFrameProducto.update(context);	
			};
			break;
		case 2:{
			JFrameFactura jFrameFactura = JFrameFactura.getInstancia();
			jFrameFactura.update(context);
			};
			break;
		case 3: {
			JFrameCliente jFrameCliente = JFrameCliente.getInstancia();
			jFrameCliente.update(context);};
			break;
		}
		

	}
}