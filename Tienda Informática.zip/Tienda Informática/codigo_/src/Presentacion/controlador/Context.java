/**
 * 
 */
package Presentacion.controlador;

public class Context {
	
	private Object datos;
	private int evento;
	
	public Context(){
		this.evento = 0;
		this.datos = null;
	}
	
	public Context(int evento, Object datos){
		this.evento = evento;
		this.datos = datos;
	}

	public void setEvento(int evento) {
		this.evento = evento;
	}

	public int getEvento() {
		return this.evento;
		}

	public Object getDatos() {
		return this.datos;
	}

	public void setDatos(Object datos) {
		this.datos = datos;
	}
}