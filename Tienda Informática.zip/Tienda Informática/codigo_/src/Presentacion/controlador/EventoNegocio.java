package Presentacion.controlador;

public class EventoNegocio {

	
	//PRODUCTO=======================================
	public static final int ALTA_PRODUCTO = 101;
	public static final int BAJA_PRODUCTO = 102;
	public static final int MODIFICA_PRODUCTO = 103;
	public static final int MUESTRA_PRODUCTO = 104;
	public static final int MUESTRA_TODOS_PRODUCTO = 105;
	public static final int MUESTRA_PRODUCTO_GUI = 106;
	public static final int CONSULTAR_PRODUCTO_FACTURA = 107;

	//FACTURA======================================
	public static final int MUESTRA_FACTURA = 204;
	public static final int MUESTRA_FACTURAS = 205;
	public static final int DEVOLUCION_FACTURA = 206;
	public static final int GENERA_FACTURA = 207;
	
	//CLIENTE======================================
	public static final int ALTA_CLIENTE = 301;
	public static final int BAJA_CLIENTE = 302;
	public static final int MODIFICA_CLIENTE= 303;
	public static final int MUESTRA_CLIENTE = 304;
	public static final int MUESTRA_TODOS_CLIENTE = 305;
	public static final int MUESTRA_CLIENTE_GUI = 306;
	public static final int CONSULTAR_CLIENTE_FACTURA = 307;
	
	
	

	
}
