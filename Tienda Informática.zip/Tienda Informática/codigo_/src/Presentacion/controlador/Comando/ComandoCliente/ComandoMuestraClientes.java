/**
 * 
 */
package Presentacion.controlador.Comando.ComandoCliente;

import java.util.ArrayList;

import Negocio.Cliente.SACliente;
import Negocio.Cliente.TCliente;
import Negocio.Factoria.FactoriaSA;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;

public class ComandoMuestraClientes implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {
		System.out.println("Paso por el comando");
		ContextRetorno contextSalida = new ContextRetorno();
		FactoriaSA factoriaSA = FactoriaSA.getInstancia();
		SACliente  saCliente = factoriaSA.generaSACliente();
		TCliente tCliente = (TCliente) contextEntrada.getDatos();
		ArrayList<TCliente> lista = saCliente.muestraClientes();
		if(lista.size() != 0)
			contextSalida.setEvento(EventoGUI.MUESTRA_TODOS_CLIENTE_OK);
		else{
			contextSalida.setEvento(EventoGUI.MUESTRA_TODOS_CLIENTE_ERROR);
		}
		contextSalida.setDatos(lista);

		return contextSalida;
	}
}