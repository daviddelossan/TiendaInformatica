/**
 * 
 */
package Presentacion.controlador.Comando.ComandoCliente;

import Negocio.Cliente.SACliente;
import Negocio.Cliente.TCliente;
import Negocio.Factoria.FactoriaSA;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;


public class ComandoModificaCliente implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {

		ContextRetorno contextSalida = new ContextRetorno();
		FactoriaSA factoriaSA = FactoriaSA.getInstancia();
		SACliente  saCliente = factoriaSA.generaSACliente();
		TCliente tCliente = (TCliente) contextEntrada.getDatos();
		boolean ok = saCliente.modificaCliente(tCliente);
		if(ok)
			contextSalida.setEvento(EventoGUI.MODIFICA_CLIENTE_OK);
		else{
			contextSalida.setEvento(EventoGUI.MODIFICA_CLIENTE_ERROR);
		}
		contextSalida.setDatos(contextEntrada.getDatos());
		return contextSalida;
		
	}
}