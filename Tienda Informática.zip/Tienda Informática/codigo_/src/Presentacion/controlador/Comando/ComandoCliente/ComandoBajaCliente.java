/**
 * 
 */
package Presentacion.controlador.Comando.ComandoCliente;

import Negocio.Cliente.SACliente;
import Negocio.Cliente.TCliente;
import Negocio.Factoria.FactoriaSA;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;


public class ComandoBajaCliente implements ComandoInterfaz {
	
	@SuppressWarnings("null")
	public ContextRetorno execute(Context contextEntrada) throws Exception {
		ContextRetorno contextSalida = new ContextRetorno();
		FactoriaSA factoriaSA = FactoriaSA.getInstancia();
		SACliente  saCliente = factoriaSA.generaSACliente();
		 TCliente tCliente = (TCliente) contextEntrada.getDatos();
		 boolean ok = saCliente.bajaCliente(tCliente.getID());
		 
		 if(ok){
			 contextSalida.setEvento(EventoGUI.BAJA_CLIENTE_OK);
		 }
		 else{
			 contextSalida.setEvento(EventoGUI.BAJA_CLIENTE_ERROR);
		 }
		 
		return contextSalida;
		// end-user-code
	}
}