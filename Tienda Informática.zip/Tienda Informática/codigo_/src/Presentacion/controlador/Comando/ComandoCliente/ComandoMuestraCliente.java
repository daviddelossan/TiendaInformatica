/**
 * 
 */
package Presentacion.controlador.Comando.ComandoCliente;

import Negocio.Cliente.SACliente;
import Negocio.Cliente.TCliente;
import Negocio.Factoria.FactoriaSA;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;


public class ComandoMuestraCliente implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {
		// begin-user-code
		ContextRetorno contextSalida = new ContextRetorno();
		FactoriaSA factoriaSA = FactoriaSA.getInstancia();
		SACliente  saCliente = factoriaSA.generaSACliente();
		TCliente tCliente = (TCliente) contextEntrada.getDatos();
		TCliente transfer = saCliente.muestraCliente(tCliente.getID());
		if(transfer != null)
			contextSalida.setEvento(EventoGUI.MUESTRA_CLIENTE_OK);
		else{
			contextSalida.setEvento(EventoGUI.MUESTRA_CLIENTE_ERROR);
		}
		contextSalida.setDatos(transfer);
		return contextSalida;
	}
}