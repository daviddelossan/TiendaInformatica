package Presentacion.controlador.Comando.ComandoCliente;

import java.util.ArrayList;

import Negocio.Cliente.SACliente;
import Negocio.Cliente.TCliente;
import Negocio.Factoria.FactoriaSA;
import Negocio.Factura.TransferFactura;
import Negocio.Producto.TransferProducto;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;


public class ComandoConsultaClienteFactura implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {
		ContextRetorno contextSalida = new ContextRetorno();
		FactoriaSA factoriaSA = FactoriaSA.getInstancia();
		SACliente saCliente = factoriaSA.generaSACliente();
		ArrayList<TransferFactura> lista = saCliente.consultaClientesFactura(((TCliente)contextEntrada.getDatos()).getID());
		if( lista.size() != 0)
			contextSalida.setEvento(EventoGUI.CONSULTAR_CLIENTE_OK);
		else{
			contextSalida.setEvento(EventoGUI.CONSULTAR_CLIENTE_ERROR);
		}
		contextSalida.setDatos(lista);
		return contextSalida;
	
		// end-user-code
	}
}