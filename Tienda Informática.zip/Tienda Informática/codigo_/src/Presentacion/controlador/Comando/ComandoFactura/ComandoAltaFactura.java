package Presentacion.controlador.Comando.ComandoFactura;

import Negocio.Factoria.FactoriaSA;
import Negocio.Factura.SAFactura;
import Negocio.Factura.TransferFactura;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;
import Presentacion.FrameTienda.EventoGUI;

public class ComandoAltaFactura implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {
		
		ContextRetorno contextSalida = new ContextRetorno();
		
		SAFactura saFactura = FactoriaSA.getInstancia().generaSAFactura();
		TransferFactura tFactura = (TransferFactura)contextEntrada.getDatos();
		int id = -1;
		if(tFactura != null)
			id = saFactura.generaFactura(tFactura);
		if(id != -1) {
			tFactura.setIDFactura(id);
			contextSalida.setEvento(EventoGUI.GENERA_FACTURA_OK);	
		}
		else
			contextSalida.setEvento(EventoGUI.GENERA_FACTURA_ERROR);
		
		contextSalida.setDatos(tFactura);
		
		return contextSalida;
	}
}