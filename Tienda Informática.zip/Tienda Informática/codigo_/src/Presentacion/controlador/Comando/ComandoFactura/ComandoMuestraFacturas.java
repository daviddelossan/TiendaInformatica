package Presentacion.controlador.Comando.ComandoFactura;

import java.util.ArrayList;

import Negocio.Factoria.FactoriaSA;
import Negocio.Factura.SAFactura;
import Negocio.Factura.TransferFactura;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;
import Presentacion.FrameTienda.EventoGUI;

public class ComandoMuestraFacturas implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {
		
		ContextRetorno contextSalida = new ContextRetorno();
		
		SAFactura saFactura = FactoriaSA.getInstancia().generaSAFactura();	
		ArrayList<TransferFactura> todasFacturas = saFactura.muestraFacturas();
		if(todasFacturas != null)
			contextSalida.setEvento(EventoGUI.MUESTRA_FACTURAS_OK);
		else
			contextSalida.setEvento(EventoGUI.MUESTRA_FACTURAS_ERROR);
		
		contextSalida.setDatos(todasFacturas);
		
		return contextSalida;
	}
}