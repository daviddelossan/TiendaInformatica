package Presentacion.controlador.Comando.ComandoFactura;

import Negocio.Factoria.FactoriaSA;
import Negocio.Factura.SAFactura;
import Negocio.Factura.TransferFactura;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;
import Presentacion.FrameTienda.EventoGUI;


public class ComandoMuestraFactura implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {

		ContextRetorno contextSalida = new ContextRetorno();
		
		SAFactura saFactura = FactoriaSA.getInstancia().generaSAFactura();
		int idFactura = (Integer)contextEntrada.getDatos();
		TransferFactura tFactura = saFactura.muestraFactura(idFactura);
		if(tFactura != null)
			contextSalida.setEvento(EventoGUI.MUESTRA_FACTURA_OK);
		else
			contextSalida.setEvento(EventoGUI.MUESTRA_FACTURA_ERROR);
		
		if(tFactura == null){
			tFactura = new TransferFactura();
			tFactura.setIDFactura(idFactura);
		}
		
		contextSalida.setDatos(tFactura);
		
		return contextSalida;
	}
}