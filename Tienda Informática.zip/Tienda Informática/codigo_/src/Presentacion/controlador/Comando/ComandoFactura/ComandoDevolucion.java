package Presentacion.controlador.Comando.ComandoFactura;

import java.util.ArrayList;

import Negocio.Factoria.FactoriaSA;
import Negocio.Factura.SAFactura;
import Negocio.Factura.TransferFactura;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;
import Presentacion.FrameTienda.EventoGUI;

public class ComandoDevolucion implements ComandoInterfaz {
	@SuppressWarnings("unchecked")
	public ContextRetorno execute(Context contextEntrada) throws Exception {
		
		ContextRetorno contextSalida = new ContextRetorno();

		SAFactura saFactura = FactoriaSA.getInstancia().generaSAFactura();
		ArrayList<Object> arrayTransfers = (ArrayList<Object>)contextEntrada.getDatos();
		int idFactura = (Integer)arrayTransfers.get(0);
		int idProducto =  (Integer)arrayTransfers.get(1);
		int unidades = (Integer)arrayTransfers.get(2);
		TransferFactura tFactura = saFactura.devolucion(idFactura, idProducto, unidades);
		if(tFactura != null)
			contextSalida.setEvento(EventoGUI.DEVOLUCION_OK);
		else
			contextSalida.setEvento(EventoGUI.DEVOLUCION_ERROR);
		
		contextSalida.setDatos(tFactura);
		
		return contextSalida;
	}
}