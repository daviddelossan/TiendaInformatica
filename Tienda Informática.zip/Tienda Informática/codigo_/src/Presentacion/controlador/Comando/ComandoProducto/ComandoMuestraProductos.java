package Presentacion.controlador.Comando.ComandoProducto;

import java.util.ArrayList;
import Negocio.Factoria.FactoriaSA;
import Negocio.Producto.SAProducto;
import Negocio.Producto.TransferProducto;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;

public class ComandoMuestraProductos implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {
		ContextRetorno contextSalida = new ContextRetorno();
		SAProducto saProducto = FactoriaSA.getInstancia().generaSAProducto();	
		ArrayList<TransferProducto> listaProductos = saProducto.muestraProductos();
		if(listaProductos.size()!= 0)
			contextSalida.setEvento(EventoGUI.MUESTRA_TODOS_PRODUCTO_OK);
		else
			contextSalida.setEvento(EventoGUI.MUESTRA_TODOS_PRODUCTO_ERROR);
		
		contextSalida.setDatos(listaProductos);
		
		return contextSalida;
	}
}