package Presentacion.controlador.Comando.ComandoProducto;


import Negocio.Factoria.FactoriaSA;
import Negocio.Producto.SAProducto;
import Negocio.Producto.TransferProducto;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;

public class ComandoMuestraProductoGUI implements ComandoInterfaz{

	@Override
	public ContextRetorno execute(Context contextEntrada) throws Exception {
		ContextRetorno contextSalida = new ContextRetorno();
		FactoriaSA factoriaSA = FactoriaSA.getInstancia();
		SAProducto  saProducto = factoriaSA.generaSAProducto();
		TransferProducto tProducto = (TransferProducto) contextEntrada.getDatos();
		TransferProducto transfer = saProducto.muestraProducto(tProducto.getID());
		
		if(transfer != null)
			contextSalida.setEvento(EventoGUI.MUESTRA_PRODUCTO_TEXTFIELDS);
		else{
			contextSalida.setEvento(EventoGUI.MUESTRA_PRODUCTO_TEXTFIELDS_ERROR);
		}
		contextSalida.setDatos(transfer);

		return contextSalida;
	}

}
