package Presentacion.controlador.Comando.ComandoProducto;

import Negocio.Factoria.FactoriaSA;
import Negocio.Producto.SAProducto;
import Negocio.Producto.TransferProducto;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;

public class ComandoBajaProducto implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {
		ContextRetorno contextSalida = new ContextRetorno();
		FactoriaSA factoriaSA = FactoriaSA.getInstancia();
		SAProducto  saProducto = factoriaSA.generaSAProducto();
		 TransferProducto tProducto = (TransferProducto)contextEntrada.getDatos();
		 boolean ok = saProducto.bajaProducto(tProducto.getID());
		 
		 if(ok){
			 contextSalida.setDatos(tProducto);
			 contextSalida.setEvento(EventoGUI.BAJA_PRODUCTO_OK);
		 }
		 else{
			 contextSalida.setEvento(EventoGUI.BAJA_PRODUCTO_ERROR);
		 }
		 
		return contextSalida;
	}
}