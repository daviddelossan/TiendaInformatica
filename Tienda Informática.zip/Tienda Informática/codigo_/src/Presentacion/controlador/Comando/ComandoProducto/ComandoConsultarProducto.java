package Presentacion.controlador.Comando.ComandoProducto;

import java.util.ArrayList;

import Negocio.Cliente.SACliente;
import Negocio.Factoria.FactoriaSA;
import Negocio.Producto.SAProducto;
import Negocio.Producto.TransferProducto;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;

public class ComandoConsultarProducto implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {
		ContextRetorno contextSalida = new ContextRetorno();
		FactoriaSA factoriaSA = FactoriaSA.getInstancia();
		SAProducto saProducto = factoriaSA.generaSAProducto();
		ArrayList<Object> lista = saProducto.consultarProducto(((TransferProducto)contextEntrada.getDatos()).getID());
		
		if( lista.size() != 0)
			contextSalida.setEvento(EventoGUI.CONSULTAR_PRODUCTO_OK);
		else{
			contextSalida.setEvento(EventoGUI.CONSULTAR_PRODUCTO_ERROR);
		}
		contextSalida.setDatos(lista);
		return contextSalida;
	}
}