package Presentacion.controlador.Comando.ComandoProducto;

import Negocio.Factoria.FactoriaSA;
import Negocio.Producto.SAProducto;
import Negocio.Producto.TransferProducto;
import Presentacion.FrameTienda.EventoGUI;
import Presentacion.controlador.ComandoInterfaz;
import Presentacion.controlador.Context;
import Presentacion.controlador.ContextRetorno;

public class ComandoAltaProducto implements ComandoInterfaz {

	public ContextRetorno execute(Context contextEntrada) throws Exception {
		ContextRetorno contextSalida = new ContextRetorno();
		FactoriaSA factoriaSA = FactoriaSA.getInstancia();
		SAProducto servicioAplicacionProducto = factoriaSA.generaSAProducto();
		int evento = servicioAplicacionProducto.altaProducto((TransferProducto)contextEntrada.getDatos());
		if(evento != -1){
			contextSalida.setEvento(EventoGUI.ALTA_PRODUCTO_OK);

		}		
		else{
			contextSalida.setEvento(EventoGUI.ALTA_PRODUCTO_ERROR);
		}
		contextSalida.setDatos(contextEntrada.getDatos());
		return contextSalida;
	}
}