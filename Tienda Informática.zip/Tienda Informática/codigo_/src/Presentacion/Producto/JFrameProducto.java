
package Presentacion.Producto;

import javax.swing.JFrame;
import Presentacion.FrameTienda.JFrameProductoImp;
import Presentacion.controlador.ContextRetorno;

public abstract class JFrameProducto extends JFrame{


	private static final long serialVersionUID = -3930339351004650361L;
	private static JFrameProducto instancia;
	


	public JFrameProducto(String nombre){
		super(nombre);
	}
	
	public static JFrameProducto getInstancia() {
		if(instancia == null){
			instancia = new JFrameProductoImp();			
		}
		return instancia;
	}
	public abstract void update(ContextRetorno context);
	
}