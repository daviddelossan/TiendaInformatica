/**
 * 
 */
package Presentacion.Cliente;

import javax.swing.JFrame;
import Presentacion.FrameTienda.JFrameClienteImp;
import Presentacion.controlador.ContextRetorno;


public abstract class JFrameCliente extends JFrame{

	private static final long serialVersionUID = -9215345081667675004L;
	private static JFrameCliente instancia;
	
	public JFrameCliente(String nombre){
		super(nombre);
}
	
	public static JFrameCliente getInstancia() {
		if(instancia == null){
			instancia = new JFrameClienteImp();			
		}
		return instancia;
	}

	public abstract void update(ContextRetorno context);
}